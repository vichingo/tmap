-- phpMyAdmin SQL Dump
-- version 3.3.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 10, 2010 at 03:31 PM
-- Server version: 5.0.75
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vichingo_wp_pizza`
--

-- --------------------------------------------------------

--
-- Table structure for table `bestanddeel`
--

CREATE TABLE `bestanddeel` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  `code` int(3) unsigned default NULL COMMENT 'ndb code',
  `prijs` decimal(4,2) default NULL,
  `voedsel_categorie_id` int(3) NOT NULL,
  PRIMARY KEY  (`id`,`voedsel_categorie_id`),
  KEY `fk_bestanddeel_voedsel_categorie1` (`voedsel_categorie_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `bestanddeel`
--

INSERT INTO `bestanddeel` VALUES(44, 'Broccoli', 77, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(50, 'Artisjok', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(49, 'Alfalfa(Luzerne scheuten)', 611, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(51, 'Champignons', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(52, 'Ui', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(53, 'Olijven', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(54, 'Doperwten', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(55, 'Ui (rood)', 100, '0.75', 1);
INSERT INTO `bestanddeel` VALUES(56, 'Tomatensaus', 100, '0.25', 1);
INSERT INTO `bestanddeel` VALUES(57, 'Kaas', 100, '0.50', 5);
INSERT INTO `bestanddeel` VALUES(58, 'Ham', 163, '0.50', 3);
INSERT INTO `bestanddeel` VALUES(59, 'Salami', 162, '0.50', 3);
INSERT INTO `bestanddeel` VALUES(60, 'Gouda', 100, '0.50', 5);
INSERT INTO `bestanddeel` VALUES(61, 'Gorgonzola', 100, '0.75', 5);
INSERT INTO `bestanddeel` VALUES(62, 'Mozzarella', 100, '0.70', 5);
INSERT INTO `bestanddeel` VALUES(63, 'Pecorino (schapenkaas)', 100, '0.75', 5);
INSERT INTO `bestanddeel` VALUES(64, 'Taleggio', 100, '0.75', 5);
INSERT INTO `bestanddeel` VALUES(65, 'Parmezaan', 100, '0.50', 5);
INSERT INTO `bestanddeel` VALUES(66, 'Roquefort ', 100, '0.70', 5);

-- --------------------------------------------------------

--
-- Table structure for table `bestellijn_gerecht_opties`
--

CREATE TABLE `bestellijn_gerecht_opties` (
  `id` int(11) NOT NULL auto_increment,
  `gerecht_optie_variant_id` int(3) NOT NULL,
  `bestellijn_id` int(3) NOT NULL,
  PRIMARY KEY  (`id`,`gerecht_optie_variant_id`,`bestellijn_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=130 ;

--
-- Dumping data for table `bestellijn_gerecht_opties`
--

INSERT INTO `bestellijn_gerecht_opties` VALUES(19, 12, 7);
INSERT INTO `bestellijn_gerecht_opties` VALUES(20, 5, 7);
INSERT INTO `bestellijn_gerecht_opties` VALUES(21, 9, 7);
INSERT INTO `bestellijn_gerecht_opties` VALUES(22, 12, 8);
INSERT INTO `bestellijn_gerecht_opties` VALUES(23, 5, 8);
INSERT INTO `bestellijn_gerecht_opties` VALUES(24, 9, 8);
INSERT INTO `bestellijn_gerecht_opties` VALUES(25, 12, 9);
INSERT INTO `bestellijn_gerecht_opties` VALUES(26, 7, 9);
INSERT INTO `bestellijn_gerecht_opties` VALUES(27, 9, 9);
INSERT INTO `bestellijn_gerecht_opties` VALUES(28, 12, 10);
INSERT INTO `bestellijn_gerecht_opties` VALUES(29, 10, 10);
INSERT INTO `bestellijn_gerecht_opties` VALUES(30, 8, 10);
INSERT INTO `bestellijn_gerecht_opties` VALUES(31, 12, 11);
INSERT INTO `bestellijn_gerecht_opties` VALUES(32, 7, 11);
INSERT INTO `bestellijn_gerecht_opties` VALUES(33, 11, 11);
INSERT INTO `bestellijn_gerecht_opties` VALUES(34, 12, 12);
INSERT INTO `bestellijn_gerecht_opties` VALUES(35, 5, 12);
INSERT INTO `bestellijn_gerecht_opties` VALUES(36, 11, 12);
INSERT INTO `bestellijn_gerecht_opties` VALUES(37, 12, 13);
INSERT INTO `bestellijn_gerecht_opties` VALUES(38, 5, 13);
INSERT INTO `bestellijn_gerecht_opties` VALUES(39, 9, 13);
INSERT INTO `bestellijn_gerecht_opties` VALUES(40, 12, 14);
INSERT INTO `bestellijn_gerecht_opties` VALUES(41, 7, 14);
INSERT INTO `bestellijn_gerecht_opties` VALUES(42, 8, 14);
INSERT INTO `bestellijn_gerecht_opties` VALUES(43, 12, 15);
INSERT INTO `bestellijn_gerecht_opties` VALUES(44, 7, 15);
INSERT INTO `bestellijn_gerecht_opties` VALUES(45, 9, 15);
INSERT INTO `bestellijn_gerecht_opties` VALUES(46, 12, 16);
INSERT INTO `bestellijn_gerecht_opties` VALUES(47, 5, 16);
INSERT INTO `bestellijn_gerecht_opties` VALUES(48, 8, 16);
INSERT INTO `bestellijn_gerecht_opties` VALUES(49, 12, 17);
INSERT INTO `bestellijn_gerecht_opties` VALUES(50, 5, 17);
INSERT INTO `bestellijn_gerecht_opties` VALUES(51, 9, 17);
INSERT INTO `bestellijn_gerecht_opties` VALUES(52, 12, 18);
INSERT INTO `bestellijn_gerecht_opties` VALUES(53, 7, 18);
INSERT INTO `bestellijn_gerecht_opties` VALUES(54, 8, 18);
INSERT INTO `bestellijn_gerecht_opties` VALUES(55, 12, 19);
INSERT INTO `bestellijn_gerecht_opties` VALUES(56, 10, 19);
INSERT INTO `bestellijn_gerecht_opties` VALUES(57, 11, 19);
INSERT INTO `bestellijn_gerecht_opties` VALUES(58, 12, 20);
INSERT INTO `bestellijn_gerecht_opties` VALUES(59, 7, 20);
INSERT INTO `bestellijn_gerecht_opties` VALUES(60, 11, 20);
INSERT INTO `bestellijn_gerecht_opties` VALUES(61, 13, 21);
INSERT INTO `bestellijn_gerecht_opties` VALUES(62, 7, 21);
INSERT INTO `bestellijn_gerecht_opties` VALUES(63, 8, 21);
INSERT INTO `bestellijn_gerecht_opties` VALUES(64, 12, 22);
INSERT INTO `bestellijn_gerecht_opties` VALUES(65, 5, 22);
INSERT INTO `bestellijn_gerecht_opties` VALUES(66, 9, 22);
INSERT INTO `bestellijn_gerecht_opties` VALUES(67, 12, 23);
INSERT INTO `bestellijn_gerecht_opties` VALUES(68, 5, 23);
INSERT INTO `bestellijn_gerecht_opties` VALUES(69, 9, 23);
INSERT INTO `bestellijn_gerecht_opties` VALUES(70, 12, 24);
INSERT INTO `bestellijn_gerecht_opties` VALUES(71, 5, 24);
INSERT INTO `bestellijn_gerecht_opties` VALUES(72, 9, 24);
INSERT INTO `bestellijn_gerecht_opties` VALUES(73, 12, 25);
INSERT INTO `bestellijn_gerecht_opties` VALUES(74, 5, 25);
INSERT INTO `bestellijn_gerecht_opties` VALUES(75, 9, 25);
INSERT INTO `bestellijn_gerecht_opties` VALUES(76, 12, 26);
INSERT INTO `bestellijn_gerecht_opties` VALUES(77, 5, 26);
INSERT INTO `bestellijn_gerecht_opties` VALUES(78, 9, 26);
INSERT INTO `bestellijn_gerecht_opties` VALUES(79, 12, 27);
INSERT INTO `bestellijn_gerecht_opties` VALUES(80, 5, 27);
INSERT INTO `bestellijn_gerecht_opties` VALUES(81, 9, 27);
INSERT INTO `bestellijn_gerecht_opties` VALUES(82, 12, 28);
INSERT INTO `bestellijn_gerecht_opties` VALUES(83, 5, 28);
INSERT INTO `bestellijn_gerecht_opties` VALUES(84, 9, 28);
INSERT INTO `bestellijn_gerecht_opties` VALUES(85, 12, 29);
INSERT INTO `bestellijn_gerecht_opties` VALUES(86, 5, 29);
INSERT INTO `bestellijn_gerecht_opties` VALUES(87, 9, 29);
INSERT INTO `bestellijn_gerecht_opties` VALUES(88, 12, 30);
INSERT INTO `bestellijn_gerecht_opties` VALUES(89, 5, 30);
INSERT INTO `bestellijn_gerecht_opties` VALUES(90, 9, 30);
INSERT INTO `bestellijn_gerecht_opties` VALUES(91, 12, 31);
INSERT INTO `bestellijn_gerecht_opties` VALUES(92, 5, 31);
INSERT INTO `bestellijn_gerecht_opties` VALUES(93, 9, 31);
INSERT INTO `bestellijn_gerecht_opties` VALUES(94, 12, 32);
INSERT INTO `bestellijn_gerecht_opties` VALUES(95, 7, 32);
INSERT INTO `bestellijn_gerecht_opties` VALUES(96, 8, 32);
INSERT INTO `bestellijn_gerecht_opties` VALUES(97, 12, 33);
INSERT INTO `bestellijn_gerecht_opties` VALUES(98, 5, 33);
INSERT INTO `bestellijn_gerecht_opties` VALUES(99, 9, 33);
INSERT INTO `bestellijn_gerecht_opties` VALUES(100, 12, 34);
INSERT INTO `bestellijn_gerecht_opties` VALUES(101, 5, 34);
INSERT INTO `bestellijn_gerecht_opties` VALUES(102, 9, 34);
INSERT INTO `bestellijn_gerecht_opties` VALUES(103, 12, 35);
INSERT INTO `bestellijn_gerecht_opties` VALUES(104, 5, 35);
INSERT INTO `bestellijn_gerecht_opties` VALUES(105, 9, 35);
INSERT INTO `bestellijn_gerecht_opties` VALUES(106, 13, 36);
INSERT INTO `bestellijn_gerecht_opties` VALUES(107, 5, 36);
INSERT INTO `bestellijn_gerecht_opties` VALUES(108, 9, 36);
INSERT INTO `bestellijn_gerecht_opties` VALUES(109, 12, 37);
INSERT INTO `bestellijn_gerecht_opties` VALUES(110, 5, 37);
INSERT INTO `bestellijn_gerecht_opties` VALUES(111, 9, 37);
INSERT INTO `bestellijn_gerecht_opties` VALUES(112, 12, 38);
INSERT INTO `bestellijn_gerecht_opties` VALUES(113, 5, 38);
INSERT INTO `bestellijn_gerecht_opties` VALUES(114, 9, 38);
INSERT INTO `bestellijn_gerecht_opties` VALUES(115, 12, 39);
INSERT INTO `bestellijn_gerecht_opties` VALUES(116, 5, 39);
INSERT INTO `bestellijn_gerecht_opties` VALUES(117, 9, 39);
INSERT INTO `bestellijn_gerecht_opties` VALUES(118, 12, 40);
INSERT INTO `bestellijn_gerecht_opties` VALUES(119, 5, 40);
INSERT INTO `bestellijn_gerecht_opties` VALUES(120, 9, 40);
INSERT INTO `bestellijn_gerecht_opties` VALUES(121, 12, 41);
INSERT INTO `bestellijn_gerecht_opties` VALUES(122, 5, 41);
INSERT INTO `bestellijn_gerecht_opties` VALUES(123, 9, 41);
INSERT INTO `bestellijn_gerecht_opties` VALUES(124, 12, 42);
INSERT INTO `bestellijn_gerecht_opties` VALUES(125, 7, 42);
INSERT INTO `bestellijn_gerecht_opties` VALUES(126, 8, 42);
INSERT INTO `bestellijn_gerecht_opties` VALUES(127, 12, 43);
INSERT INTO `bestellijn_gerecht_opties` VALUES(128, 5, 43);
INSERT INTO `bestellijn_gerecht_opties` VALUES(129, 9, 43);

-- --------------------------------------------------------

--
-- Table structure for table `bestelling`
--

CREATE TABLE `bestelling` (
  `id` int(11) NOT NULL auto_increment,
  `besteltijd` bigint(20) unsigned default NULL COMMENT 'unix timestamp',
  `levertijd` bigint(20) unsigned default NULL,
  `bestelling_nummer` bigint(20) unsigned NOT NULL,
  `leverwijze_id` int(11) unsigned NOT NULL,
  `totaal_prijs` decimal(4,2) NOT NULL,
  PRIMARY KEY  (`id`,`leverwijze_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `bestelling`
--

INSERT INTO `bestelling` VALUES(6, 1280321090, 1280323490, 20100728144400011, 2, '15.00');
INSERT INTO `bestelling` VALUES(5, 1280318692, 1280321092, 20100728140400011, 2, '42.60');
INSERT INTO `bestelling` VALUES(4, 1280087605, 1280090005, 20100725215300004, 2, '26.80');
INSERT INTO `bestelling` VALUES(7, 1280321528, 1280323928, 20100728145200011, 2, '18.52');
INSERT INTO `bestelling` VALUES(8, 1280359066, 1280361466, 20100729011700004, 2, '20.40');
INSERT INTO `bestelling` VALUES(9, 1280359315, 1280361715, 20100729012100004, 2, '13.00');
INSERT INTO `bestelling` VALUES(10, 1280359400, 1280361800, 20100729012300004, 2, '30.96');
INSERT INTO `bestelling` VALUES(11, 1280359476, 1280361876, 20100729012400004, 2, '24.77');
INSERT INTO `bestelling` VALUES(12, 1280359828, 1280362228, 20100729013000004, 2, '48.00');
INSERT INTO `bestelling` VALUES(13, 1280442001, 1280431200, 20100730002000009, 2, '33.00');
INSERT INTO `bestelling` VALUES(14, 1280442835, 1280439000, 20100730003300009, 2, '34.00');
INSERT INTO `bestelling` VALUES(15, 1280445921, 1280444400, 20100730012500009, 2, '33.00');
INSERT INTO `bestelling` VALUES(16, 1280445937, 1280445000, 20100730012500009, 2, '33.00');
INSERT INTO `bestelling` VALUES(17, 1280446028, 1280492400, 20100730012700009, 2, '33.00');
INSERT INTO `bestelling` VALUES(18, 1280446194, 1280445000, 20100730012900009, 2, '33.00');
INSERT INTO `bestelling` VALUES(19, 1280446823, 1280535600, 20100730014000009, 2, '33.00');
INSERT INTO `bestelling` VALUES(20, 1280446917, 1280445600, 20100730014100009, 2, '33.00');
INSERT INTO `bestelling` VALUES(21, 1280446998, 1280669400, 20100730014300009, 2, '33.00');
INSERT INTO `bestelling` VALUES(22, 1280665399, 1282828800, 20100801142300009, 2, '27.52');
INSERT INTO `bestelling` VALUES(23, 1281061337, 1282327200, 20100806042200009, 2, '53.65');
INSERT INTO `bestelling` VALUES(24, 1281198135, 1283011200, 20100807182200009, 2, '24.00');
INSERT INTO `bestelling` VALUES(25, 1281309386, 1282866600, 20100809011600004, 1, '20.70');
INSERT INTO `bestelling` VALUES(26, 1281339037, 1281341437, 20100809093000009, 1, '23.93');
INSERT INTO `bestelling` VALUES(27, 1281403077, 1282787400, 20100810031700014, 1, '9.25');

-- --------------------------------------------------------

--
-- Table structure for table `bestelling_lijn`
--

CREATE TABLE `bestelling_lijn` (
  `id` int(11) NOT NULL auto_increment,
  `bestelling_id` int(3) NOT NULL,
  `lijn_naam` varchar(45) default NULL,
  `lijn_aantal` int(11) default NULL,
  `lijn_prijs` decimal(4,2) NOT NULL,
  PRIMARY KEY  (`id`,`bestelling_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `bestelling_lijn`
--

INSERT INTO `bestelling_lijn` VALUES(11, 5, 'Pizza Quattro Formaggio', 1, '16.20');
INSERT INTO `bestelling_lijn` VALUES(10, 5, 'Pizza Salami', 1, '14.40');
INSERT INTO `bestelling_lijn` VALUES(9, 4, 'Pizza Quattro Formaggio', 1, '10.80');
INSERT INTO `bestelling_lijn` VALUES(8, 4, 'Pizza Salami', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(7, 4, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(12, 5, 'Pizza Salami', 1, '12.00');
INSERT INTO `bestelling_lijn` VALUES(13, 6, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(14, 7, 'Pizza Salami', 1, '11.52');
INSERT INTO `bestelling_lijn` VALUES(15, 8, 'Pizza Salami', 1, '9.60');
INSERT INTO `bestelling_lijn` VALUES(16, 8, 'Pizza Quattro Formaggio', 1, '10.80');
INSERT INTO `bestelling_lijn` VALUES(17, 9, 'Pizza Salami', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(18, 10, 'Pizza Quattro Formaggio', 1, '12.96');
INSERT INTO `bestelling_lijn` VALUES(19, 10, 'Pizza Salami', 1, '18.00');
INSERT INTO `bestelling_lijn` VALUES(20, 11, 'Pizza Salami', 1, '14.40');
INSERT INTO `bestelling_lijn` VALUES(21, 11, 'Pizza Quattro Formaggio', 1, '10.37');
INSERT INTO `bestelling_lijn` VALUES(22, 12, 'Pizza Prosciutto', 6, '48.00');
INSERT INTO `bestelling_lijn` VALUES(23, 13, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(24, 14, 'Pizza Quattro Formaggio', 1, '9.00');
INSERT INTO `bestelling_lijn` VALUES(25, 15, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(26, 15, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(27, 17, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(28, 18, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(29, 19, 'Pizza Prosciutto', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(30, 20, 'Pizza Salami', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(31, 21, 'Pizza Salami', 1, '8.00');
INSERT INTO `bestelling_lijn` VALUES(32, 22, 'Pizza Prosciutto', 1, '11.52');
INSERT INTO `bestelling_lijn` VALUES(33, 22, 'Pizza Salami', 2, '16.00');
INSERT INTO `bestelling_lijn` VALUES(34, 23, 'Pizza Prosciutto', 2, '18.50');
INSERT INTO `bestelling_lijn` VALUES(35, 23, 'Pizza Salami', 3, '27.75');
INSERT INTO `bestelling_lijn` VALUES(36, 23, 'Pizza Prosciutto', 1, '7.40');
INSERT INTO `bestelling_lijn` VALUES(37, 24, 'Pizza Salami', 1, '6.20');
INSERT INTO `bestelling_lijn` VALUES(38, 24, 'Pizza Quattro Formaggio', 1, '10.55');
INSERT INTO `bestelling_lijn` VALUES(39, 24, 'Pizza Prosciutto', 1, '7.25');
INSERT INTO `bestelling_lijn` VALUES(40, 25, 'Pizza Prosciutto', 2, '14.50');
INSERT INTO `bestelling_lijn` VALUES(41, 25, 'Pizza Salami', 1, '6.20');
INSERT INTO `bestelling_lijn` VALUES(42, 26, 'Pizza Salami', 1, '8.93');
INSERT INTO `bestelling_lijn` VALUES(43, 27, 'Pizza Prosciutto', 1, '7.25');

-- --------------------------------------------------------

--
-- Table structure for table `company_images`
--

CREATE TABLE `company_images` (
  `id` int(4) NOT NULL auto_increment,
  `logo` varchar(255) default NULL,
  `icon` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `company_images`
--


-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(4) NOT NULL auto_increment,
  `vraag` mediumtext,
  `antwoord` longtext,
  `volgorde` int(3) default NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `zoek_index` (`vraag`,`antwoord`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='De veelgestelde vragen tabel' AUTO_INCREMENT=20 ;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` VALUES(14, 'Bevatten jullie producten noten', 'Nee, noten worden niet gebruikt bij de vervaardiging van een van onze producten.', 1);
INSERT INTO `faqs` VALUES(13, 'Bevatten jullie producten pinda''s of pinda-olie?', 'Nee, onze producten bevatten geen pinda''s of pinda-olie.', 2);
INSERT INTO `faqs` VALUES(15, 'Bevatten uw pizzabodems soja?', 'Alle pizza bodems bevatten soja-olie.', 3);
INSERT INTO `faqs` VALUES(16, 'Moet ik mij registreren voor Pi(a)zza della Signoria?', 'Registratie is inderdaad verplicht. Dit om er voor te zorgen dat de onderlinge relatie correct blijft.', 0);
INSERT INTO `faqs` VALUES(17, 'Ik kan geen pizza meer bestellen', 'Dat is mogelijk. Hoogstwaarschijnlijk staat er nog een rekening van u bij ons open. Gelieve zo snel mogelijk contact met ons op te nemen om dit op te lossen.', 4);
INSERT INTO `faqs` VALUES(18, 'Kan ik ook een bestelling op voorhand reserveren via uw site', 'Reserveren van een bestelling is inderdaad mogelijk. Dit is zeker aan te raden bij grote bestellingen.', 5);
INSERT INTO `faqs` VALUES(19, 'Hoe lang duurt het voordat mijn bestelling bij mij aankomt?', 'Het kan tussen de 20 en 45 minuten duren voordat je uw bestelling ontvangt.', 6);

-- --------------------------------------------------------

--
-- Table structure for table `gastenboek`
--

CREATE TABLE `gastenboek` (
  `id` int(3) NOT NULL auto_increment,
  `naam` varchar(50) collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  `bericht` text collate utf8_unicode_ci NOT NULL,
  `post_tijd` bigint(20) NOT NULL,
  `ip` varchar(15) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `gastenboek`
--

INSERT INTO `gastenboek` VALUES(1, 'Milo van Loon', 'milo@email.com', 'Het eerste berichtje', 1281197354, '81.246.215.239');
INSERT INTO `gastenboek` VALUES(2, 'Milo van Loon', 'milo@email.com', 'jjl', 1281198388, '81.246.215.239');
INSERT INTO `gastenboek` VALUES(3, 'Milo van Loon', 'milo@email.com', '@1 Het derde berichtje', 1281198430, '81.246.215.239');
INSERT INTO `gastenboek` VALUES(4, 'Milo van Loon', 'milo@email.com', 'Blijven testen\r\n', 1281389925, '213.219.153.185');
INSERT INTO `gastenboek` VALUES(5, 'VDAB Dendermonde', 'vdab@opleiding.be', 'Altijd maar testen', 1281422834, '81.241.228.203');

-- --------------------------------------------------------

--
-- Table structure for table `gebruikers`
--

CREATE TABLE `gebruikers` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  `login_naam` varchar(45) default NULL,
  `login_wachtwoord` varchar(45) default NULL,
  `sesam` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `gebruikers`
--

INSERT INTO `gebruikers` VALUES(13, 'Milo', 'admin', '7288edd0fc3ffcbe93a0cf06e3568e28521687bc', 'test123');

-- --------------------------------------------------------

--
-- Table structure for table `gerecht`
--

CREATE TABLE `gerecht` (
  `id` int(11) NOT NULL auto_increment,
  `menu_id` int(11) NOT NULL,
  `naam` tinytext NOT NULL,
  `code` varchar(4) NOT NULL,
  `basisprijs` decimal(3,2) NOT NULL,
  `omschrijving` mediumtext NOT NULL,
  `image` varchar(255) default NULL,
  PRIMARY KEY  (`id`,`menu_id`),
  KEY `fk_gerecht_menu1` (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `gerecht`
--

INSERT INTO `gerecht` VALUES(1, 4, 'Pizza Prosciutto', '1001', '6.00', 'simpele ham pizza', 'Pizza_Prosciutto.jpg');
INSERT INTO `gerecht` VALUES(2, 4, 'Pizza Salami', '1002', '4.95', 'simpele salami pizza', 'Pizza_Salami.jpg');
INSERT INTO `gerecht` VALUES(4, 4, 'Pizza Quattro Formaggio', '1004', '7.60', 'Pizza met 4 verschillende kazen', 'Pizza_Quattro_Stagioni.jpg');
INSERT INTO `gerecht` VALUES(5, 0, '', '', '0.00', '', '');
INSERT INTO `gerecht` VALUES(6, 0, '', '', '0.00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `gerecht_bestanddeel`
--

CREATE TABLE `gerecht_bestanddeel` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `gerecht_id` int(11) NOT NULL,
  `bestanddeel_id` int(11) NOT NULL,
  `op_basis` tinyint(1) default NULL,
  PRIMARY KEY  (`id`,`gerecht_id`,`bestanddeel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `gerecht_bestanddeel`
--

INSERT INTO `gerecht_bestanddeel` VALUES(1, 1, 56, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(2, 1, 57, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(3, 1, 58, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(4, 2, 56, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(5, 2, 57, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(6, 2, 59, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(7, 4, 0, 0);
INSERT INTO `gerecht_bestanddeel` VALUES(8, 4, 0, 0);
INSERT INTO `gerecht_bestanddeel` VALUES(9, 4, 0, 0);
INSERT INTO `gerecht_bestanddeel` VALUES(14, 4, 62, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(13, 4, 61, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(15, 4, 63, 1);
INSERT INTO `gerecht_bestanddeel` VALUES(16, 4, 64, 1);

-- --------------------------------------------------------

--
-- Table structure for table `gerecht_gerecht_opties`
--

CREATE TABLE `gerecht_gerecht_opties` (
  `id` int(11) NOT NULL auto_increment,
  `gerecht_id` int(3) NOT NULL,
  `gerecht_optie_id` int(3) NOT NULL,
  PRIMARY KEY  (`id`,`gerecht_id`,`gerecht_optie_id`),
  KEY `fk_gerecht_gerecht_opties_gerecht_opties1` (`gerecht_optie_id`),
  KEY `fk_gerecht_gerecht_opties_gerecht_bestanddeel1` (`gerecht_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gerecht_gerecht_opties`
--


-- --------------------------------------------------------

--
-- Table structure for table `gerecht_opties`
--

CREATE TABLE `gerecht_opties` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `gerecht_opties`
--

INSERT INTO `gerecht_opties` VALUES(1, 'Grootte');
INSERT INTO `gerecht_opties` VALUES(2, 'Vorm');
INSERT INTO `gerecht_opties` VALUES(3, 'Bodem');

-- --------------------------------------------------------

--
-- Table structure for table `in_seizoen`
--

CREATE TABLE `in_seizoen` (
  `id` int(11) NOT NULL auto_increment,
  `bestanddeel_id` int(3) NOT NULL,
  `maand` int(2) default NULL,
  PRIMARY KEY  (`id`,`bestanddeel_id`),
  KEY `fk_in_seizoen_bestanddeel1` (`bestanddeel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `in_seizoen`
--


-- --------------------------------------------------------

--
-- Table structure for table `klant`
--

CREATE TABLE `klant` (
  `id` int(11) NOT NULL auto_increment,
  `wachtwoord` varchar(45) default NULL,
  `achternaam` varchar(200) NOT NULL,
  `voornaam` varchar(45) NOT NULL,
  `straat` varchar(45) NOT NULL,
  `straat_nummer` varchar(45) NOT NULL,
  `nummer_bus` varchar(45) default NULL,
  `lokatie_id` int(15) NOT NULL,
  `tel_vast` varchar(45) default NULL,
  `tel_gsm` varchar(45) default NULL,
  `email` varchar(45) default NULL,
  `aanmaakdatum` int(11) default NULL,
  `geblokkeerd` tinyint(1) default NULL COMMENT 'Heeft klant alle openstaande rekeningen betaald?\n',
  `promotie` tinyint(1) default NULL,
  PRIMARY KEY  (`id`,`lokatie_id`),
  KEY `fk_klant_klant_bestelling1` (`id`),
  KEY `fk_klant_lokatie1` (`lokatie_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Deze tabel bevat de gegevens over de klanten' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `klant`
--

INSERT INTO `klant` VALUES(4, '346f08db76374ad1c8f43ff591aee670b452761f', 'van Loon', 'Milo', 'stokthoekstraat', '4', '', 417, '05431', '051654', 'vichingo.sl@gmail.com', 1278375600, 0, 1);
INSERT INTO `klant` VALUES(5, 'a8da9cad44f6114c16e7a052878a8dc106a740dd', 'Colman', 'Caroline', 'Hertjen', '32', '', 10, '1254852645', '1254258654', 'vichingo@hotmail.com', 1278961113, 0, 0);
INSERT INTO `klant` VALUES(8, 'a8da9cad44f6114c16e7a052878a8dc106a740dd', 'de ruiter', 'Bart', 'kerkstraat', '98', '', 404, '0567483294', '1234567890', 'test@test.com', 1278973554, 0, 0);
INSERT INTO `klant` VALUES(7, 'a8da9cad44f6114c16e7a052878a8dc106a740dd', 'Blatter', 'Kees', 'kempstraat', '45', '', 427, '2154365214', '7856954259', 'test@test.be', 1278971509, 0, 0);
INSERT INTO `klant` VALUES(9, '346f08db76374ad1c8f43ff591aee670b452761f', 'van Loon', 'Milo', 'meir', '23', '', 1, '1254254875', '2568452153', 'milo@email.com', 1280249693, 0, 0);
INSERT INTO `klant` VALUES(11, '346f08db76374ad1c8f43ff591aee670b452761f', 'ten Cate', 'Henk', 'kerkstraat', '32', '', 404, '1254876523', '1254875963', 'henk@email.com', 1280271259, 0, 0);
INSERT INTO `klant` VALUES(12, '963bee8098bb8160b003112c51ecbeb3c6ee0c2b', 'Dendermonde', 'VDAB', 'Oude vest', '17', '', 435, '0123456789', '0123456789', 'vdab@opleiding.be', 1281343944, 0, 0);
INSERT INTO `klant` VALUES(13, '963bee8098bb8160b003112c51ecbeb3c6ee0c2b', 'Dendermonde', 'VDAB', 'OUde vest', '17', '', 435, '5434356543', '4354678564', 'vdab@opleiding.be', 1281344858, 0, 0);
INSERT INTO `klant` VALUES(14, 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'vetbek', 'Kees', 'blblastraat', '45', '', 402, '0125412541', '1254852659', 'kees@email.com', 1281390100, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `klant_bestelling`
--

CREATE TABLE `klant_bestelling` (
  `id` int(11) NOT NULL auto_increment,
  `klant_id` int(11) unsigned NOT NULL,
  `bestelling_id` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`,`klant_id`,`bestelling_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `klant_bestelling`
--

INSERT INTO `klant_bestelling` VALUES(4, 4, 4);
INSERT INTO `klant_bestelling` VALUES(5, 11, 5);
INSERT INTO `klant_bestelling` VALUES(6, 11, 6);
INSERT INTO `klant_bestelling` VALUES(7, 11, 7);
INSERT INTO `klant_bestelling` VALUES(8, 4, 8);
INSERT INTO `klant_bestelling` VALUES(9, 4, 9);
INSERT INTO `klant_bestelling` VALUES(10, 4, 10);
INSERT INTO `klant_bestelling` VALUES(11, 4, 11);
INSERT INTO `klant_bestelling` VALUES(12, 4, 12);
INSERT INTO `klant_bestelling` VALUES(13, 9, 13);
INSERT INTO `klant_bestelling` VALUES(14, 9, 14);
INSERT INTO `klant_bestelling` VALUES(15, 9, 15);
INSERT INTO `klant_bestelling` VALUES(16, 9, 15);
INSERT INTO `klant_bestelling` VALUES(17, 9, 17);
INSERT INTO `klant_bestelling` VALUES(18, 9, 18);
INSERT INTO `klant_bestelling` VALUES(19, 9, 19);
INSERT INTO `klant_bestelling` VALUES(20, 9, 20);
INSERT INTO `klant_bestelling` VALUES(21, 9, 21);
INSERT INTO `klant_bestelling` VALUES(22, 9, 22);
INSERT INTO `klant_bestelling` VALUES(23, 9, 23);
INSERT INTO `klant_bestelling` VALUES(24, 9, 24);
INSERT INTO `klant_bestelling` VALUES(25, 4, 25);
INSERT INTO `klant_bestelling` VALUES(26, 9, 26);
INSERT INTO `klant_bestelling` VALUES(27, 14, 27);

-- --------------------------------------------------------

--
-- Table structure for table `leveren_in`
--

CREATE TABLE `leveren_in` (
  `id` int(11) NOT NULL auto_increment,
  `lokatie_id` int(11) NOT NULL,
  `resto_id` int(11) NOT NULL,
  `leveringkost` decimal(4,2) NOT NULL,
  PRIMARY KEY  (`id`,`lokatie_id`,`resto_id`),
  KEY `fk_leveren_in_lokatie1` (`lokatie_id`),
  KEY `fk_leveren_in_resto1` (`resto_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `leveren_in`
--

INSERT INTO `leveren_in` VALUES(1, 403, 1, '1.00');
INSERT INTO `leveren_in` VALUES(2, 415, 1, '5.00');
INSERT INTO `leveren_in` VALUES(3, 402, 1, '2.00');
INSERT INTO `leveren_in` VALUES(4, 409, 1, '7.00');
INSERT INTO `leveren_in` VALUES(5, 1, 1, '15.00');
INSERT INTO `leveren_in` VALUES(6, 417, 1, '5.00');
INSERT INTO `leveren_in` VALUES(7, 404, 1, '7.00');
INSERT INTO `leveren_in` VALUES(8, 435, 1, '10.00');

-- --------------------------------------------------------

--
-- Table structure for table `leverwijze`
--

CREATE TABLE `leverwijze` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `leverwijze`
--

INSERT INTO `leverwijze` VALUES(1, 'ophalen');
INSERT INTO `leverwijze` VALUES(2, 'bezorgen');

-- --------------------------------------------------------

--
-- Table structure for table `lijn_bestanddeel`
--

CREATE TABLE `lijn_bestanddeel` (
  `id` int(11) NOT NULL auto_increment,
  `bestelling_lijn_id` int(3) NOT NULL,
  `gerecht_bestanddeel_id` int(3) NOT NULL,
  `optellen` tinyint(1) default NULL,
  PRIMARY KEY  (`id`,`gerecht_bestanddeel_id`,`bestelling_lijn_id`),
  KEY `fk_lijn_bestanddeel_bestelling_lijn1` (`bestelling_lijn_id`),
  KEY `fk_lijn_bestanddeel_gerecht_bestanddeel1` (`gerecht_bestanddeel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lijn_bestanddeel`
--


-- --------------------------------------------------------

--
-- Table structure for table `lokatie`
--

CREATE TABLE `lokatie` (
  `id` bigint(15) NOT NULL auto_increment,
  `alpha` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `longitude` decimal(12,10) default NULL,
  `latitude` decimal(12,10) default NULL,
  `code` varchar(30) character set utf8 collate utf8_unicode_ci NOT NULL,
  `name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `provincie_id` bigint(15) NOT NULL default '0',
  `lokatie_zonenummer_id` bigint(15) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `region` (`provincie_id`),
  KEY `code` (`code`),
  KEY `alpha` (`alpha`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=14297 ;

--
-- Dumping data for table `lokatie`
--

INSERT INTO `lokatie` VALUES(2753, 'vodele', '4.7319823000', '50.1700235000', '5680', 'Vodelée', 10, 0);
INSERT INTO `lokatie` VALUES(2752, 'vaucelles', '4.7435856000', '50.1132065000', '5680', 'Vaucelles', 10, 0);
INSERT INTO `lokatie` VALUES(2751, 'soulme', '4.7362843000', '50.1875880000', '5680', 'Soulme', 10, 0);
INSERT INTO `lokatie` VALUES(2750, 'romere', '4.6751612000', '50.1349753000', '5680', 'Romerée', 10, 0);
INSERT INTO `lokatie` VALUES(2749, 'niverle', '4.7009273000', '50.1176372000', '5680', 'Niverlée', 10, 0);
INSERT INTO `lokatie` VALUES(2748, 'matagne-la-petite', '4.6466011000', '50.1187174000', '5680', 'Matagne-la-Petite', 10, 0);
INSERT INTO `lokatie` VALUES(2747, 'matagne-la-grande', '4.6230829000', '50.1171994000', '5680', 'Matagne-la-Grande', 10, 0);
INSERT INTO `lokatie` VALUES(2746, 'gochene', '4.7598303000', '50.1838389000', '5680', 'Gochenée', 10, 0);
INSERT INTO `lokatie` VALUES(2745, 'gimne', '4.7141846000', '50.1322987000', '5680', 'Gimnée', 10, 0);
INSERT INTO `lokatie` VALUES(2744, 'doische', '4.7451565000', '50.1354941000', '5680', 'Doische', 10, 0);
INSERT INTO `lokatie` VALUES(2743, 'viroinval', '4.6059942000', '50.0714722000', '5670', 'Viroinval', 10, 0);
INSERT INTO `lokatie` VALUES(2742, 'vierves-sur-viroin', '4.6342325000', '50.0803073000', '5670', 'Vierves-sur-Viroin', 10, 0);
INSERT INTO `lokatie` VALUES(2741, 'treignes', '4.6692223000', '50.0928419000', '5670', 'Treignes', 10, 0);
INSERT INTO `lokatie` VALUES(2740, 'olloy-sur-viroin', '4.6073551000', '50.0734406000', '5670', 'Olloy-sur-Viroin', 10, 0);
INSERT INTO `lokatie` VALUES(2739, 'oignies-en-thirache', '4.6390911000', '50.0237916000', '5670', 'Oignies-en-Thiérache', 10, 0);
INSERT INTO `lokatie` VALUES(2738, 'nismes', '4.5483014000', '50.0747916000', '5670', 'Nismes', 10, 0);
INSERT INTO `lokatie` VALUES(2737, 'maze', '4.6962280000', '50.1013002000', '5670', 'Mazée', 10, 0);
INSERT INTO `lokatie` VALUES(2736, 'le-mesnil', '4.6714057000', '50.0315066000', '5670', 'Le Mesnil', 10, 0);
INSERT INTO `lokatie` VALUES(2735, 'dourbes', '4.5911852000', '50.0915244000', '5670', 'Dourbes', 10, 0);
INSERT INTO `lokatie` VALUES(2734, 'presgaux', '4.4198508000', '50.0251800000', '5660', 'Presgaux', 10, 0);
INSERT INTO `lokatie` VALUES(2733, 'petite-chapelle', '4.5051169000', '49.9501137000', '5660', 'Petite-Chapelle', 10, 0);
INSERT INTO `lokatie` VALUES(2732, 'petigny', '4.5329342000', '50.0588019000', '5660', 'Petigny', 10, 0);
INSERT INTO `lokatie` VALUES(2731, 'pesche', '4.4587268000', '50.0423745000', '5660', 'Pesche', 10, 0);
INSERT INTO `lokatie` VALUES(2730, 'mariembourg', '4.5221759000', '50.0949510000', '5660', 'Mariembourg', 10, 0);
INSERT INTO `lokatie` VALUES(2729, 'gonrieux', '4.4262188000', '50.0360473000', '5660', 'Gonrieux', 10, 0);
INSERT INTO `lokatie` VALUES(2728, 'frasnes-namur', '4.5089143000', '50.0767425000', '5660', 'Frasnes, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2727, 'dailly', '4.4357088000', '50.0574819000', '5660', 'Dailly', 10, 0);
INSERT INTO `lokatie` VALUES(2726, 'cul-des-sarts', '4.4546930000', '49.9620803000', '5660', 'Cul-des-Sarts', 10, 0);
INSERT INTO `lokatie` VALUES(2725, 'couvin', '4.4971552000', '50.0516936000', '5660', 'Couvin', 10, 0);
INSERT INTO `lokatie` VALUES(2724, 'brly-de-pesche', '4.4607012000', '50.0009904000', '5660', 'Brûly-de-Pesche', 10, 0);
INSERT INTO `lokatie` VALUES(2723, 'brly', '4.5276734000', '49.9700584000', '5660', 'Brûly', 10, 0);
INSERT INTO `lokatie` VALUES(2722, 'boussu-en-fagne', '4.4718043000', '50.0762654000', '5660', 'Boussu-en-Fagne', 10, 0);
INSERT INTO `lokatie` VALUES(2721, 'aublain', '4.4090755000', '50.0675767000', '5660', 'Aublain', 10, 0);
INSERT INTO `lokatie` VALUES(2720, 'thy-le-chteau', '4.4259158000', '50.2823570000', '5651', 'Thy-le-Château', 10, 0);
INSERT INTO `lokatie` VALUES(2719, 'tarcienne', '4.4978154000', '50.3121148000', '5651', 'Tarcienne', 10, 0);
INSERT INTO `lokatie` VALUES(2718, 'somze', '4.4831638000', '50.2950667000', '5651', 'Somzée', 10, 0);
INSERT INTO `lokatie` VALUES(2717, 'rogne', '4.3890376000', '50.2696666000', '5651', 'Rognée', 10, 0);
INSERT INTO `lokatie` VALUES(2716, 'laneffe', '4.4945456000', '50.2776590000', '5651', 'Laneffe', 10, 0);
INSERT INTO `lokatie` VALUES(2715, 'gourdinne', '4.4562301000', '50.2901206000', '5651', 'Gourdinne', 10, 0);
INSERT INTO `lokatie` VALUES(2714, 'berze', '4.3991598000', '50.2906721000', '5651', 'Berzée', 10, 0);
INSERT INTO `lokatie` VALUES(2713, 'yves-gomeze', '4.4942942000', '50.2394220000', '5650', 'Yves-Gomezée', 10, 0);
INSERT INTO `lokatie` VALUES(2712, 'walcourt', '4.4316899000', '50.2517267000', '5650', 'Walcourt', 10, 0);
INSERT INTO `lokatie` VALUES(2711, 'vogene', '4.4523807000', '50.2388380000', '5650', 'Vogenée', 10, 0);
INSERT INTO `lokatie` VALUES(2710, 'pry', '4.4292602000', '50.2702052000', '5650', 'Pry', 10, 0);
INSERT INTO `lokatie` VALUES(2709, 'fraire', '4.5075507000', '50.2612928000', '5650', 'Fraire', 10, 0);
INSERT INTO `lokatie` VALUES(2708, 'fontenelle', '4.3820441000', '50.2480932000', '5650', 'Fontenelle', 10, 0);
INSERT INTO `lokatie` VALUES(2707, 'clermont-namur', '4.3166534000', '50.2602509000', '5650', 'Clermont, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2706, 'chastrs', '4.4594299000', '50.2649875000', '5650', 'Chastrès', 10, 0);
INSERT INTO `lokatie` VALUES(2705, 'castillon', '4.3535680000', '50.2469600000', '5650', 'Castillon', 10, 0);
INSERT INTO `lokatie` VALUES(2704, 'stave', '4.6595389000', '50.2823372000', '5646', 'Stave', 10, 0);
INSERT INTO `lokatie` VALUES(2703, 'ermeton-sur-biert', '4.7220269000', '50.2886049000', '5644', 'Ermeton-sur-Biert', 10, 0);
INSERT INTO `lokatie` VALUES(2702, 'furnaux', '4.7035401000', '50.3074423000', '5641', 'Furnaux', 10, 0);
INSERT INTO `lokatie` VALUES(2701, 'saint-grard', '4.7402044000', '50.3459587000', '5640', 'Saint-Gérard', 10, 0);
INSERT INTO `lokatie` VALUES(2700, 'oret', '4.6155651000', '50.2998711000', '5640', 'Oret', 10, 0);
INSERT INTO `lokatie` VALUES(2699, 'mettet', '4.6579476000', '50.3201538000', '5640', 'Mettet', 10, 0);
INSERT INTO `lokatie` VALUES(2698, 'graux', '4.7188075000', '50.3256276000', '5640', 'Graux', 10, 0);
INSERT INTO `lokatie` VALUES(2697, 'biesmere', '4.6800577000', '50.2972765000', '5640', 'Biesmerée', 10, 0);
INSERT INTO `lokatie` VALUES(2696, 'biesme', '4.6084738000', '50.3341410000', '5640', 'Biesme', 10, 0);
INSERT INTO `lokatie` VALUES(2695, 'villers-deux-eglises', '4.4827135000', '50.1895479000', '5630', 'Villers-Deux-Eglises', 10, 0);
INSERT INTO `lokatie` VALUES(2694, 'soumoy', '4.4374719000', '50.1893197000', '5630', 'Soumoy', 10, 0);
INSERT INTO `lokatie` VALUES(2693, 'silenrieux', '4.4101535000', '50.2247693000', '5630', 'Silenrieux', 10, 0);
INSERT INTO `lokatie` VALUES(2692, 'senzeille', '4.4654506000', '50.1773954000', '5630', 'Senzeille', 10, 0);
INSERT INTO `lokatie` VALUES(2691, 'daussois', '4.4538610000', '50.2215797000', '5630', 'Daussois', 10, 0);
INSERT INTO `lokatie` VALUES(2690, 'cerfontaine', '4.4123064000', '50.1706980000', '5630', 'Cerfontaine', 10, 0);
INSERT INTO `lokatie` VALUES(2689, 'thy-le-bauduin', '4.5236966000', '50.2951273000', '5621', 'Thy-le-Bauduin', 10, 0);
INSERT INTO `lokatie` VALUES(2688, 'morialm', '4.5659309000', '50.2750372000', '5621', 'Morialmé', 10, 0);
INSERT INTO `lokatie` VALUES(2687, 'hanzinne', '4.5431971000', '50.3100157000', '5621', 'Hanzinne', 10, 0);
INSERT INTO `lokatie` VALUES(2686, 'hanzinelle', '4.5564457000', '50.2960690000', '5621', 'Hanzinelle', 10, 0);
INSERT INTO `lokatie` VALUES(2685, 'saint-aubin', '4.5775596000', '50.2480443000', '5620', 'Saint-Aubin', 10, 0);
INSERT INTO `lokatie` VALUES(2684, 'rose', '4.6867744000', '50.2321287000', '5620', 'Rosée', 10, 0);
INSERT INTO `lokatie` VALUES(2683, 'morville', '4.7449983000', '50.2334567000', '5620', 'Morville', 10, 0);
INSERT INTO `lokatie` VALUES(2682, 'hemptinne-lez-florennes', '4.5626703000', '50.2285443000', '5620', 'Hemptinne-lez-Florennes', 10, 0);
INSERT INTO `lokatie` VALUES(2681, 'florennes', '4.6037449000', '50.2508165000', '5620', 'Florennes', 10, 0);
INSERT INTO `lokatie` VALUES(2680, 'flavion', '4.7122250000', '50.2492740000', '5620', 'Flavion', 10, 0);
INSERT INTO `lokatie` VALUES(2679, 'corenne', '4.6787666000', '50.2522483000', '5620', 'Corenne', 10, 0);
INSERT INTO `lokatie` VALUES(2678, 'vodece', '4.5922945000', '50.1973298000', '5600', 'Vodecée', 10, 0);
INSERT INTO `lokatie` VALUES(2677, 'villers-le-gambon', '4.6080556000', '50.1901290000', '5600', 'Villers-le-Gambon', 10, 0);
INSERT INTO `lokatie` VALUES(2676, 'villers-en-fagne', '4.5839366000', '50.1465037000', '5600', 'Villers-en-Fagne', 10, 0);
INSERT INTO `lokatie` VALUES(2675, 'surice', '4.6959882000', '50.1820681000', '5600', 'Surice', 10, 0);
INSERT INTO `lokatie` VALUES(2674, 'sautour', '4.5609023000', '50.1683864000', '5600', 'Sautour', 10, 0);
INSERT INTO `lokatie` VALUES(2673, 'sart-en-fagne', '4.6192908000', '50.1577417000', '5600', 'Sart-en-Fagne', 10, 0);
INSERT INTO `lokatie` VALUES(2672, 'samart', '4.5334513000', '50.1776304000', '5600', 'Samart', 10, 0);
INSERT INTO `lokatie` VALUES(2671, 'romedenne', '4.6975298000', '50.1722966000', '5600', 'Romedenne', 10, 0);
INSERT INTO `lokatie` VALUES(2670, 'roly', '4.5394752000', '50.1354103000', '5600', 'Roly', 10, 0);
INSERT INTO `lokatie` VALUES(2669, 'philippeville', '4.5450760000', '50.1959602000', '5600', 'Philippeville', 10, 0);
INSERT INTO `lokatie` VALUES(2668, 'omeze', '4.6989402000', '50.1933782000', '5600', 'Omezée', 10, 0);
INSERT INTO `lokatie` VALUES(2667, 'neuville-philippeville', '4.5261182000', '50.1749438000', '5600', 'Neuville (Philippeville)', 10, 0);
INSERT INTO `lokatie` VALUES(2666, 'merlemont', '4.6069362000', '50.1730941000', '5600', 'Merlemont', 10, 0);
INSERT INTO `lokatie` VALUES(2665, 'jamiolle', '4.5077446000', '50.2124268000', '5600', 'Jamiolle', 10, 0);
INSERT INTO `lokatie` VALUES(2664, 'jamagne', '4.5314057000', '50.2182086000', '5600', 'Jamagne', 10, 0);
INSERT INTO `lokatie` VALUES(2663, 'franchimont', '4.6406821000', '50.1904421000', '5600', 'Franchimont', 10, 0);
INSERT INTO `lokatie` VALUES(2662, 'fagnolle', '4.5699776000', '50.1051443000', '5600', 'Fagnolle', 10, 0);
INSERT INTO `lokatie` VALUES(2661, 'sovet', '5.0352068000', '50.2955559000', '5590', 'Sovet', 10, 0);
INSERT INTO `lokatie` VALUES(2660, 'serinchamps', '5.2344473000', '50.2317957000', '5590', 'Serinchamps', 10, 0);
INSERT INTO `lokatie` VALUES(2659, 'pessoux', '5.1709303000', '50.2831200000', '5590', 'Pessoux', 10, 0);
INSERT INTO `lokatie` VALUES(2658, 'leignon', '5.1097204000', '50.2699199000', '5590', 'Leignon', 10, 0);
INSERT INTO `lokatie` VALUES(2657, 'haversin', '5.1957765000', '50.2491623000', '5590', 'Haversin', 10, 0);
INSERT INTO `lokatie` VALUES(2656, 'conneux', '5.0593659000', '50.2477883000', '5590', 'Conneux', 10, 0);
INSERT INTO `lokatie` VALUES(2655, 'ciney', '5.1003878000', '50.2963722000', '5590', 'Ciney', 10, 0);
INSERT INTO `lokatie` VALUES(2654, 'chevetogne', '5.1196680000', '50.2229563000', '5590', 'Chevetogne', 10, 0);
INSERT INTO `lokatie` VALUES(2653, 'braibant', '5.0621486000', '50.3128890000', '5590', 'Braibant', 10, 0);
INSERT INTO `lokatie` VALUES(2652, 'achne', '5.0446251000', '50.2666156000', '5590', 'Achêne', 10, 0);
INSERT INTO `lokatie` VALUES(2651, 'wavreille', '5.2484131000', '50.1210662000', '5580', 'Wavreille', 10, 0);
INSERT INTO `lokatie` VALUES(2650, 'villers-sur-lesse', '5.1130064000', '50.1519737000', '5580', 'Villers-sur-Lesse', 10, 0);
INSERT INTO `lokatie` VALUES(2649, 'rochefort', '5.2222341000', '50.1615793000', '5580', 'Rochefort', 10, 0);
INSERT INTO `lokatie` VALUES(2648, 'mont-gauthier', '5.1212394000', '50.2092963000', '5580', 'Mont-Gauthier', 10, 0);
INSERT INTO `lokatie` VALUES(2647, 'lessive', '5.1487734000', '50.1397560000', '5580', 'Lessive', 10, 0);
INSERT INTO `lokatie` VALUES(2646, 'lavaux-sainte-anne', '5.0933042000', '50.1147316000', '5580', 'Lavaux-Sainte-Anne', 10, 0);
INSERT INTO `lokatie` VALUES(2645, 'jemelle', '5.2611051000', '50.1617886000', '5580', 'Jemelle', 10, 0);
INSERT INTO `lokatie` VALUES(2644, 'han-sur-lesse', '5.1872830000', '50.1255154000', '5580', 'Han-sur-Lesse', 10, 0);
INSERT INTO `lokatie` VALUES(2643, 'eprave', '5.1618966000', '50.1410341000', '5580', 'Eprave', 10, 0);
INSERT INTO `lokatie` VALUES(2642, 'buissonville', '5.2019025000', '50.2163739000', '5580', 'Buissonville', 10, 0);
INSERT INTO `lokatie` VALUES(2641, 'ave-et-auffe', '5.1429583000', '50.1085676000', '5580', 'Ave-et-Auffe', 10, 0);
INSERT INTO `lokatie` VALUES(2640, 'willerzie', '4.8479062000', '49.9869942000', '5575', 'Willerzie', 10, 0);
INSERT INTO `lokatie` VALUES(2639, 'vencimont', '4.9216608000', '50.0320437000', '5575', 'Vencimont', 10, 0);
INSERT INTO `lokatie` VALUES(2638, 'sart-custinne', '4.9168953000', '50.0014490000', '5575', 'Sart-Custinne', 10, 0);
INSERT INTO `lokatie` VALUES(2637, 'rienne', '4.8885927000', '49.9928797000', '5575', 'Rienne', 10, 0);
INSERT INTO `lokatie` VALUES(2636, 'patignies', '4.9512729000', '50.0003491000', '5575', 'Patignies', 10, 0);
INSERT INTO `lokatie` VALUES(2635, 'malvoisin', '4.9601702000', '50.0117441000', '5575', 'Malvoisin', 10, 0);
INSERT INTO `lokatie` VALUES(2634, 'louette-saint-pierre', '4.9274160000', '49.9605522000', '5575', 'Louette-Saint-Pierre', 10, 0);
INSERT INTO `lokatie` VALUES(2633, 'louette-saint-denis', '4.9570778000', '49.9584818000', '5575', 'Louette-Saint-Denis', 10, 0);
INSERT INTO `lokatie` VALUES(2632, 'houdremont', '4.9442417000', '49.9415139000', '5575', 'Houdremont', 10, 0);
INSERT INTO `lokatie` VALUES(2631, 'gedinne', '4.9368537000', '49.9812974000', '5575', 'Gedinne', 10, 0);
INSERT INTO `lokatie` VALUES(2630, 'bourseigne-vieille', '4.8707927000', '50.0225075000', '5575', 'Bourseigne-Vieille', 10, 0);
INSERT INTO `lokatie` VALUES(2629, 'bourseigne-neuve', '4.8549694000', '50.0248424000', '5575', 'Bourseigne-Neuve', 10, 0);
INSERT INTO `lokatie` VALUES(2628, 'froidfontaine', '5.0037681000', '50.0601637000', '5576', 'Froidfontaine', 10, 0);
INSERT INTO `lokatie` VALUES(2627, 'pondrme', '5.0092269000', '50.0908324000', '5574', 'Pondrôme', 10, 0);
INSERT INTO `lokatie` VALUES(2626, 'martouzin-neuville', '5.0042404000', '50.1322773000', '5573', 'Martouzin-Neuville', 10, 0);
INSERT INTO `lokatie` VALUES(2625, 'focant', '5.0392534000', '50.1204534000', '5572', 'Focant', 10, 0);
INSERT INTO `lokatie` VALUES(2624, 'wiesme', '4.9815000000', '50.1435665000', '5571', 'Wiesme', 10, 0);
INSERT INTO `lokatie` VALUES(2623, 'winenne', '4.8984425000', '50.0996297000', '5570', 'Winenne', 10, 0);
INSERT INTO `lokatie` VALUES(2622, 'wancennes', '4.9611083000', '50.0912319000', '5570', 'Wancennes', 10, 0);
INSERT INTO `lokatie` VALUES(2621, 'vonche', '4.9791820000', '50.0612463000', '5570', 'Vonêche', 10, 0);
INSERT INTO `lokatie` VALUES(2620, 'javingue', '4.9270533000', '50.0933422000', '5570', 'Javingue', 10, 0);
INSERT INTO `lokatie` VALUES(2619, 'honnay', '5.0398336000', '50.0809206000', '5570', 'Honnay', 10, 0);
INSERT INTO `lokatie` VALUES(2618, 'feschaux', '4.9104112000', '50.1507423000', '5570', 'Feschaux', 10, 0);
INSERT INTO `lokatie` VALUES(2617, 'felenne', '4.8479679000', '50.0695166000', '5570', 'Felenne', 10, 0);
INSERT INTO `lokatie` VALUES(2616, 'dion', '4.8885998000', '50.1177785000', '5570', 'Dion', 10, 0);
INSERT INTO `lokatie` VALUES(2615, 'beauraing', '4.9580692000', '50.1093216000', '5570', 'Beauraing', 10, 0);
INSERT INTO `lokatie` VALUES(2614, 'baronville', '4.9426711000', '50.1276641000', '5570', 'Baronville', 10, 0);
INSERT INTO `lokatie` VALUES(2613, 'wanlin', '5.0658160000', '50.1476553000', '5564', 'Wanlin', 10, 0);
INSERT INTO `lokatie` VALUES(2612, 'hour', '5.0342976000', '50.1619196000', '5563', 'Hour', 10, 0);
INSERT INTO `lokatie` VALUES(2611, 'custinne', '5.0557975000', '50.2125898000', '5562', 'Custinne', 10, 0);
INSERT INTO `lokatie` VALUES(2610, 'celles-namur', '5.0154300000', '50.2298284000', '5561', 'Celles, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2609, 'mesnil-saint-blaise', '4.8850015000', '50.1669792000', '5560', 'Mesnil-Saint-Blaise', 10, 0);
INSERT INTO `lokatie` VALUES(2608, 'mesnil-eglise', '4.9620663000', '50.1641084000', '5560', 'Mesnil-Eglise', 10, 0);
INSERT INTO `lokatie` VALUES(2607, 'hulsonniaux', '4.9475735000', '50.2014731000', '5560', 'Hulsonniaux', 10, 0);
INSERT INTO `lokatie` VALUES(2606, 'houyet', '5.0115217000', '50.1849760000', '5560', 'Houyet', 10, 0);
INSERT INTO `lokatie` VALUES(2605, 'finnevaux', '4.9454998000', '50.1580511000', '5560', 'Finnevaux', 10, 0);
INSERT INTO `lokatie` VALUES(2604, 'ciergnon', '5.0884749000', '50.1667403000', '5560', 'Ciergnon', 10, 0);
INSERT INTO `lokatie` VALUES(2603, 'petit-fays', '4.9674127000', '49.9018959000', '5555', 'Petit-Fays', 10, 0);
INSERT INTO `lokatie` VALUES(2602, 'oizy', '5.0086639000', '49.8935999000', '5555', 'Oizy', 10, 0);
INSERT INTO `lokatie` VALUES(2601, 'naom', '5.0900976000', '49.9224387000', '5555', 'Naomé', 10, 0);
INSERT INTO `lokatie` VALUES(2600, 'monceau-en-ardenne', '4.9854375000', '49.9048564000', '5555', 'Monceau-en-Ardenne', 10, 0);
INSERT INTO `lokatie` VALUES(2599, 'gros-fays', '4.9833222000', '49.8695652000', '5555', 'Gros-Fays', 10, 0);
INSERT INTO `lokatie` VALUES(2598, 'graide', '5.0667409000', '49.9514562000', '5555', 'Graide', 10, 0);
INSERT INTO `lokatie` VALUES(2597, 'cornimont', '4.9983804000', '49.8624711000', '5555', 'Cornimont', 10, 0);
INSERT INTO `lokatie` VALUES(2596, 'bivre', '5.0164048000', '49.9413731000', '5555', 'Bièvre', 10, 0);
INSERT INTO `lokatie` VALUES(2595, 'bellefontaine-namur', '4.9727820000', '49.9177160000', '5555', 'Bellefontaine, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2594, 'baillamont', '5.0265040000', '49.8995762000', '5555', 'Baillamont', 10, 0);
INSERT INTO `lokatie` VALUES(2593, 'vresse-sur-semois', '4.9324779000', '49.8725743000', '5550', 'Vresse-sur-Semois', 10, 0);
INSERT INTO `lokatie` VALUES(2592, 'sugny', '4.9015886000', '49.8143970000', '5550', 'Sugny', 10, 0);
INSERT INTO `lokatie` VALUES(2591, 'pussemange', '4.8696993000', '49.8112527000', '5550', 'Pussemange', 10, 0);
INSERT INTO `lokatie` VALUES(2590, 'orchimont', '4.9272901000', '49.8935906000', '5550', 'Orchimont', 10, 0);
INSERT INTO `lokatie` VALUES(2589, 'nafraiture', '4.9172464000', '49.9105827000', '5550', 'Nafraiture', 10, 0);
INSERT INTO `lokatie` VALUES(2588, 'mouzaive', '4.9655633000', '49.8536120000', '5550', 'Mouzaive', 10, 0);
INSERT INTO `lokatie` VALUES(2587, 'membre', '4.9013313000', '49.8662228000', '5550', 'Membre', 10, 0);
INSERT INTO `lokatie` VALUES(2586, 'lafort', '4.9295387000', '49.8626878000', '5550', 'Laforêt', 10, 0);
INSERT INTO `lokatie` VALUES(2585, 'chairire', '4.9470893000', '49.8615312000', '5550', 'Chairière', 10, 0);
INSERT INTO `lokatie` VALUES(2584, 'bohan', '4.8856280000', '49.8641094000', '5550', 'Bohan', 10, 0);
INSERT INTO `lokatie` VALUES(2583, 'bagimont', '4.8752848000', '49.8243528000', '5550', 'Bagimont', 10, 0);
INSERT INTO `lokatie` VALUES(2582, 'alle', '4.9710511000', '49.8417377000', '5550', 'Alle', 10, 0);
INSERT INTO `lokatie` VALUES(2581, 'agimont', '4.7870724000', '50.1620531000', '5544', 'Agimont', 10, 0);
INSERT INTO `lokatie` VALUES(2580, 'heer', '4.8378402000', '50.1702655000', '5543', 'Heer', 10, 0);
INSERT INTO `lokatie` VALUES(2579, 'blaimont', '4.8413671000', '50.1907537000', '5542', 'Blaimont', 10, 0);
INSERT INTO `lokatie` VALUES(2578, 'hastire-par-del', '4.8291121000', '50.2093250000', '5541', 'Hastière-par-Delà', 10, 0);
INSERT INTO `lokatie` VALUES(2577, 'waulsort', '4.8644500000', '50.2050175000', '5540', 'Waulsort', 10, 0);
INSERT INTO `lokatie` VALUES(2576, 'hermeton-sur-meuse', '4.8151736000', '50.1952502000', '5540', 'Hermeton-sur-Meuse', 10, 0);
INSERT INTO `lokatie` VALUES(2575, 'hastire-lavaux', '4.8247979000', '50.2170488000', '5540', 'Hastière-Lavaux', 10, 0);
INSERT INTO `lokatie` VALUES(2574, 'hastire', '4.8080740000', '50.2127777000', '5540', 'Hastière', 10, 0);
INSERT INTO `lokatie` VALUES(2573, 'warnant', '4.8322257000', '50.3218661000', '5537', 'Warnant', 10, 0);
INSERT INTO `lokatie` VALUES(2572, 'sosoye', '4.7819505000', '50.2957434000', '5537', 'Sosoye', 10, 0);
INSERT INTO `lokatie` VALUES(2571, 'haut-le-wastia', '4.8427421000', '50.3054778000', '5537', 'Haut-le-Wastia', 10, 0);
INSERT INTO `lokatie` VALUES(2570, 'dene', '4.7497431000', '50.3167107000', '5537', 'Denée', 10, 0);
INSERT INTO `lokatie` VALUES(2569, 'bioul', '4.7987228000', '50.3336599000', '5537', 'Bioul', 10, 0);
INSERT INTO `lokatie` VALUES(2568, 'annevoie-rouillon', '4.8412997000', '50.3430484000', '5537', 'Annevoie-Rouillon', 10, 0);
INSERT INTO `lokatie` VALUES(2567, 'anhe', '4.8785852000', '50.3103443000', '5537', 'Anhée', 10, 0);
INSERT INTO `lokatie` VALUES(2566, 'yvoir', '4.8785776000', '50.3265112000', '5530', 'Yvoir', 10, 0);
INSERT INTO `lokatie` VALUES(2565, 'spontin', '5.0058663000', '50.3219709000', '5530', 'Spontin', 10, 0);
INSERT INTO `lokatie` VALUES(2564, 'purnode', '4.9439917000', '50.3121704000', '5530', 'Purnode', 10, 0);
INSERT INTO `lokatie` VALUES(2563, 'mont-namur', '4.9014191000', '50.3534706000', '5530', 'Mont, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2562, 'houx', '4.8980846000', '50.3028466000', '5530', 'Houx', 10, 0);
INSERT INTO `lokatie` VALUES(2561, 'godinne', '4.8663531000', '50.3496749000', '5530', 'Godinne', 10, 0);
INSERT INTO `lokatie` VALUES(2560, 'evrehailles', '4.9121382000', '50.3196849000', '5530', 'Evrehailles', 10, 0);
INSERT INTO `lokatie` VALUES(2559, 'durnal', '4.9847432000', '50.3365129000', '5530', 'Durnal', 10, 0);
INSERT INTO `lokatie` VALUES(2558, 'dorinne', '4.9728218000', '50.3159822000', '5530', 'Dorinne', 10, 0);
INSERT INTO `lokatie` VALUES(2557, 'gerin', '4.8133387000', '50.2435358000', '5524', 'Gerin', 10, 0);
INSERT INTO `lokatie` VALUES(2556, 'weillen', '4.8237599000', '50.2601664000', '5523', 'Weillen', 10, 0);
INSERT INTO `lokatie` VALUES(2555, 'sommire', '4.8482714000', '50.2768267000', '5523', 'Sommière', 10, 0);
INSERT INTO `lokatie` VALUES(2554, 'falan', '4.7957727000', '50.2855873000', '5522', 'Falaën', 10, 0);
INSERT INTO `lokatie` VALUES(2553, 'serville', '4.7756040000', '50.2580031000', '5521', 'Serville', 10, 0);
INSERT INTO `lokatie` VALUES(2552, 'onhaye', '4.8399518000', '50.2399612000', '5520', 'Onhaye', 10, 0);
INSERT INTO `lokatie` VALUES(2551, 'anthe', '4.7622804000', '50.2403296000', '5520', 'Anthée', 10, 0);
INSERT INTO `lokatie` VALUES(2550, 'foy-notre-dame', '4.9890808000', '50.2387086000', '5504', 'Foy-Notre-Dame', 10, 0);
INSERT INTO `lokatie` VALUES(2549, 'sorinnes', '5.0015126000', '50.2562527000', '5503', 'Sorinnes', 10, 0);
INSERT INTO `lokatie` VALUES(2548, 'thynes', '4.9946536000', '50.2875513000', '5502', 'Thynes', 10, 0);
INSERT INTO `lokatie` VALUES(2547, 'lisogne', '4.9453168000', '50.2896600000', '5501', 'Lisogne', 10, 0);
INSERT INTO `lokatie` VALUES(2546, 'furfooz', '4.9601476000', '50.2227495000', '5500', 'Furfooz', 10, 0);
INSERT INTO `lokatie` VALUES(2545, 'falmignoul', '4.8915702000', '50.2036240000', '5500', 'Falmignoul', 10, 0);
INSERT INTO `lokatie` VALUES(2544, 'falmagne', '4.8972014000', '50.1997732000', '5500', 'Falmagne', 10, 0);
INSERT INTO `lokatie` VALUES(2543, 'drhance', '4.9386151000', '50.2366011000', '5500', 'Dréhance', 10, 0);
INSERT INTO `lokatie` VALUES(2542, 'dinant', '4.9121846000', '50.2606083000', '5500', 'Dinant', 10, 0);
INSERT INTO `lokatie` VALUES(2541, 'bouvignes-sur-meuse', '4.8974710000', '50.2726749000', '5500', 'Bouvignes-sur-Meuse', 10, 0);
INSERT INTO `lokatie` VALUES(2540, 'anseremme', '4.9075295000', '50.2384166000', '5500', 'Anseremme', 10, 0);
INSERT INTO `lokatie` VALUES(2539, 'tillier', '4.9459064000', '50.5445462000', '5380', 'Tillier', 10, 0);
INSERT INTO `lokatie` VALUES(2538, 'pontillas', '5.0225574000', '50.5469146000', '5380', 'Pontillas', 10, 0);
INSERT INTO `lokatie` VALUES(2537, 'noville-les-bois', '4.9856092000', '50.5570566000', '5380', 'Noville-les-Bois', 10, 0);
INSERT INTO `lokatie` VALUES(2536, 'marchovelette', '4.9400520000', '50.5252865000', '5380', 'Marchovelette', 10, 0);
INSERT INTO `lokatie` VALUES(2535, 'hingeon', '5.0068940000', '50.5236273000', '5380', 'Hingeon', 10, 0);
INSERT INTO `lokatie` VALUES(2534, 'hemptinne-fernelmont', '4.9912011000', '50.6005008000', '5380', 'Hemptinne (Fernelmont)', 10, 0);
INSERT INTO `lokatie` VALUES(2533, 'franc-waret', '4.9777148000', '50.5201148000', '5380', 'Franc-Waret', 10, 0);
INSERT INTO `lokatie` VALUES(2532, 'forville', '5.0023558000', '50.5748458000', '5380', 'Forville', 10, 0);
INSERT INTO `lokatie` VALUES(2531, 'fernelmont', '4.9855088000', '50.5521080000', '5380', 'Fernelmont', 10, 0);
INSERT INTO `lokatie` VALUES(2530, 'cortil-wodon', '4.9583659000', '50.5678251000', '5380', 'Cortil-Wodon', 10, 0);
INSERT INTO `lokatie` VALUES(2529, 'bierwart', '5.0363692000', '50.5559583000', '5380', 'Bierwart', 10, 0);
INSERT INTO `lokatie` VALUES(2528, 'waillet', '5.3054247000', '50.2600627000', '5377', 'Waillet', 10, 0);
INSERT INTO `lokatie` VALUES(2527, 'somme-leuze', '5.3668406000', '50.3367465000', '5377', 'Somme-Leuze', 10, 0);
INSERT INTO `lokatie` VALUES(2526, 'sinsin', '5.2603696000', '50.2756440000', '5377', 'Sinsin', 10, 0);
INSERT INTO `lokatie` VALUES(2525, 'noiseux', '5.3746769000', '50.2990911000', '5377', 'Noiseux', 10, 0);
INSERT INTO `lokatie` VALUES(2524, 'nettinne', '5.2623985000', '50.2913953000', '5377', 'Nettinne', 10, 0);
INSERT INTO `lokatie` VALUES(2523, 'hogne', '5.2797968000', '50.2491030000', '5377', 'Hogne', 10, 0);
INSERT INTO `lokatie` VALUES(2522, 'heure-namur', '5.2958660000', '50.2937634000', '5377', 'Heure, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2521, 'bonsin', '5.3807551000', '50.3724477000', '5377', 'Bonsin', 10, 0);
INSERT INTO `lokatie` VALUES(2520, 'baillonville', '5.3369311000', '50.2883212000', '5377', 'Baillonville', 10, 0);
INSERT INTO `lokatie` VALUES(2519, 'micret', '5.2516921000', '50.3683735000', '5376', 'Miécret', 10, 0);
INSERT INTO `lokatie` VALUES(2518, 'maffe', '5.3157560000', '50.3534851000', '5374', 'Maffe', 10, 0);
INSERT INTO `lokatie` VALUES(2517, 'man', '5.3442156000', '50.3547686000', '5372', 'Méan', 10, 0);
INSERT INTO `lokatie` VALUES(2516, 'verle', '5.2745452000', '50.3643826000', '5370', 'Verlée', 10, 0);
INSERT INTO `lokatie` VALUES(2515, 'porcheresse-namur', '5.2378367000', '50.3374202000', '5370', 'Porcheresse, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2514, 'jeneffe-namur', '5.2449511000', '50.3553902000', '5370', 'Jeneffe, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2513, 'havelange', '5.2416418000', '50.3876488000', '5370', 'Havelange', 10, 0);
INSERT INTO `lokatie` VALUES(2512, 'flostoy', '5.1835408000', '50.3881122000', '5370', 'Flostoy', 10, 0);
INSERT INTO `lokatie` VALUES(2511, 'barvaux-condroz', '5.2609273000', '50.3289660000', '5370', 'Barvaux-Condroz', 10, 0);
INSERT INTO `lokatie` VALUES(2510, 'schaltin', '5.1207437000', '50.3648227000', '5364', 'Schaltin', 10, 0);
INSERT INTO `lokatie` VALUES(2509, 'emptinne', '5.1151291000', '50.3340230000', '5363', 'Emptinne', 10, 0);
INSERT INTO `lokatie` VALUES(2508, 'achet', '5.1744391000', '50.3339858000', '5362', 'Achet', 10, 0);
INSERT INTO `lokatie` VALUES(2507, 'scy', '5.2091699000', '50.3074621000', '5361', 'Scy', 10, 0);
INSERT INTO `lokatie` VALUES(2506, 'mohiville', '5.1909462000', '50.3199330000', '5361', 'Mohiville', 10, 0);
INSERT INTO `lokatie` VALUES(2505, 'natoye', '5.0644557000', '50.3351981000', '5360', 'Natoye', 10, 0);
INSERT INTO `lokatie` VALUES(2504, 'hamois', '5.1602993000', '50.3413338000', '5360', 'Hamois', 10, 0);
INSERT INTO `lokatie` VALUES(2503, 'jallet', '5.1836073000', '50.4345429000', '5354', 'Jallet', 10, 0);
INSERT INTO `lokatie` VALUES(2502, 'goesnes', '5.2087116000', '50.4515615000', '5353', 'Goesnes', 10, 0);
INSERT INTO `lokatie` VALUES(2501, 'perwez-haillot', '5.1749645000', '50.4556588000', '5352', 'Perwez-Haillot', 10, 0);
INSERT INTO `lokatie` VALUES(2500, 'haillot', '5.1481975000', '50.4464795000', '5351', 'Haillot', 10, 0);
INSERT INTO `lokatie` VALUES(2499, 'ohey', '5.1207431000', '50.4357426000', '5350', 'Ohey', 10, 0);
INSERT INTO `lokatie` VALUES(2498, 'evelette', '5.1737050000', '50.4119220000', '5350', 'Evelette', 10, 0);
INSERT INTO `lokatie` VALUES(2497, 'sore', '5.1254171000', '50.3993460000', '5340', 'Sorée', 10, 0);
INSERT INTO `lokatie` VALUES(2496, 'mozet', '4.9858724000', '50.4410071000', '5340', 'Mozet', 10, 0);
INSERT INTO `lokatie` VALUES(2495, 'haltinne', '5.0786476000', '50.4518119000', '5340', 'Haltinne', 10, 0);
INSERT INTO `lokatie` VALUES(2494, 'gesves', '5.0753322000', '50.4024328000', '5340', 'Gesves', 10, 0);
INSERT INTO `lokatie` VALUES(2493, 'faulx-les-tombes', '5.0250465000', '50.4264485000', '5340', 'Faulx-les-Tombes', 10, 0);
INSERT INTO `lokatie` VALUES(2492, 'courrire', '4.9881871000', '50.3912880000', '5336', 'Courrière', 10, 0);
INSERT INTO `lokatie` VALUES(2491, 'flore', '5.0730382000', '50.3772652000', '5334', 'Florée', 10, 0);
INSERT INTO `lokatie` VALUES(2490, 'sorinne-la-longue', '5.0253340000', '50.3896895000', '5333', 'Sorinne-la-Longue', 10, 0);
INSERT INTO `lokatie` VALUES(2489, 'crupet', '4.9685315000', '50.3507246000', '5332', 'Crupet', 10, 0);
INSERT INTO `lokatie` VALUES(2488, 'sart-bernard', '4.9498585000', '50.4050702000', '5330', 'Sart-Bernard', 10, 0);
INSERT INTO `lokatie` VALUES(2487, 'maillen', '4.9703054000', '50.3780379000', '5330', 'Maillen', 10, 0);
INSERT INTO `lokatie` VALUES(2486, 'assesse', '5.0222043000', '50.3717203000', '5330', 'Assesse', 10, 0);
INSERT INTO `lokatie` VALUES(2485, 'waret-la-chausse', '4.9283769000', '50.5440008000', '5310', 'Waret-la-Chaussée', 10, 0);
INSERT INTO `lokatie` VALUES(2484, 'upigny', '4.8722392000', '50.5716173000', '5310', 'Upigny', 10, 0);
INSERT INTO `lokatie` VALUES(2483, 'taviers-namur', '4.9307085000', '50.6170583000', '5310', 'Taviers, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2482, 'saint-germain', '4.8423498000', '50.5726930000', '5310', 'Saint-Germain', 10, 0);
INSERT INTO `lokatie` VALUES(2481, 'noville-sur-mhaigne', '4.8905202000', '50.6079355000', '5310', 'Noville-sur-Méhaigne', 10, 0);
INSERT INTO `lokatie` VALUES(2480, 'mehaigne', '4.8756059000', '50.5938019000', '5310', 'Mehaigne', 10, 0);
INSERT INTO `lokatie` VALUES(2479, 'longchamps-namur', '4.8967471000', '50.5772165000', '5310', 'Longchamps, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2478, 'liernu', '4.8267341000', '50.5841815000', '5310', 'Liernu', 10, 0);
INSERT INTO `lokatie` VALUES(2477, 'leuze-namur', '4.9099844000', '50.5600883000', '5310', 'Leuze, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2476, 'hanret', '4.9450355000', '50.5842881000', '5310', 'Hanret', 10, 0);
INSERT INTO `lokatie` VALUES(2475, 'egheze', '4.9064553000', '50.5917189000', '5310', 'Eghezée', 10, 0);
INSERT INTO `lokatie` VALUES(2474, 'dhuy', '4.8592148000', '50.5596414000', '5310', 'Dhuy', 10, 0);
INSERT INTO `lokatie` VALUES(2473, 'branchon', '4.9725300000', '50.6291816000', '5310', 'Branchon', 10, 0);
INSERT INTO `lokatie` VALUES(2472, 'boneffe', '4.9575925000', '50.6253802000', '5310', 'Boneffe', 10, 0);
INSERT INTO `lokatie` VALUES(2471, 'bolinne', '4.9284973000', '50.6009713000', '5310', 'Bolinne', 10, 0);
INSERT INTO `lokatie` VALUES(2470, 'aische-en-refail', '4.8357292000', '50.5998605000', '5310', 'Aische-en-Refail', 10, 0);
INSERT INTO `lokatie` VALUES(2469, 'vezin', '5.0070979000', '50.4947522000', '5300', 'Vezin', 10, 0);
INSERT INTO `lokatie` VALUES(2468, 'thon', '5.0120225000', '50.4641169000', '5300', 'Thon', 10, 0);
INSERT INTO `lokatie` VALUES(2467, 'seilles', '5.0780070000', '50.5002032000', '5300', 'Seilles', 10, 0);
INSERT INTO `lokatie` VALUES(2466, 'sclayn', '5.0277062000', '50.4896116000', '5300', 'Sclayn', 10, 0);
INSERT INTO `lokatie` VALUES(2465, 'namche', '4.9948454000', '50.4698414000', '5300', 'Namêche', 10, 0);
INSERT INTO `lokatie` VALUES(2464, 'maizeret', '4.9789218000', '50.4596236000', '5300', 'Maizeret', 10, 0);
INSERT INTO `lokatie` VALUES(2463, 'landenne', '5.0632264000', '50.5133302000', '5300', 'Landenne', 10, 0);
INSERT INTO `lokatie` VALUES(2462, 'coutisse', '5.1168327000', '50.4629456000', '5300', 'Coutisse', 10, 0);
INSERT INTO `lokatie` VALUES(2461, 'bonneville', '5.0336188000', '50.4707971000', '5300', 'Bonneville', 10, 0);
INSERT INTO `lokatie` VALUES(2460, 'andenne', '5.0968908000', '50.4897595000', '5300', 'Andenne', 10, 0);
INSERT INTO `lokatie` VALUES(2459, 'spy', '4.7042876000', '50.4822127000', '5190', 'Spy', 10, 0);
INSERT INTO `lokatie` VALUES(2458, 'saint-martin', '4.6473657000', '50.5009515000', '5190', 'Saint-Martin', 10, 0);
INSERT INTO `lokatie` VALUES(2457, 'onoz', '4.6703061000', '50.4925112000', '5190', 'Onoz', 10, 0);
INSERT INTO `lokatie` VALUES(2456, 'moustier-sur-sambre', '4.6976908000', '50.4662224000', '5190', 'Moustier-sur-Sambre', 10, 0);
INSERT INTO `lokatie` VALUES(2455, 'mornimont', '4.7039762000', '50.4553349000', '5190', 'Mornimont', 10, 0);
INSERT INTO `lokatie` VALUES(2454, 'jemeppe-sur-sambre', '4.6682645000', '50.4655947000', '5190', 'Jemeppe-sur-Sambre', 10, 0);
INSERT INTO `lokatie` VALUES(2453, 'ham-sur-sambre', '4.6734135000', '50.4444291000', '5190', 'Ham-sur-Sambre', 10, 0);
INSERT INTO `lokatie` VALUES(2452, 'baltre', '4.6384944000', '50.4985760000', '5190', 'Balâtre', 10, 0);
INSERT INTO `lokatie` VALUES(2451, 'rivire', '4.8722228000', '50.3580223000', '5170', 'Rivière', 10, 0);
INSERT INTO `lokatie` VALUES(2450, 'profondeville', '4.8695410000', '50.3777331000', '5170', 'Profondeville', 10, 0);
INSERT INTO `lokatie` VALUES(2449, 'lustin', '4.8960324000', '50.3796102000', '5170', 'Lustin', 10, 0);
INSERT INTO `lokatie` VALUES(2448, 'lesve', '4.7794123000', '50.3736475000', '5170', 'Lesve', 10, 0);
INSERT INTO `lokatie` VALUES(2447, 'bois-de-villers', '4.8229103000', '50.3884450000', '5170', 'Bois-de-Villers', 10, 0);
INSERT INTO `lokatie` VALUES(2446, 'arbre-namur', '4.8201553000', '50.3662379000', '5170', 'Arbre, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2445, 'soye-namur', '4.7304410000', '50.4493140000', '5150', 'Soye, Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2444, 'franire', '4.7300145000', '50.4404676000', '5150', 'Franière', 10, 0);
INSERT INTO `lokatie` VALUES(2443, 'floriffoux', '4.7696330000', '50.4521019000', '5150', 'Floriffoux', 10, 0);
INSERT INTO `lokatie` VALUES(2442, 'floreffe', '4.7578868000', '50.4350146000', '5150', 'Floreffe', 10, 0);
INSERT INTO `lokatie` VALUES(2441, 'tongrinne', '4.6241467000', '50.5156892000', '5140', 'Tongrinne', 10, 0);
INSERT INTO `lokatie` VALUES(2440, 'sombreffe', '4.6008687000', '50.5229845000', '5140', 'Sombreffe', 10, 0);
INSERT INTO `lokatie` VALUES(2439, 'ligny', '4.5749136000', '50.5120267000', '5140', 'Ligny', 10, 0);
INSERT INTO `lokatie` VALUES(2438, 'boigne', '4.6140590000', '50.5018645000', '5140', 'Boignée', 10, 0);
INSERT INTO `lokatie` VALUES(2437, 'saint-denis-bovesse', '4.7848510000', '50.5354646000', '5081', 'Saint-Denis-Bovesse', 10, 0);
INSERT INTO `lokatie` VALUES(2436, 'meux', '4.8010080000', '50.5518937000', '5081', 'Meux', 10, 0);
INSERT INTO `lokatie` VALUES(2435, 'bovesse', '4.7783833000', '50.5175906000', '5081', 'Bovesse', 10, 0);
INSERT INTO `lokatie` VALUES(2434, 'warisoulx', '4.8612652000', '50.5341811000', '5080', 'Warisoulx', 10, 0);
INSERT INTO `lokatie` VALUES(2433, 'villers-lez-heest', '4.8455238000', '50.5299194000', '5080', 'Villers-lez-Heest', 10, 0);
INSERT INTO `lokatie` VALUES(2432, 'rhisnes', '4.8036957000', '50.5049003000', '5080', 'Rhisnes', 10, 0);
INSERT INTO `lokatie` VALUES(2431, 'la-bruyre', '4.8150906000', '50.5073930000', '5080', 'La Bruyère', 10, 0);
INSERT INTO `lokatie` VALUES(2430, 'emines', '4.8411544000', '50.5152270000', '5080', 'Emines', 10, 0);
INSERT INTO `lokatie` VALUES(2429, 'vitrival', '4.6568760000', '50.3938273000', '5070', 'Vitrival', 10, 0);
INSERT INTO `lokatie` VALUES(2428, 'sart-saint-laurent', '4.7416127000', '50.4022456000', '5070', 'Sart-Saint-Laurent', 10, 0);
INSERT INTO `lokatie` VALUES(2427, 'sart-eustache', '4.5989101000', '50.3760875000', '5070', 'Sart-Eustache', 10, 0);
INSERT INTO `lokatie` VALUES(2426, 'le-roux', '4.6237091000', '50.3889572000', '5070', 'Le Roux', 10, 0);
INSERT INTO `lokatie` VALUES(2425, 'fosses-la-ville', '4.6970754000', '50.3971290000', '5070', 'Fosses-la-Ville', 10, 0);
INSERT INTO `lokatie` VALUES(2424, 'aisemont', '4.6513307000', '50.4046873000', '5070', 'Aisemont', 10, 0);
INSERT INTO `lokatie` VALUES(2423, 'velaine-sur-sambre', '4.6169786000', '50.4684309000', '5060', 'Velaine-sur-Sambre', 10, 0);
INSERT INTO `lokatie` VALUES(2422, 'tamines', '4.6116399000', '50.4316253000', '5060', 'Tamines', 10, 0);
INSERT INTO `lokatie` VALUES(2421, 'sambreville', '4.6069796000', '50.4536106000', '5060', 'Sambreville', 10, 0);
INSERT INTO `lokatie` VALUES(2420, 'moignele', '4.5857527000', '50.4383224000', '5060', 'Moignelée', 10, 0);
INSERT INTO `lokatie` VALUES(2419, 'keumie', '4.5944398000', '50.4648714000', '5060', 'Keumiée', 10, 0);
INSERT INTO `lokatie` VALUES(2418, 'falisolle', '4.6212812000', '50.4184698000', '5060', 'Falisolle', 10, 0);
INSERT INTO `lokatie` VALUES(2417, 'auvelais', '4.6350156000', '50.4469503000', '5060', 'Auvelais', 10, 0);
INSERT INTO `lokatie` VALUES(2416, 'arsimont', '4.6379140000', '50.4266648000', '5060', 'Arsimont', 10, 0);
INSERT INTO `lokatie` VALUES(2415, 'mazy', '4.6770711000', '50.5115880000', '5032', 'Mazy', 10, 0);
INSERT INTO `lokatie` VALUES(2414, 'isnes', '4.7290719000', '50.5062005000', '5032', 'Isnes', 10, 0);
INSERT INTO `lokatie` VALUES(2413, 'corroy-le-chteau', '4.6588374000', '50.5361958000', '5032', 'Corroy-le-Château', 10, 0);
INSERT INTO `lokatie` VALUES(2412, 'bothey', '4.6526180000', '50.5218156000', '5032', 'Bothey', 10, 0);
INSERT INTO `lokatie` VALUES(2411, 'bossire', '4.6968326000', '50.5184708000', '5032', 'Bossière', 10, 0);
INSERT INTO `lokatie` VALUES(2410, 'grand-leez', '4.7707367000', '50.5766743000', '5031', 'Grand-Leez', 10, 0);
INSERT INTO `lokatie` VALUES(2409, 'sauvenire', '4.7240750000', '50.5812547000', '5030', 'Sauvenière', 10, 0);
INSERT INTO `lokatie` VALUES(2408, 'lonze', '4.7263320000', '50.5529889000', '5030', 'Lonzée', 10, 0);
INSERT INTO `lokatie` VALUES(2407, 'grand-manil', '4.6826733000', '50.5572329000', '5030', 'Grand-Manil', 10, 0);
INSERT INTO `lokatie` VALUES(2406, 'gembloux', '4.6937503000', '50.5612084000', '5030', 'Gembloux', 10, 0);
INSERT INTO `lokatie` VALUES(2405, 'ernage', '4.6741635000', '50.5939303000', '5030', 'Ernage', 10, 0);
INSERT INTO `lokatie` VALUES(2404, 'beuzet', '4.7417015000', '50.5329187000', '5030', 'Beuzet', 10, 0);
INSERT INTO `lokatie` VALUES(2403, 'loyers', '4.9503556000', '50.4639019000', '5101', 'Loyers', 10, 0);
INSERT INTO `lokatie` VALUES(2402, 'lives-sur-meuse', '4.9252306000', '50.4652886000', '5101', 'Lives-sur-Meuse', 10, 0);
INSERT INTO `lokatie` VALUES(2401, 'erpent', '4.9071522000', '50.4510107000', '5101', 'Erpent', 10, 0);
INSERT INTO `lokatie` VALUES(2400, 'wierde', '4.9504473000', '50.4248911000', '5100', 'Wierde', 10, 0);
INSERT INTO `lokatie` VALUES(2399, 'wpion', '4.8712428000', '50.4197516000', '5100', 'Wépion', 10, 0);
INSERT INTO `lokatie` VALUES(2398, 'naninne', '4.9194705000', '50.4182751000', '5100', 'Naninne', 10, 0);
INSERT INTO `lokatie` VALUES(2397, 'jambes', '4.8681711000', '50.4578105000', '5100', 'Jambes', 10, 0);
INSERT INTO `lokatie` VALUES(2396, 'dave', '4.8867499000', '50.4151202000', '5100', 'Dave', 10, 0);
INSERT INTO `lokatie` VALUES(2395, 'marche-les-dames', '4.9720170000', '50.4938868000', '5024', 'Marche-les-Dames', 10, 0);
INSERT INTO `lokatie` VALUES(2394, 'gelbresse', '4.9540278000', '50.5098000000', '5024', 'Gelbressée', 10, 0);
INSERT INTO `lokatie` VALUES(2393, 'cognele', '4.9072348000', '50.5165140000', '5022', 'Cognelée', 10, 0);
INSERT INTO `lokatie` VALUES(2392, 'boninne', '4.9272263000', '50.4952458000', '5021', 'Boninne', 10, 0);
INSERT INTO `lokatie` VALUES(2391, 'vedrin', '4.8725938000', '50.5036361000', '5020', 'Vedrin', 10, 0);
INSERT INTO `lokatie` VALUES(2390, 'temploux', '4.7509103000', '50.4833180000', '5020', 'Temploux', 10, 0);
INSERT INTO `lokatie` VALUES(2389, 'suarle', '4.7797801000', '50.4805880000', '5020', 'Suarlée', 10, 0);
INSERT INTO `lokatie` VALUES(2388, 'malonne', '4.7947122000', '50.4360664000', '5020', 'Malonne', 10, 0);
INSERT INTO `lokatie` VALUES(2387, 'flawinne', '4.7981759000', '50.4605596000', '5020', 'Flawinne', 10, 0);
INSERT INTO `lokatie` VALUES(2386, 'daussoulx', '4.8757257000', '50.5166591000', '5020', 'Daussoulx', 10, 0);
INSERT INTO `lokatie` VALUES(2385, 'champion', '4.9014511000', '50.4975351000', '5020', 'Champion', 10, 0);
INSERT INTO `lokatie` VALUES(2384, 'bouge', '4.8911893000', '50.4782959000', '5004', 'Bouge', 10, 0);
INSERT INTO `lokatie` VALUES(2383, 'saint-marc', '4.8469493000', '50.4931073000', '5003', 'Saint-Marc', 10, 0);
INSERT INTO `lokatie` VALUES(2382, 'saint-servais', '4.8380903000', '50.4779223000', '5002', 'Saint-Servais', 10, 0);
INSERT INTO `lokatie` VALUES(2381, 'belgrade', '4.8239381000', '50.4681427000', '5001', 'Belgrade', 10, 0);
INSERT INTO `lokatie` VALUES(2380, 'namur', '4.8604305000', '50.4640737000', '5000', 'Namur', 10, 0);
INSERT INTO `lokatie` VALUES(2379, 'beez', '4.9218061000', '50.4687502000', '5000', 'Beez', 10, 0);
INSERT INTO `lokatie` VALUES(2378, 'soy', '5.5109115000', '50.2856280000', '6997', 'Soy', 9, 0);
INSERT INTO `lokatie` VALUES(2377, 'mormont', '5.5929954000', '50.3254256000', '6997', 'Mormont', 9, 0);
INSERT INTO `lokatie` VALUES(2376, 'ereze', '5.5585806000', '50.2921540000', '6997', 'Erezée', 9, 0);
INSERT INTO `lokatie` VALUES(2375, 'amonines', '5.5558759000', '50.2658412000', '6997', 'Amonines', 9, 0);
INSERT INTO `lokatie` VALUES(2374, 'marenne', '5.4165485000', '50.2424469000', '6990', 'Marenne', 9, 0);
INSERT INTO `lokatie` VALUES(2373, 'hotton', '5.4465057000', '50.2677331000', '6990', 'Hotton', 9, 0);
INSERT INTO `lokatie` VALUES(2372, 'hampteau', '5.4726031000', '50.2577954000', '6990', 'Hampteau', 9, 0);
INSERT INTO `lokatie` VALUES(2371, 'fronville', '5.4225320000', '50.2941147000', '6990', 'Fronville', 9, 0);
INSERT INTO `lokatie` VALUES(2370, 'rendeux', '5.5039369000', '50.2338118000', '6987', 'Rendeux', 9, 0);
INSERT INTO `lokatie` VALUES(2369, 'marcourt', '5.5280558000', '50.2144573000', '6987', 'Marcourt', 9, 0);
INSERT INTO `lokatie` VALUES(2368, 'hodister', '5.4955151000', '50.2006741000', '6987', 'Hodister', 9, 0);
INSERT INTO `lokatie` VALUES(2367, 'beffe', '5.5235120000', '50.2449722000', '6987', 'Beffe', 9, 0);
INSERT INTO `lokatie` VALUES(2366, 'halleux', '5.4968030000', '50.1719117000', '6986', 'Halleux', 9, 0);
INSERT INTO `lokatie` VALUES(2365, 'hives', '5.5795416000', '50.1473227000', '6984', 'Hives', 9, 0);
INSERT INTO `lokatie` VALUES(2364, 'ortho', '5.6219286000', '50.1401181000', '6983', 'Ortho', 9, 0);
INSERT INTO `lokatie` VALUES(2363, 'samre', '5.6590863000', '50.2002587000', '6982', 'Samrée', 9, 0);
INSERT INTO `lokatie` VALUES(2362, 'la-roche-en-ardenne', '5.5756903000', '50.1827438000', '6980', 'La-Roche-en-Ardenne', 9, 0);
INSERT INTO `lokatie` VALUES(2361, 'beausaint', '5.5527219000', '50.1696753000', '6980', 'Beausaint', 9, 0);
INSERT INTO `lokatie` VALUES(2360, 'erneuville', '5.5642302000', '50.1016368000', '6972', 'Erneuville', 9, 0);
INSERT INTO `lokatie` VALUES(2359, 'champlon', '5.4868123000', '50.1207914000', '6971', 'Champlon', 9, 0);
INSERT INTO `lokatie` VALUES(2358, 'tenneville', '5.4613070000', '50.0859055000', '6970', 'Tenneville', 9, 0);
INSERT INTO `lokatie` VALUES(2357, 'vaux-chavanne', '5.6970764000', '50.3023904000', '6960', 'Vaux-Chavanne', 9, 0);
INSERT INTO `lokatie` VALUES(2356, 'odeigne', '5.6824792000', '50.2575322000', '6960', 'Odeigne', 9, 0);
INSERT INTO `lokatie` VALUES(2355, 'manhay', '5.6756196000', '50.2922444000', '6960', 'Manhay', 9, 0);
INSERT INTO `lokatie` VALUES(2354, 'malempr', '5.7155791000', '50.2812902000', '6960', 'Malempré', 9, 0);
INSERT INTO `lokatie` VALUES(2353, 'harre', '5.6581118000', '50.3511881000', '6960', 'Harre', 9, 0);
INSERT INTO `lokatie` VALUES(2352, 'grandmenil', '5.6583148000', '50.2918148000', '6960', 'Grandmenil', 9, 0);
INSERT INTO `lokatie` VALUES(2351, 'dochamps', '5.6220690000', '50.2344812000', '6960', 'Dochamps', 9, 0);
INSERT INTO `lokatie` VALUES(2350, 'masbourg', '5.3119170000', '50.1125461000', '6953', 'Masbourg', 9, 0);
INSERT INTO `lokatie` VALUES(2349, 'lesterny', '5.2815057000', '50.1125965000', '6953', 'Lesterny', 9, 0);
INSERT INTO `lokatie` VALUES(2348, 'forrires', '5.2770192000', '50.1321311000', '6953', 'Forrières', 9, 0);
INSERT INTO `lokatie` VALUES(2347, 'ambly', '5.3130651000', '50.1419666000', '6953', 'Ambly', 9, 0);
INSERT INTO `lokatie` VALUES(2346, 'grune', '5.3918429000', '50.1458721000', '6952', 'Grune', 9, 0);
INSERT INTO `lokatie` VALUES(2345, 'bande', '5.4289372000', '50.1441437000', '6951', 'Bande', 9, 0);
INSERT INTO `lokatie` VALUES(2344, 'nassogne', '5.3406283000', '50.1286245000', '6950', 'Nassogne', 9, 0);
INSERT INTO `lokatie` VALUES(2343, 'harsin', '5.3496164000', '50.1727688000', '6950', 'Harsin', 9, 0);
INSERT INTO `lokatie` VALUES(2342, 'villers-sainte-gertrude', '5.5788535000', '50.3608486000', '6941', 'Villers-Sainte-Gertrude', 9, 0);
INSERT INTO `lokatie` VALUES(2341, 'tohogne', '5.4801310000', '50.3798065000', '6941', 'Tohogne', 9, 0);
INSERT INTO `lokatie` VALUES(2340, 'izier', '5.5793403000', '50.3838003000', '6941', 'Izier', 9, 0);
INSERT INTO `lokatie` VALUES(2339, 'heyd', '5.5599127000', '50.3467044000', '6941', 'Heyd', 9, 0);
INSERT INTO `lokatie` VALUES(2338, 'borlon', '5.4051212000', '50.3790764000', '6941', 'Borlon', 9, 0);
INSERT INTO `lokatie` VALUES(2337, 'bomal-sur-ourthe', '5.5239400000', '50.3768155000', '6941', 'Bomal-sur-Ourthe', 9, 0);
INSERT INTO `lokatie` VALUES(2336, 'bende', '5.4139216000', '50.4174109000', '6941', 'Bende', 9, 0);
INSERT INTO `lokatie` VALUES(2335, 'wris', '5.5304441000', '50.3262656000', '6940', 'Wéris', 9, 0);
INSERT INTO `lokatie` VALUES(2334, 'septon', '5.4228577000', '50.3566021000', '6940', 'Septon', 9, 0);
INSERT INTO `lokatie` VALUES(2333, 'grandhan', '5.4080850000', '50.3298776000', '6940', 'Grandhan', 9, 0);
INSERT INTO `lokatie` VALUES(2332, 'durbuy', '5.4565088000', '50.3528179000', '6940', 'Durbuy', 9, 0);
INSERT INTO `lokatie` VALUES(2331, 'barvaux-sur-ourthe', '5.4931214000', '50.3505198000', '6940', 'Barvaux-sur-Ourthe', 9, 0);
INSERT INTO `lokatie` VALUES(2330, 'porcheresse-luxembourg', '5.0870920000', '49.9778164000', '6929', 'Porcheresse, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2329, 'haut-fays', '5.0179004000', '50.0013437000', '6929', 'Haut-Fays', 9, 0);
INSERT INTO `lokatie` VALUES(2328, 'gembes', '5.0633331000', '49.9967186000', '6929', 'Gembes', 9, 0);
INSERT INTO `lokatie` VALUES(2327, 'daverdisse', '5.1180605000', '50.0210507000', '6929', 'Daverdisse', 9, 0);
INSERT INTO `lokatie` VALUES(2326, 'tellin', '5.2166123000', '50.0811880000', '6927', 'Tellin', 9, 0);
INSERT INTO `lokatie` VALUES(2325, 'resteigne', '5.1770086000', '50.0826009000', '6927', 'Resteigne', 9, 0);
INSERT INTO `lokatie` VALUES(2324, 'grupont', '5.2801115000', '50.0926343000', '6927', 'Grupont', 9, 0);
INSERT INTO `lokatie` VALUES(2323, 'bure', '5.2598156000', '50.0887965000', '6927', 'Bure', 9, 0);
INSERT INTO `lokatie` VALUES(2322, 'lomprez', '5.0895748000', '50.0564338000', '6924', 'Lomprez', 9, 0);
INSERT INTO `lokatie` VALUES(2321, 'halma', '5.1299168000', '50.0572330000', '6922', 'Halma', 9, 0);
INSERT INTO `lokatie` VALUES(2320, 'chanly', '5.1528040000', '50.0639445000', '6921', 'Chanly', 9, 0);
INSERT INTO `lokatie` VALUES(2319, 'wellin', '5.1137667000', '50.0815885000', '6920', 'Wellin', 9, 0);
INSERT INTO `lokatie` VALUES(2318, 'sohier', '5.0708520000', '50.0687716000', '6920', 'Sohier', 9, 0);
INSERT INTO `lokatie` VALUES(2317, 'waha', '5.3432071000', '50.2119547000', '6900', 'Waha', 9, 0);
INSERT INTO `lokatie` VALUES(2316, 'roy', '5.4094241000', '50.1880842000', '6900', 'Roy', 9, 0);
INSERT INTO `lokatie` VALUES(2315, 'on', '5.2886531000', '50.1721366000', '6900', 'On', 9, 0);
INSERT INTO `lokatie` VALUES(2314, 'marche-en-famenne', '5.3443149000', '50.2285822000', '6900', 'Marche-en-Famenne', 9, 0);
INSERT INTO `lokatie` VALUES(2313, 'humain', '5.2567095000', '50.2049559000', '6900', 'Humain', 9, 0);
INSERT INTO `lokatie` VALUES(2312, 'hargimont', '5.3083396000', '50.1837759000', '6900', 'Hargimont', 9, 0);
INSERT INTO `lokatie` VALUES(2311, 'aye', '5.3001020000', '50.2243014000', '6900', 'Aye', 9, 0);
INSERT INTO `lokatie` VALUES(2310, 'villance', '5.2208880000', '49.9710592000', '6890', 'Villance', 9, 0);
INSERT INTO `lokatie` VALUES(2309, 'transinne', '5.2029085000', '49.9987666000', '6890', 'Transinne', 9, 0);
INSERT INTO `lokatie` VALUES(2308, 'smuid', '5.2661777000', '50.0186083000', '6890', 'Smuid', 9, 0);
INSERT INTO `lokatie` VALUES(2307, 'redu', '5.1601778000', '50.0070656000', '6890', 'Redu', 9, 0);
INSERT INTO `lokatie` VALUES(2306, 'ochamps', '5.2770840000', '49.9250277000', '6890', 'Ochamps', 9, 0);
INSERT INTO `lokatie` VALUES(2305, 'libin', '5.2560731000', '49.9805558000', '6890', 'Libin', 9, 0);
INSERT INTO `lokatie` VALUES(2304, 'anloy', '5.2216385000', '49.9502718000', '6890', 'Anloy', 9, 0);
INSERT INTO `lokatie` VALUES(2303, 'straimont', '5.3803701000', '49.7963609000', '6887', 'Straimont', 9, 0);
INSERT INTO `lokatie` VALUES(2302, 'saint-mdard', '5.3280912000', '49.8165414000', '6887', 'Saint-Médard', 9, 0);
INSERT INTO `lokatie` VALUES(2301, 'herbeumont', '5.2350026000', '49.7823279000', '6887', 'Herbeumont', 9, 0);
INSERT INTO `lokatie` VALUES(2300, 'orgeo', '5.3061011000', '49.8331566000', '6880', 'Orgeo', 9, 0);
INSERT INTO `lokatie` VALUES(2299, 'jehonville', '5.2005857000', '49.9070024000', '6880', 'Jehonville', 9, 0);
INSERT INTO `lokatie` VALUES(2298, 'cugnon', '5.2105350000', '49.8002513000', '6880', 'Cugnon', 9, 0);
INSERT INTO `lokatie` VALUES(2297, 'bertrix', '5.2526716000', '49.8543318000', '6880', 'Bertrix', 9, 0);
INSERT INTO `lokatie` VALUES(2296, 'auby-sur-semois', '5.1813349000', '49.8158607000', '6880', 'Auby-sur-Semois', 9, 0);
INSERT INTO `lokatie` VALUES(2295, 'vesqueville', '5.3963853000', '50.0055817000', '6870', 'Vesqueville', 9, 0);
INSERT INTO `lokatie` VALUES(2294, 'saint-hubert', '5.3740981000', '50.0260592000', '6870', 'Saint-Hubert', 9, 0);
INSERT INTO `lokatie` VALUES(2293, 'mirwart', '5.2634737000', '50.0563298000', '6870', 'Mirwart', 9, 0);
INSERT INTO `lokatie` VALUES(2292, 'hatrival', '5.3480962000', '50.0059352000', '6870', 'Hatrival', 9, 0);
INSERT INTO `lokatie` VALUES(2291, 'awenne', '5.3064494000', '50.0745421000', '6870', 'Awenne', 9, 0);
INSERT INTO `lokatie` VALUES(2290, 'arville', '5.3164927000', '50.0323296000', '6870', 'Arville', 9, 0);
INSERT INTO `lokatie` VALUES(2289, 'witry', '5.6120217000', '49.8593938000', '6860', 'Witry', 9, 0);
INSERT INTO `lokatie` VALUES(2288, 'mellier', '5.5221168000', '49.7686828000', '6860', 'Mellier', 9, 0);
INSERT INTO `lokatie` VALUES(2287, 'lglise', '5.5394448000', '49.8010408000', '6860', 'Léglise', 9, 0);
INSERT INTO `lokatie` VALUES(2286, 'ebly', '5.5409926000', '49.8523930000', '6860', 'Ebly', 9, 0);
INSERT INTO `lokatie` VALUES(2285, 'assenois', '5.4651678000', '49.8014898000', '6860', 'Assenois', 9, 0);
INSERT INTO `lokatie` VALUES(2284, 'fays-les-veneurs', '5.1643785000', '49.8577639000', '6856', 'Fays-les-Veneurs', 9, 0);
INSERT INTO `lokatie` VALUES(2283, 'framont', '5.1652451000', '49.9296283000', '6853', 'Framont', 9, 0);
INSERT INTO `lokatie` VALUES(2282, 'opont', '5.1180347000', '49.9343622000', '6852', 'Opont', 9, 0);
INSERT INTO `lokatie` VALUES(2281, 'maissin', '5.1792656000', '49.9646214000', '6852', 'Maissin', 9, 0);
INSERT INTO `lokatie` VALUES(2280, 'nollevaux', '5.1174360000', '49.8701117000', '6851', 'Nollevaux', 9, 0);
INSERT INTO `lokatie` VALUES(2279, 'paliseul', '5.1350441000', '49.9037334000', '6850', 'Paliseul', 9, 0);
INSERT INTO `lokatie` VALUES(2278, 'offagne', '5.1743324000', '49.8862428000', '6850', 'Offagne', 9, 0);
INSERT INTO `lokatie` VALUES(2277, 'carlsbourg', '5.0823158000', '49.8946641000', '6850', 'Carlsbourg', 9, 0);
INSERT INTO `lokatie` VALUES(2276, 'tournay', '5.3980121000', '49.8535767000', '6840', 'Tournay', 9, 0);
INSERT INTO `lokatie` VALUES(2275, 'neufchteau', '5.4348813000', '49.8391647000', '6840', 'Neufchâteau', 9, 0);
INSERT INTO `lokatie` VALUES(2274, 'longlier', '5.4557457000', '49.8546020000', '6840', 'Longlier', 9, 0);
INSERT INTO `lokatie` VALUES(2273, 'hamipr', '5.4565823000', '49.8351927000', '6840', 'Hamipré', 9, 0);
INSERT INTO `lokatie` VALUES(2272, 'grapfontaine', '5.4091579000', '49.8216507000', '6840', 'Grapfontaine', 9, 0);
INSERT INTO `lokatie` VALUES(2271, 'grandvoir', '5.3727437000', '49.8583554000', '6840', 'Grandvoir', 9, 0);
INSERT INTO `lokatie` VALUES(2270, 'corbion', '5.0175742000', '49.7923956000', '6838', 'Corbion', 9, 0);
INSERT INTO `lokatie` VALUES(2269, 'dohan', '5.1375114000', '49.7948320000', '6836', 'Dohan', 9, 0);
INSERT INTO `lokatie` VALUES(2268, 'bellevaux', '5.1214901000', '49.8417042000', '6834', 'Bellevaux', 9, 0);
INSERT INTO `lokatie` VALUES(2267, 'vivy', '5.0383798000', '49.8668882000', '6833', 'Vivy', 9, 0);
INSERT INTO `lokatie` VALUES(2266, 'ucimont', '5.0547346000', '49.8310920000', '6833', 'Ucimont', 9, 0);
INSERT INTO `lokatie` VALUES(2265, 'sensenruth', '5.0716756000', '49.8208082000', '6832', 'Sensenruth', 9, 0);
INSERT INTO `lokatie` VALUES(2264, 'noirefontaine', '5.1063496000', '49.8090285000', '6831', 'Noirefontaine', 9, 0);
INSERT INTO `lokatie` VALUES(2263, 'rochehaut', '5.0056055000', '49.8401918000', '6830', 'Rochehaut', 9, 0);
INSERT INTO `lokatie` VALUES(2262, 'poupehan', '5.0029000000', '49.8122243000', '6830', 'Poupehan', 9, 0);
INSERT INTO `lokatie` VALUES(2261, 'les-hayons', '5.1443705000', '49.8129729000', '6830', 'Les Hayons', 9, 0);
INSERT INTO `lokatie` VALUES(2260, 'bouillon', '5.0681136000', '49.7955726000', '6830', 'Bouillon', 9, 0);
INSERT INTO `lokatie` VALUES(2259, 'chassepierre', '5.2720366000', '49.7093680000', '6824', 'Chassepierre', 9, 0);
INSERT INTO `lokatie` VALUES(2258, 'villers-devant-orval', '5.3751218000', '49.6380977000', '6823', 'Villers-devant-Orval', 9, 0);
INSERT INTO `lokatie` VALUES(2257, 'lacuisine', '5.2969666000', '49.7440858000', '6821', 'Lacuisine', 9, 0);
INSERT INTO `lokatie` VALUES(2256, 'sainte-ccile', '5.2417770000', '49.7288166000', '6820', 'Sainte-Cécile', 9, 0);
INSERT INTO `lokatie` VALUES(2255, 'muno', '5.1757762000', '49.7166638000', '6820', 'Muno', 9, 0);
INSERT INTO `lokatie` VALUES(2254, 'fontenoille', '5.2342519000', '49.7151318000', '6820', 'Fontenoille', 9, 0);
INSERT INTO `lokatie` VALUES(2253, 'florenville', '5.3112041000', '49.7000208000', '6820', 'Florenville', 9, 0);
INSERT INTO `lokatie` VALUES(2252, 'termes', '5.4547742000', '49.7009054000', '6813', 'Termes', 9, 0);
INSERT INTO `lokatie` VALUES(2251, 'suxy', '5.4189218000', '49.7384451000', '6812', 'Suxy', 9, 0);
INSERT INTO `lokatie` VALUES(2250, 'les-bulles', '5.4201396000', '49.7127741000', '6811', 'Les Bulles', 9, 0);
INSERT INTO `lokatie` VALUES(2249, 'jamoigne', '5.4217195000', '49.6964879000', '6810', 'Jamoigne', 9, 0);
INSERT INTO `lokatie` VALUES(2248, 'izel', '5.3739431000', '49.6938073000', '6810', 'Izel', 9, 0);
INSERT INTO `lokatie` VALUES(2247, 'chiny', '5.3414856000', '49.7386283000', '6810', 'Chiny', 9, 0);
INSERT INTO `lokatie` VALUES(2246, 'saint-pierre', '5.3873885000', '49.9037898000', '6800', 'Saint-Pierre', 9, 0);
INSERT INTO `lokatie` VALUES(2245, 'sainte-marie-chevigny', '5.4571417000', '49.9234311000', '6800', 'Sainte-Marie-Chevigny', 9, 0);
INSERT INTO `lokatie` VALUES(2244, 'remagne', '5.4933997000', '49.9766661000', '6800', 'Remagne', 9, 0);
INSERT INTO `lokatie` VALUES(2243, 'recogne', '5.3602981000', '49.9116760000', '6800', 'Recogne', 9, 0);
INSERT INTO `lokatie` VALUES(2242, 'moircy', '5.4670882000', '49.9900016000', '6800', 'Moircy', 9, 0);
INSERT INTO `lokatie` VALUES(2241, 'libramont-chevigny', '5.4233166000', '49.9538337000', '6800', 'Libramont-Chevigny', 9, 0);
INSERT INTO `lokatie` VALUES(2240, 'libramont', '5.4233166000', '49.9538337000', '6800', 'Libramont', 9, 0);
INSERT INTO `lokatie` VALUES(2239, 'freux', '5.4478424000', '49.9694962000', '6800', 'Freux', 9, 0);
INSERT INTO `lokatie` VALUES(2238, 'bras', '5.3948181000', '49.9708125000', '6800', 'Bras', 9, 0);
INSERT INTO `lokatie` VALUES(2237, 'rachecourt', '5.7266366000', '49.5912687000', '6792', 'Rachecourt', 9, 0);
INSERT INTO `lokatie` VALUES(2236, 'halanzy', '5.7427064000', '49.5598858000', '6792', 'Halanzy', 9, 0);
INSERT INTO `lokatie` VALUES(2235, 'athus', '5.8497214000', '49.5792831000', '6791', 'Athus', 9, 0);
INSERT INTO `lokatie` VALUES(2234, 'aubange', '5.8088730000', '49.5608954000', '6790', 'Aubange', 9, 0);
INSERT INTO `lokatie` VALUES(2233, 'habergy', '5.7581624000', '49.6145594000', '6782', 'Habergy', 9, 0);
INSERT INTO `lokatie` VALUES(2232, 'slange', '5.8560275000', '49.6096472000', '6781', 'Sélange', 9, 0);
INSERT INTO `lokatie` VALUES(2231, 'wolkrange', '5.7997392000', '49.6335171000', '6780', 'Wolkrange', 9, 0);
INSERT INTO `lokatie` VALUES(2230, 'messancy', '5.8152462000', '49.5922039000', '6780', 'Messancy', 9, 0);
INSERT INTO `lokatie` VALUES(2229, 'hondelange', '5.8323381000', '49.6324878000', '6780', 'Hondelange', 9, 0);
INSERT INTO `lokatie` VALUES(2228, 'villers-la-loue', '5.4828823000', '49.5747539000', '6769', 'Villers-la-Loue', 9, 0);
INSERT INTO `lokatie` VALUES(2227, 'sommethonne', '5.4465142000', '49.5781306000', '6769', 'Sommethonne', 9, 0);
INSERT INTO `lokatie` VALUES(2226, 'robelmont', '5.5084403000', '49.5951701000', '6769', 'Robelmont', 9, 0);
INSERT INTO `lokatie` VALUES(2225, 'meix-devant-virton', '5.4810942000', '49.6045190000', '6769', 'Meix-devant-Virton', 9, 0);
INSERT INTO `lokatie` VALUES(2224, 'grouville', '5.4255079000', '49.6193864000', '6769', 'Gérouville', 9, 0);
INSERT INTO `lokatie` VALUES(2223, 'torgny', '5.4757525000', '49.5072834000', '6767', 'Torgny', 9, 0);
INSERT INTO `lokatie` VALUES(2222, 'rouvroy', '5.4910644000', '49.5385125000', '6767', 'Rouvroy', 9, 0);
INSERT INTO `lokatie` VALUES(2221, 'lamorteau', '5.4792013000', '49.5262347000', '6767', 'Lamorteau', 9, 0);
INSERT INTO `lokatie` VALUES(2220, 'harnoncourt', '5.5006109000', '49.5343331000', '6767', 'Harnoncourt', 9, 0);
INSERT INTO `lokatie` VALUES(2219, 'dampicourt', '5.4983079000', '49.5530729000', '6767', 'Dampicourt', 9, 0);
INSERT INTO `lokatie` VALUES(2218, 'saint-mard', '5.5296426000', '49.5490336000', '6762', 'Saint-Mard', 9, 0);
INSERT INTO `lokatie` VALUES(2217, 'latour', '5.5630304000', '49.5627592000', '6761', 'Latour', 9, 0);
INSERT INTO `lokatie` VALUES(2216, 'virton', '5.5323145000', '49.5675112000', '6760', 'Virton', 9, 0);
INSERT INTO `lokatie` VALUES(2215, 'ruette', '5.5924543000', '49.5382086000', '6760', 'Ruette', 9, 0);
INSERT INTO `lokatie` VALUES(2214, 'ethe', '5.5794340000', '49.5799360000', '6760', 'Ethe', 9, 0);
INSERT INTO `lokatie` VALUES(2213, 'bleid', '5.6272350000', '49.5695443000', '6760', 'Bleid', 9, 0);
INSERT INTO `lokatie` VALUES(2212, 'signeulx', '5.6384977000', '49.5522338000', '6750', 'Signeulx', 9, 0);
INSERT INTO `lokatie` VALUES(2211, 'mussy-la-ville', '5.6607937000', '49.5698015000', '6750', 'Mussy-la-Ville', 9, 0);
INSERT INTO `lokatie` VALUES(2210, 'musson', '5.7057755000', '49.5588623000', '6750', 'Musson', 9, 0);
INSERT INTO `lokatie` VALUES(2209, 'saint-lger-luxembourg', '5.6546440000', '49.6111035000', '6747', 'Saint-Léger, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2208, 'meix-le-tige', '5.7201633000', '49.6165625000', '6747', 'Meix-le-Tige', 9, 0);
INSERT INTO `lokatie` VALUES(2207, 'chtillon', '5.6985484000', '49.6247719000', '6747', 'Châtillon', 9, 0);
INSERT INTO `lokatie` VALUES(2206, 'buzenol', '5.5988903000', '49.6351637000', '6743', 'Buzenol', 9, 0);
INSERT INTO `lokatie` VALUES(2205, 'chantemelle', '5.6629789000', '49.6473956000', '6742', 'Chantemelle', 9, 0);
INSERT INTO `lokatie` VALUES(2204, 'vance', '5.6706218000', '49.6700541000', '6741', 'Vance', 9, 0);
INSERT INTO `lokatie` VALUES(2203, 'villers-sur-semois', '5.5602429000', '49.6980795000', '6740', 'Villers-sur-Semois', 9, 0);
INSERT INTO `lokatie` VALUES(2202, 'sainte-marie-sur-semois', '5.5632456000', '49.6724414000', '6740', 'Sainte-Marie-sur-Semois', 9, 0);
INSERT INTO `lokatie` VALUES(2201, 'etalle', '5.6012001000', '49.6743407000', '6740', 'Etalle', 9, 0);
INSERT INTO `lokatie` VALUES(2200, 'tintigny', '5.5135393000', '49.6837149000', '6730', 'Tintigny', 9, 0);
INSERT INTO `lokatie` VALUES(2199, 'saint-vincent', '5.4750836000', '49.6772522000', '6730', 'Saint-Vincent', 9, 0);
INSERT INTO `lokatie` VALUES(2198, 'rossignol', '5.4849401000', '49.7173461000', '6730', 'Rossignol', 9, 0);
INSERT INTO `lokatie` VALUES(2197, 'bellefontaine-luxembourg', '5.4970382000', '49.6658060000', '6730', 'Bellefontaine, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2196, 'rulles', '5.5597343000', '49.7169616000', '6724', 'Rulles', 9, 0);
INSERT INTO `lokatie` VALUES(2195, 'marbehan-luxembourg', '5.5359058000', '49.7261297000', '6724', 'Marbehan, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2194, 'houdemont', '5.5832580000', '49.7184539000', '6724', 'Houdemont', 9, 0);
INSERT INTO `lokatie` VALUES(2193, 'habay-la-vieille', '5.6175878000', '49.7136086000', '6723', 'Habay-la-Vieille', 9, 0);
INSERT INTO `lokatie` VALUES(2192, 'anlier', '5.6154640000', '49.7649623000', '6721', 'Anlier', 9, 0);
INSERT INTO `lokatie` VALUES(2191, 'hachy', '5.6806620000', '49.7013388000', '6720', 'Hachy', 9, 0);
INSERT INTO `lokatie` VALUES(2190, 'habay-la-neuve', '5.6486351000', '49.7295756000', '6720', 'Habay-la-Neuve', 9, 0);
INSERT INTO `lokatie` VALUES(2189, 'habay', '5.6634857000', '49.7267434000', '6720', 'Habay', 9, 0);
INSERT INTO `lokatie` VALUES(2188, 'tontelange', '5.8082365000', '49.7270049000', '6717', 'Tontelange', 9, 0);
INSERT INTO `lokatie` VALUES(2187, 'thiaumont', '5.7305049000', '49.7162292000', '6717', 'Thiaumont', 9, 0);
INSERT INTO `lokatie` VALUES(2186, 'nothomb', '5.7876058000', '49.7708968000', '6717', 'Nothomb', 9, 0);
INSERT INTO `lokatie` VALUES(2185, 'nobressart', '5.7187648000', '49.7396349000', '6717', 'Nobressart', 9, 0);
INSERT INTO `lokatie` VALUES(2184, 'attert', '5.7884452000', '49.7508361000', '6717', 'Attert', 9, 0);
INSERT INTO `lokatie` VALUES(2183, 'autelbas', '5.8492601000', '49.6509257000', '6706', 'Autelbas', 9, 0);
INSERT INTO `lokatie` VALUES(2182, 'guirsch', '5.8362962000', '49.7223267000', '6704', 'Guirsch', 9, 0);
INSERT INTO `lokatie` VALUES(2181, 'toernich', '5.7781761000', '49.6521263000', '6700', 'Toernich', 9, 0);
INSERT INTO `lokatie` VALUES(2180, 'heinsch', '5.7436743000', '49.6989076000', '6700', 'Heinsch', 9, 0);
INSERT INTO `lokatie` VALUES(2179, 'bonnert', '5.8184409000', '49.7109446000', '6700', 'Bonnert', 9, 0);
INSERT INTO `lokatie` VALUES(2178, 'arlon', '5.8168223000', '49.6843571000', '6700', 'Arlon', 9, 0);
INSERT INTO `lokatie` VALUES(2177, 'grand-halleux', '5.9077572000', '50.3252998000', '6698', 'Grand-Halleux', 9, 0);
INSERT INTO `lokatie` VALUES(2176, 'petit-thier', '5.9894564000', '50.3026042000', '6692', 'Petit-Thier', 9, 0);
INSERT INTO `lokatie` VALUES(2175, 'vielsalm', '5.9152200000', '50.2863052000', '6690', 'Vielsalm', 9, 0);
INSERT INTO `lokatie` VALUES(2174, 'bihain', '5.8050125000', '50.2385434000', '6690', 'Bihain', 9, 0);
INSERT INTO `lokatie` VALUES(2173, 'longchamps-luxembourg', '5.6798603000', '50.0548009000', '6688', 'Longchamps, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2172, 'bertogne', '5.6808856000', '50.0908293000', '6687', 'Bertogne', 9, 0);
INSERT INTO `lokatie` VALUES(2171, 'flamierge', '5.6056084000', '50.0584121000', '6686', 'Flamierge', 9, 0);
INSERT INTO `lokatie` VALUES(2170, 'lavacherie', '5.4780506000', '50.0438986000', '6681', 'Lavacherie', 9, 0);
INSERT INTO `lokatie` VALUES(2169, 'tillet', '5.5297218000', '50.0104192000', '6680', 'Tillet', 9, 0);
INSERT INTO `lokatie` VALUES(2168, 'sainte-ode', '5.5480905000', '50.0199719000', '6680', 'Sainte-Ode', 9, 0);
INSERT INTO `lokatie` VALUES(2167, 'amberloup', '5.5250491000', '50.0282561000', '6680', 'Amberloup', 9, 0);
INSERT INTO `lokatie` VALUES(2166, 'montleban', '5.8376462000', '50.2120826000', '6674', 'Montleban', 9, 0);
INSERT INTO `lokatie` VALUES(2165, 'cherain', '5.8789963000', '50.1686749000', '6673', 'Cherain', 9, 0);
INSERT INTO `lokatie` VALUES(2164, 'beho', '5.9874998000', '50.2044509000', '6672', 'Beho', 9, 0);
INSERT INTO `lokatie` VALUES(2163, 'bovigny', '5.9418410000', '50.2274685000', '6671', 'Bovigny', 9, 0);
INSERT INTO `lokatie` VALUES(2162, 'limerl', '5.9240994000', '50.1577103000', '6670', 'Limerlé', 9, 0);
INSERT INTO `lokatie` VALUES(2161, 'gouvy', '5.9426256000', '50.1856075000', '6670', 'Gouvy', 9, 0);
INSERT INTO `lokatie` VALUES(2160, 'wibrin', '5.7295649000', '50.1761464000', '6666', 'Wibrin', 9, 0);
INSERT INTO `lokatie` VALUES(2159, 'mabompr', '5.7170744000', '50.1148360000', '6663', 'Mabompré', 9, 0);
INSERT INTO `lokatie` VALUES(2158, 'tavigny', '5.8413112000', '50.1086488000', '6662', 'Tavigny', 9, 0);
INSERT INTO `lokatie` VALUES(2157, 'tailles', '5.7437507000', '50.2273877000', '6661', 'Tailles', 9, 0);
INSERT INTO `lokatie` VALUES(2156, 'mont-luxembourg', '5.7676992000', '50.1537399000', '6661', 'Mont, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2155, 'nadrin', '5.6843161000', '50.1581733000', '6660', 'Nadrin', 9, 0);
INSERT INTO `lokatie` VALUES(2154, 'houffalize', '5.7889027000', '50.1331714000', '6660', 'Houffalize', 9, 0);
INSERT INTO `lokatie` VALUES(2153, 'juseret', '5.5414584000', '49.8917062000', '6642', 'Juseret', 9, 0);
INSERT INTO `lokatie` VALUES(2152, 'vaux-sur-sre', '5.6202645000', '49.9444556000', '6640', 'Vaux-sur-Sûre', 9, 0);
INSERT INTO `lokatie` VALUES(2151, 'vaux-lez-rosires', '5.5659053000', '49.9102794000', '6640', 'Vaux-lez-Rosières', 9, 0);
INSERT INTO `lokatie` VALUES(2150, 'sibret', '5.6354543000', '49.9713825000', '6640', 'Sibret', 9, 0);
INSERT INTO `lokatie` VALUES(2149, 'nives', '5.6016096000', '49.9126564000', '6640', 'Nives', 9, 0);
INSERT INTO `lokatie` VALUES(2148, 'morhet', '5.5842662000', '49.9635597000', '6640', 'Morhet', 9, 0);
INSERT INTO `lokatie` VALUES(2147, 'hompr', '5.6858059000', '49.9440778000', '6640', 'Hompré', 9, 0);
INSERT INTO `lokatie` VALUES(2146, 'tintange', '5.7518160000', '49.8787001000', '6637', 'Tintange', 9, 0);
INSERT INTO `lokatie` VALUES(2145, 'hollange', '5.6871693000', '49.9066188000', '6637', 'Hollange', 9, 0);
INSERT INTO `lokatie` VALUES(2144, 'fauvillers', '5.6640269000', '49.8514130000', '6637', 'Fauvillers', 9, 0);
INSERT INTO `lokatie` VALUES(2143, 'martelange', '5.7290052000', '49.8055663000', '6630', 'Martelange', 9, 0);
INSERT INTO `lokatie` VALUES(2142, 'wardin', '5.7883722000', '49.9911621000', '6600', 'Wardin', 9, 0);
INSERT INTO `lokatie` VALUES(2141, 'villers-la-bonne-eau', '5.7479368000', '49.9340029000', '6600', 'Villers-la-Bonne-Eau', 9, 0);
INSERT INTO `lokatie` VALUES(2140, 'noville-luxembourg', '5.7605768000', '50.0635748000', '6600', 'Noville, Luxembourg', 9, 0);
INSERT INTO `lokatie` VALUES(2139, 'longvilly', '5.8359798000', '50.0250444000', '6600', 'Longvilly', 9, 0);
INSERT INTO `lokatie` VALUES(2138, 'bastogne', '5.7214881000', '50.0055343000', '6600', 'Bastogne', 9, 0);
INSERT INTO `lokatie` VALUES(2137, 'villers-la-ville', '4.5302930000', '50.5774372000', '1495', 'Villers-la-Ville', 8, 0);
INSERT INTO `lokatie` VALUES(2136, 'tilly', '4.5516293000', '50.5608132000', '1495', 'Tilly', 8, 0);
INSERT INTO `lokatie` VALUES(2135, 'sart-dames-avelines', '4.4917064000', '50.5683679000', '1495', 'Sart-Dames-Avelines', 8, 0);
INSERT INTO `lokatie` VALUES(2134, 'mellery', '4.5696062000', '50.5827017000', '1495', 'Mellery', 8, 0);
INSERT INTO `lokatie` VALUES(2133, 'marbais-brw', '4.5334333000', '50.5453903000', '1495', 'Marbais (Br.W.)', 8, 0);
INSERT INTO `lokatie` VALUES(2132, 'court-saint-etienne', '4.5597931000', '50.6214692000', '1490', 'Court-Saint-Etienne', 8, 0);
INSERT INTO `lokatie` VALUES(2131, 'tubize', '4.2043037000', '50.6934705000', '1480', 'Tubize', 8, 0);
INSERT INTO `lokatie` VALUES(2130, 'saintes', '4.1606222000', '50.7038093000', '1480', 'Saintes', 8, 0);
INSERT INTO `lokatie` VALUES(2129, 'oisquercq', '4.2194552000', '50.6698901000', '1480', 'Oisquercq', 8, 0);
INSERT INTO `lokatie` VALUES(2128, 'clabecq', '4.2217969000', '50.6898377000', '1480', 'Clabecq', 8, 0);
INSERT INTO `lokatie` VALUES(2127, 'houtain-le-val', '4.4102122000', '50.5804921000', '1476', 'Houtain-le-Val', 8, 0);
INSERT INTO `lokatie` VALUES(2126, 'ways', '4.4766613000', '50.6272880000', '1474', 'Ways', 8, 0);
INSERT INTO `lokatie` VALUES(2125, 'glabais', '4.4430615000', '50.6311704000', '1473', 'Glabais', 8, 0);
INSERT INTO `lokatie` VALUES(2124, 'vieux-genappe', '4.4043555000', '50.6222503000', '1472', 'Vieux-Genappe', 8, 0);
INSERT INTO `lokatie` VALUES(2123, 'loupoigne', '4.4346610000', '50.5977336000', '1471', 'Loupoigne', 8, 0);
INSERT INTO `lokatie` VALUES(2122, 'genappe', '4.4507227000', '50.6110387000', '1470', 'Genappe', 8, 0);
INSERT INTO `lokatie` VALUES(2121, 'bousval', '4.5084794000', '50.6161587000', '1470', 'Bousval', 8, 0);
INSERT INTO `lokatie` VALUES(2120, 'baisy-thy', '4.4653574000', '50.5937472000', '1470', 'Baisy-Thy', 8, 0);
INSERT INTO `lokatie` VALUES(2119, 'haut-ittre', '4.2937473000', '50.6497513000', '1461', 'Haut-Ittre', 8, 0);
INSERT INTO `lokatie` VALUES(2118, 'virginal-samme', '4.2110419000', '50.6409938000', '1460', 'Virginal-Samme', 8, 0);
INSERT INTO `lokatie` VALUES(2117, 'ittre', '4.2638335000', '50.6502347000', '1460', 'Ittre', 8, 0);
INSERT INTO `lokatie` VALUES(2116, 'walhain-saint-paul', '4.6952466000', '50.6178874000', '1457', 'Walhain-Saint-Paul', 8, 0);
INSERT INTO `lokatie` VALUES(2115, 'walhain', '4.6872076000', '50.6371980000', '1457', 'Walhain', 8, 0);
INSERT INTO `lokatie` VALUES(2114, 'tourinnes-saint-lambert', '4.7203225000', '50.6398423000', '1457', 'Tourinnes-Saint-Lambert', 8, 0);
INSERT INTO `lokatie` VALUES(2113, 'nil-saint-vincent-saint-martin', '4.6735162000', '50.6398882000', '1457', 'Nil-Saint-Vincent-Saint-Martin', 8, 0);
INSERT INTO `lokatie` VALUES(2112, 'saint-gry', '4.6117508000', '50.5801683000', '1450', 'Saint-Géry', 8, 0);
INSERT INTO `lokatie` VALUES(2111, 'gentinnes', '4.6028737000', '50.5813076000', '1450', 'Gentinnes', 8, 0);
INSERT INTO `lokatie` VALUES(2110, 'cortil-noirmont', '4.6401579000', '50.5871743000', '1450', 'Cortil-Noirmont', 8, 0);
INSERT INTO `lokatie` VALUES(2109, 'chastre-villeroux-blanmont', '4.6361833000', '50.6205998000', '1450', 'Chastre-Villeroux-Blanmont', 8, 0);
INSERT INTO `lokatie` VALUES(2108, 'chastre', '4.6376382000', '50.6080816000', '1450', 'Chastre', 8, 0);
INSERT INTO `lokatie` VALUES(2107, 'wauthier-braine', '4.2985007000', '50.6801449000', '1440', 'Wauthier-Braine', 8, 0);
INSERT INTO `lokatie` VALUES(2106, 'braine-le-chteau', '4.2664244000', '50.6820742000', '1440', 'Braine-le-Château', 8, 0);
INSERT INTO `lokatie` VALUES(2105, 'mont-saint-guibert', '4.6106473000', '50.6341474000', '1435', 'Mont-Saint-Guibert', 8, 0);
INSERT INTO `lokatie` VALUES(2104, 'hvillers', '4.6168887000', '50.6223581000', '1435', 'Hévillers', 8, 0);
INSERT INTO `lokatie` VALUES(2103, 'corbais', '4.6551777000', '50.6458581000', '1435', 'Corbais', 8, 0);
INSERT INTO `lokatie` VALUES(2102, 'rebecq-rognon', '4.1331594000', '50.6651435000', '1430', 'Rebecq-Rognon', 8, 0);
INSERT INTO `lokatie` VALUES(2101, 'rebecq', '4.1215403000', '50.6793466000', '1430', 'Rebecq', 8, 0);
INSERT INTO `lokatie` VALUES(2100, 'quenast', '4.1561966000', '50.6717547000', '1430', 'Quenast', 8, 0);
INSERT INTO `lokatie` VALUES(2099, 'bierghes', '4.1195047000', '50.6958945000', '1430', 'Bierghes', 8, 0);
INSERT INTO `lokatie` VALUES(2098, 'lillois-witterze', '4.3705251000', '50.6443017000', '1428', 'Lillois-Witterzée', 8, 0);
INSERT INTO `lokatie` VALUES(2097, 'ophain-bois-seigneur-isaac', '4.3350676000', '50.6560168000', '1421', 'Ophain-Bois-Seigneur-Isaac', 8, 0);
INSERT INTO `lokatie` VALUES(2096, 'braine-l039alleud', '4.3538379000', '50.6969022000', '1420', 'Braine-l&#039;Alleud', 8, 0);
INSERT INTO `lokatie` VALUES(2095, 'waterloo', '4.4049735000', '50.7053833000', '1410', 'Waterloo', 8, 0);
INSERT INTO `lokatie` VALUES(2094, 'bornival', '4.2619990000', '50.6041731000', '1404', 'Bornival', 8, 0);
INSERT INTO `lokatie` VALUES(2093, 'thines', '4.3871558000', '50.5917437000', '1402', 'Thines', 8, 0);
INSERT INTO `lokatie` VALUES(2092, 'baulers', '4.3533583000', '50.6137787000', '1401', 'Baulers', 8, 0);
INSERT INTO `lokatie` VALUES(2091, 'nivelles', '4.3232325000', '50.5970933000', '1400', 'Nivelles', 8, 0);
INSERT INTO `lokatie` VALUES(2090, 'monstreux', '4.2887585000', '50.5980612000', '1400', 'Monstreux', 8, 0);
INSERT INTO `lokatie` VALUES(2089, 'nethen', '4.6740569000', '50.7837562000', '1390', 'Nethen', 8, 0);
INSERT INTO `lokatie` VALUES(2088, 'grez-doiceau', '4.6960595000', '50.7382610000', '1390', 'Grez-Doiceau', 8, 0);
INSERT INTO `lokatie` VALUES(2087, 'bossut-gottechain', '4.6952210000', '50.7613902000', '1390', 'Bossut-Gottechain', 8, 0);
INSERT INTO `lokatie` VALUES(2086, 'biez', '4.7037283000', '50.7268251000', '1390', 'Biez', 8, 0);
INSERT INTO `lokatie` VALUES(2085, 'archennes', '4.6717931000', '50.7514444000', '1390', 'Archennes', 8, 0);
INSERT INTO `lokatie` VALUES(2084, 'plancenoit', '4.4297572000', '50.6605078000', '1380', 'Plancenoit', 8, 0);
INSERT INTO `lokatie` VALUES(2083, 'ohain', '4.4706060000', '50.6960314000', '1380', 'Ohain', 8, 0);
INSERT INTO `lokatie` VALUES(2082, 'maransart', '4.4617253000', '50.6602939000', '1380', 'Maransart', 8, 0);
INSERT INTO `lokatie` VALUES(2081, 'lasne-chapelle-saint-lambert', '4.4843197000', '50.6865147000', '1380', 'Lasne-Chapelle-Saint-Lambert', 8, 0);
INSERT INTO `lokatie` VALUES(2080, 'lasne', '4.4843197000', '50.6865147000', '1380', 'Lasne', 8, 0);
INSERT INTO `lokatie` VALUES(2079, 'couture-saint-germain', '4.4784141000', '50.6739910000', '1380', 'Couture-Saint-Germain', 8, 0);
INSERT INTO `lokatie` VALUES(2078, 'ztrud-lumay', '4.8869490000', '50.7585589000', '1370', 'Zétrud-Lumay', 8, 0);
INSERT INTO `lokatie` VALUES(2077, 'saint-remy-geest', '4.8587562000', '50.7465971000', '1370', 'Saint-Remy-Geest', 8, 0);
INSERT INTO `lokatie` VALUES(2076, 'saint-jean-geest', '4.8954764000', '50.7396628000', '1370', 'Saint-Jean-Geest', 8, 0);
INSERT INTO `lokatie` VALUES(2075, 'pitrain', '4.9173799000', '50.7258732000', '1370', 'Piétrain', 8, 0);
INSERT INTO `lokatie` VALUES(2074, 'mlin', '4.8282830000', '50.7402652000', '1370', 'Mélin', 8, 0);
INSERT INTO `lokatie` VALUES(2073, 'lathuy', '4.8237613000', '50.7231571000', '1370', 'Lathuy', 8, 0);
INSERT INTO `lokatie` VALUES(2072, 'jodoigne-souveraine', '4.8422679000', '50.7078833000', '1370', 'Jodoigne-Souveraine', 8, 0);
INSERT INTO `lokatie` VALUES(2071, 'jodoigne', '4.8638493000', '50.7231670000', '1370', 'Jodoigne', 8, 0);
INSERT INTO `lokatie` VALUES(2070, 'jauchelette', '4.8434317000', '50.6866594000', '1370', 'Jauchelette', 8, 0);
INSERT INTO `lokatie` VALUES(2069, 'dongelberg', '4.8196516000', '50.7027952000', '1370', 'Dongelberg', 8, 0);
INSERT INTO `lokatie` VALUES(2068, 'ramillies-offus', '4.9149777000', '50.6363660000', '1367', 'Ramillies-Offus', 8, 0);
INSERT INTO `lokatie` VALUES(2067, 'mont-saint-andr', '4.8632195000', '50.6551099000', '1367', 'Mont-Saint-André', 8, 0);
INSERT INTO `lokatie` VALUES(2066, 'huppaye', '4.8924418000', '50.6920854000', '1367', 'Huppaye', 8, 0);
INSERT INTO `lokatie` VALUES(2065, 'grand-rosire-hottomont', '4.8671681000', '50.6324167000', '1367', 'Grand-Rosière-Hottomont', 8, 0);
INSERT INTO `lokatie` VALUES(2064, 'grompont', '4.8802622000', '50.6469310000', '1367', 'Gérompont', 8, 0);
INSERT INTO `lokatie` VALUES(2063, 'geest-grompont-petit-rosire', '4.8604311000', '50.6436340000', '1367', 'Geest-Gérompont-Petit-Rosière', 8, 0);
INSERT INTO `lokatie` VALUES(2062, 'bomal-brw', '4.8739731000', '50.6680410000', '1367', 'Bomal (Br.W.)', 8, 0);
INSERT INTO `lokatie` VALUES(2061, 'autre-eglise', '4.9242891000', '50.6633359000', '1367', 'Autre-Eglise', 8, 0);
INSERT INTO `lokatie` VALUES(2060, 'thorembais-saint-trond', '4.7841771000', '50.6356332000', '1360', 'Thorembais-Saint-Trond', 8, 0);
INSERT INTO `lokatie` VALUES(2059, 'thorembais-les-bguines', '4.8178972000', '50.6584844000', '1360', 'Thorembais-les-Béguines', 8, 0);
INSERT INTO `lokatie` VALUES(2058, 'perwez', '4.8120015000', '50.6223778000', '1360', 'Perwez', 8, 0);
INSERT INTO `lokatie` VALUES(2057, 'orbais', '4.7632035000', '50.6375771000', '1360', 'Orbais', 8, 0);
INSERT INTO `lokatie` VALUES(2056, 'malves-sainte-marie-wastines', '4.7919993000', '50.6583281000', '1360', 'Malèves-Sainte-Marie-Wastines', 8, 0);
INSERT INTO `lokatie` VALUES(2055, 'opheylissem', '4.9782549000', '50.7482134000', '1357', 'Opheylissem', 8, 0);
INSERT INTO `lokatie` VALUES(2054, 'neerheylissem', '4.9881791000', '50.7569259000', '1357', 'Neerheylissem', 8, 0);
INSERT INTO `lokatie` VALUES(2053, 'linsmeau', '5.0033498000', '50.7331091000', '1357', 'Linsmeau', 8, 0);
INSERT INTO `lokatie` VALUES(2052, 'hlcine', '4.9829359000', '50.7497791000', '1357', 'Hélécine', 8, 0);
INSERT INTO `lokatie` VALUES(2051, 'orp-le-grand', '4.9905153000', '50.7035039000', '1350', 'Orp-le-Grand', 8, 0);
INSERT INTO `lokatie` VALUES(2050, 'orp-jauche', '4.9719204000', '50.6877943000', '1350', 'Orp-Jauche', 8, 0);
INSERT INTO `lokatie` VALUES(2049, 'noduwez', '4.9641114000', '50.7289435000', '1350', 'Noduwez', 8, 0);
INSERT INTO `lokatie` VALUES(2048, 'marilles', '4.9526985000', '50.7071532000', '1350', 'Marilles', 8, 0);
INSERT INTO `lokatie` VALUES(2047, 'jauche', '4.9719204000', '50.6877943000', '1350', 'Jauche', 8, 0);
INSERT INTO `lokatie` VALUES(2046, 'jandrain-jandrenouille', '4.9786601000', '50.6740783000', '1350', 'Jandrain-Jandrenouille', 8, 0);
INSERT INTO `lokatie` VALUES(2045, 'folx-les-caves', '4.9368627000', '50.6616032000', '1350', 'Folx-les-Caves', 8, 0);
INSERT INTO `lokatie` VALUES(2044, 'enines', '4.9259890000', '50.6947063000', '1350', 'Enines', 8, 0);
INSERT INTO `lokatie` VALUES(2043, 'louvain-la-neuve', '4.6151693000', '50.6738567000', '1348', 'Louvain-la-Neuve', 8, 0);
INSERT INTO `lokatie` VALUES(2042, 'limelette', '4.5601556000', '50.6812199000', '1342', 'Limelette', 8, 0);
INSERT INTO `lokatie` VALUES(2041, 'croux-mousty', '4.5319998000', '50.6615232000', '1341', 'Céroux-Mousty', 8, 0);
INSERT INTO `lokatie` VALUES(2040, 'ottignies-louvain-la-neuve', '4.5859684000', '50.6672105000', '1340', 'Ottignies-Louvain-la-Neuve', 8, 0);
INSERT INTO `lokatie` VALUES(2039, 'ottignies', '4.5859684000', '50.6672105000', '1340', 'Ottignies', 8, 0);
INSERT INTO `lokatie` VALUES(2038, 'genval', '4.4950562000', '50.7227540000', '1332', 'Genval', 8, 0);
INSERT INTO `lokatie` VALUES(2037, 'rosires', '4.5437157000', '50.7338771000', '1331', 'Rosières', 8, 0);
INSERT INTO `lokatie` VALUES(2036, 'rixensart', '4.5306325000', '50.7109736000', '1330', 'Rixensart', 8, 0);
INSERT INTO `lokatie` VALUES(2035, 'longueville', '4.7391679000', '50.7026995000', '1325', 'Longueville', 8, 0);
INSERT INTO `lokatie` VALUES(2034, 'dion-valmont', '4.6614575000', '50.7162660000', '1325', 'Dion-Valmont', 8, 0);
INSERT INTO `lokatie` VALUES(2033, 'corroy-le-grand', '4.6752523000', '50.6615767000', '1325', 'Corroy-le-Grand', 8, 0);
INSERT INTO `lokatie` VALUES(2032, 'chaumont-gistoux', '4.7227148000', '50.6786039000', '1325', 'Chaumont-Gistoux', 8, 0);
INSERT INTO `lokatie` VALUES(2031, 'bonlez', '4.6894627000', '50.7018874000', '1325', 'Bonlez', 8, 0);
INSERT INTO `lokatie` VALUES(2030, 'tourinnes-la-grosse', '4.7464118000', '50.7783538000', '1320', 'Tourinnes-la-Grosse', 8, 0);
INSERT INTO `lokatie` VALUES(2029, 'nodebais', '4.7335650000', '50.7730712000', '1320', 'Nodebais', 8, 0);
INSERT INTO `lokatie` VALUES(2028, 'l039ecluse', '4.8318926000', '50.7718833000', '1320', 'l&#039;Ecluse', 8, 0);
INSERT INTO `lokatie` VALUES(2027, 'hamme-mille', '4.7196473000', '50.7793197000', '1320', 'Hamme-Mille', 8, 0);
INSERT INTO `lokatie` VALUES(2026, 'beauvechain', '4.7725397000', '50.7802279000', '1320', 'Beauvechain', 8, 0);
INSERT INTO `lokatie` VALUES(2025, 'roux-miroir', '4.7838573000', '50.7105501000', '1315', 'Roux-Miroir', 8, 0);
INSERT INTO `lokatie` VALUES(2024, 'pitrebais', '4.7481673000', '50.7320595000', '1315', 'Piétrebais', 8, 0);
INSERT INTO `lokatie` VALUES(2023, 'opprebais', '4.7954859000', '50.6816945000', '1315', 'Opprebais', 8, 0);
INSERT INTO `lokatie` VALUES(2022, 'incourt', '4.7982852000', '50.6922225000', '1315', 'Incourt', 8, 0);
INSERT INTO `lokatie` VALUES(2021, 'glimes', '4.8381831000', '50.6798192000', '1315', 'Glimes', 8, 0);
INSERT INTO `lokatie` VALUES(2020, 'la-hulpe', '4.4594749000', '50.7345253000', '1310', 'La Hulpe', 8, 0);
INSERT INTO `lokatie` VALUES(2019, 'bierges', '4.5695740000', '50.7198592000', '1301', 'Bierges', 8, 0);
INSERT INTO `lokatie` VALUES(2018, 'wavre', '4.6107147000', '50.7168831000', '1300', 'Wavre', 8, 0);
INSERT INTO `lokatie` VALUES(2017, 'limal', '4.5737166000', '50.6934917000', '1300', 'Limal', 8, 0);
INSERT INTO `lokatie` VALUES(2016, 'lierneux', '5.7945885000', '50.2836594000', '4990', 'Lierneux', 7, 0);
INSERT INTO `lokatie` VALUES(2015, 'bra', '5.7321886000', '50.3238889000', '4990', 'Bra', 7, 0);
INSERT INTO `lokatie` VALUES(2014, 'arbrefontaine', '5.8347888000', '50.3001693000', '4990', 'Arbrefontaine', 7, 0);
INSERT INTO `lokatie` VALUES(2013, 'stoumont', '5.8085993000', '50.4068711000', '4987', 'Stoumont', 7, 0);
INSERT INTO `lokatie` VALUES(2012, 'rahier', '5.7785439000', '50.3859041000', '4987', 'Rahier', 7, 0);
INSERT INTO `lokatie` VALUES(2011, 'lorc', '5.7346061000', '50.4170229000', '4987', 'Lorcé', 7, 0);
INSERT INTO `lokatie` VALUES(2010, 'la-gleize', '5.8463101000', '50.4103784000', '4987', 'La Gleize', 7, 0);
INSERT INTO `lokatie` VALUES(2009, 'chevron', '5.7303604000', '50.3813902000', '4987', 'Chevron', 7, 0);
INSERT INTO `lokatie` VALUES(2008, 'basse-bodeux', '5.7923506000', '50.3591924000', '4983', 'Basse-Bodeux', 7, 0);
INSERT INTO `lokatie` VALUES(2007, 'wanne', '5.9216765000', '50.3550573000', '4980', 'Wanne', 7, 0);
INSERT INTO `lokatie` VALUES(2006, 'trois-ponts', '5.8704037000', '50.3712947000', '4980', 'Trois-Ponts', 7, 0);
INSERT INTO `lokatie` VALUES(2005, 'fosse-liege', '5.8411759000', '50.3411387000', '4980', 'Fosse, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(2004, 'stavelot', '5.9290001000', '50.3941813000', '4970', 'Stavelot', 7, 0);
INSERT INTO `lokatie` VALUES(2003, 'francorchamps', '5.9523621000', '50.4542686000', '4970', 'Francorchamps', 7, 0);
INSERT INTO `lokatie` VALUES(2002, 'malmedy', '6.0332144000', '50.4254168000', '4960', 'Malmedy', 7, 0);
INSERT INTO `lokatie` VALUES(2001, 'beverc', '6.0388619000', '50.4417346000', '4960', 'Bevercé', 7, 0);
INSERT INTO `lokatie` VALUES(2000, 'bellevaux-ligneuville', '6.0542306000', '50.3756174000', '4960', 'Bellevaux-Ligneuville', 7, 0);
INSERT INTO `lokatie` VALUES(1999, 'waimesweismes', '6.1114200000', '50.4153542000', '4950', 'Waimes/Weismes', 7, 0);
INSERT INTO `lokatie` VALUES(1998, 'sourbrodt', '6.1193101000', '50.4726622000', '4950', 'Sourbrodt', 7, 0);
INSERT INTO `lokatie` VALUES(1997, 'robertville', '6.1221382000', '50.4537157000', '4950', 'Robertville', 7, 0);
INSERT INTO `lokatie` VALUES(1996, 'faymonville', '6.1389171000', '50.4046727000', '4950', 'Faymonville', 7, 0);
INSERT INTO `lokatie` VALUES(1995, 'sougn-remouchamps', '5.7054278000', '50.4824779000', '4920', 'Sougné-Remouchamps', 7, 0);
INSERT INTO `lokatie` VALUES(1994, 'harz', '5.6671018000', '50.4405513000', '4920', 'Harzé', 7, 0);
INSERT INTO `lokatie` VALUES(1993, 'ernonheid', '5.6663160000', '50.4022333000', '4920', 'Ernonheid', 7, 0);
INSERT INTO `lokatie` VALUES(1992, 'aywaille', '5.6751821000', '50.4736486000', '4920', 'Aywaille', 7, 0);
INSERT INTO `lokatie` VALUES(1991, 'theux', '5.8131344000', '50.5355799000', '4910', 'Theux', 7, 0);
INSERT INTO `lokatie` VALUES(1990, 'polleur', '5.8806628000', '50.5390306000', '4910', 'Polleur', 7, 0);
INSERT INTO `lokatie` VALUES(1989, 'la-reid', '5.7905238000', '50.4893885000', '4910', 'La Reid', 7, 0);
INSERT INTO `lokatie` VALUES(1988, 'spa', '5.8681801000', '50.4798137000', '4900', 'Spa', 7, 0);
INSERT INTO `lokatie` VALUES(1987, 'thimister-clermont', '5.8817619000', '50.6662360000', '4890', 'Thimister-Clermont', 7, 0);
INSERT INTO `lokatie` VALUES(1986, 'thimister', '5.8638448000', '50.6536029000', '4890', 'Thimister', 7, 0);
INSERT INTO `lokatie` VALUES(1985, 'clermont-liege', '5.8817619000', '50.6662360000', '4890', 'Clermont, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1984, 'aubel', '5.8576481000', '50.7038984000', '4880', 'Aubel', 7, 0);
INSERT INTO `lokatie` VALUES(1983, 'olne', '5.7330545000', '50.5956245000', '4877', 'Olne', 7, 0);
INSERT INTO `lokatie` VALUES(1982, 'trooz', '5.6946837000', '50.5698552000', '4870', 'Trooz', 7, 0);
INSERT INTO `lokatie` VALUES(1981, 'nessonvaux', '5.7350082000', '50.5748425000', '4870', 'Nessonvaux', 7, 0);
INSERT INTO `lokatie` VALUES(1980, 'fraipont', '5.7491553000', '50.5635306000', '4870', 'Fraipont', 7, 0);
INSERT INTO `lokatie` VALUES(1979, 'fort', '5.7002984000', '50.5842263000', '4870', 'Forêt', 7, 0);
INSERT INTO `lokatie` VALUES(1978, 'soiron', '5.7835057000', '50.5931291000', '4861', 'Soiron', 7, 0);
INSERT INTO `lokatie` VALUES(1977, 'wegnez', '5.8166465000', '50.5788609000', '4860', 'Wegnez', 7, 0);
INSERT INTO `lokatie` VALUES(1976, 'pepinster', '5.8033955000', '50.5666380000', '4860', 'Pepinster', 7, 0);
INSERT INTO `lokatie` VALUES(1975, 'cornesse', '5.7909717000', '50.5746947000', '4860', 'Cornesse', 7, 0);
INSERT INTO `lokatie` VALUES(1974, 'hombourg', '5.9254218000', '50.7213076000', '4852', 'Hombourg', 7, 0);
INSERT INTO `lokatie` VALUES(1973, 'sippenaeken', '5.9334672000', '50.7508123000', '4851', 'Sippenaeken', 7, 0);
INSERT INTO `lokatie` VALUES(1972, 'gemmenich', '5.9945256000', '50.7465517000', '4851', 'Gemmenich', 7, 0);
INSERT INTO `lokatie` VALUES(1971, 'plombires', '5.9617155000', '50.7367908000', '4850', 'Plombières', 7, 0);
INSERT INTO `lokatie` VALUES(1970, 'moresnet', '5.9891108000', '50.7212015000', '4850', 'Moresnet', 7, 0);
INSERT INTO `lokatie` VALUES(1969, 'montzen', '5.9619924000', '50.7077480000', '4850', 'Montzen', 7, 0);
INSERT INTO `lokatie` VALUES(1968, 'sart-lez-spa', '5.9336880000', '50.5170270000', '4845', 'Sart-lez-Spa', 7, 0);
INSERT INTO `lokatie` VALUES(1967, 'jalhay', '5.9646657000', '50.5586327000', '4845', 'Jalhay', 7, 0);
INSERT INTO `lokatie` VALUES(1966, 'henri-chapelle', '5.9271962000', '50.6691380000', '4841', 'Henri-Chapelle', 7, 0);
INSERT INTO `lokatie` VALUES(1965, 'welkenraedt', '5.9630388000', '50.6568973000', '4840', 'Welkenraedt', 7, 0);
INSERT INTO `lokatie` VALUES(1964, 'membach', '5.9948927000', '50.6191079000', '4837', 'Membach', 7, 0);
INSERT INTO `lokatie` VALUES(1963, 'baelen-liege', '5.9703451000', '50.6308880000', '4837', 'Baelen, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1962, 'go', '5.9498994000', '50.5951412000', '4834', 'Goé', 7, 0);
INSERT INTO `lokatie` VALUES(1961, 'bilstain', '5.9184812000', '50.6279490000', '4831', 'Bilstain', 7, 0);
INSERT INTO `lokatie` VALUES(1960, 'limbourg', '5.9357239000', '50.6036651000', '4830', 'Limbourg', 7, 0);
INSERT INTO `lokatie` VALUES(1959, 'andrimont', '5.8910045000', '50.6189389000', '4821', 'Andrimont', 7, 0);
INSERT INTO `lokatie` VALUES(1958, 'dison', '5.8509177000', '50.6105586000', '4820', 'Dison', 7, 0);
INSERT INTO `lokatie` VALUES(1957, 'heusy', '5.8723411000', '50.5756860000', '4802', 'Heusy', 7, 0);
INSERT INTO `lokatie` VALUES(1956, 'stembert', '5.9019344000', '50.5949834000', '4801', 'Stembert', 7, 0);
INSERT INTO `lokatie` VALUES(1955, 'verviers', '5.8612512000', '50.5923688000', '4800', 'Verviers', 7, 0);
INSERT INTO `lokatie` VALUES(1954, 'petit-rechain', '5.8342658000', '50.6148361000', '4800', 'Petit-Rechain', 7, 0);
INSERT INTO `lokatie` VALUES(1953, 'lambermont', '5.8318129000', '50.5906093000', '4800', 'Lambermont', 7, 0);
INSERT INTO `lokatie` VALUES(1952, 'ensival', '5.8419452000', '50.5807649000', '4800', 'Ensival', 7, 0);
INSERT INTO `lokatie` VALUES(1951, 'thommen', '6.0669593000', '50.2209976000', '4791', 'Thommen', 7, 0);
INSERT INTO `lokatie` VALUES(1950, 'reuland', '6.1376625000', '50.1966077000', '4790', 'Reuland', 7, 0);
INSERT INTO `lokatie` VALUES(1949, 'burg-reuland', '6.1376625000', '50.1966077000', '4790', 'Burg-Reuland', 7, 0);
INSERT INTO `lokatie` VALUES(1948, 'crombach', '6.0551459000', '50.2836736000', '4784', 'Crombach', 7, 0);
INSERT INTO `lokatie` VALUES(1947, 'lommersweiler', '6.1762009000', '50.2566039000', '4783', 'Lommersweiler', 7, 0);
INSERT INTO `lokatie` VALUES(1946, 'schnbergschoenberg', '6.2509933000', '50.2784703000', '4782', 'Schönberg/Schoenberg', 7, 0);
INSERT INTO `lokatie` VALUES(1945, 'sankt-vithsaint-vith', '6.1304560000', '50.2797224000', '4780', 'Sankt Vith/Saint-Vith', 7, 0);
INSERT INTO `lokatie` VALUES(1944, 'recht', '6.0429532000', '50.3347591000', '4780', 'Recht', 7, 0);
INSERT INTO `lokatie` VALUES(1943, 'heppenbach', '6.2239870000', '50.3575950000', '4771', 'Heppenbach', 7, 0);
INSERT INTO `lokatie` VALUES(1942, 'meyerode', '6.1887164000', '50.3292364000', '4770', 'Meyerode', 7, 0);
INSERT INTO `lokatie` VALUES(1941, 'amelamblve', '6.1693660000', '50.3542207000', '4770', 'Amel/Amblève', 7, 0);
INSERT INTO `lokatie` VALUES(1940, 'rocherath', '6.3227426000', '50.4559831000', '4761', 'Rocherath', 7, 0);
INSERT INTO `lokatie` VALUES(1939, 'manderfeld', '6.3411021000', '50.3302460000', '4760', 'Manderfeld', 7, 0);
INSERT INTO `lokatie` VALUES(1938, 'bllingenbullange', '6.2576355000', '50.4074104000', '4760', 'Büllingen/Bullange', 7, 0);
INSERT INTO `lokatie` VALUES(1937, 'elsenborn', '6.2200289000', '50.4576120000', '4750', 'Elsenborn', 7, 0);
INSERT INTO `lokatie` VALUES(1936, 'btgenbachbutgenbach', '6.2054321000', '50.4272976000', '4750', 'Bütgenbach/Butgenbach', 7, 0);
INSERT INTO `lokatie` VALUES(1935, 'eynatten', '6.1011403000', '50.7018163000', '4731', 'Eynatten', 7, 0);
INSERT INTO `lokatie` VALUES(1934, 'raeren', '6.1111438000', '50.6757240000', '4730', 'Raeren', 7, 0);
INSERT INTO `lokatie` VALUES(1933, 'hauset', '6.0706532000', '50.7082800000', '4730', 'Hauset', 7, 0);
INSERT INTO `lokatie` VALUES(1932, 'hergenrath', '6.0285772000', '50.7081998000', '4728', 'Hergenrath', 7, 0);
INSERT INTO `lokatie` VALUES(1931, 'neu-moresnet', '6.0255506000', '50.7239872000', '4721', 'Neu-Moresnet', 7, 0);
INSERT INTO `lokatie` VALUES(1930, 'kelmisla-calamine', '6.0128347000', '50.7246443000', '4720', 'Kelmis/La Calamine', 7, 0);
INSERT INTO `lokatie` VALUES(1929, 'walhorn', '6.0458144000', '50.6838671000', '4711', 'Walhorn', 7, 0);
INSERT INTO `lokatie` VALUES(1928, 'lontzen', '5.9875637000', '50.6816693000', '4710', 'Lontzen', 7, 0);
INSERT INTO `lokatie` VALUES(1927, 'kettenis', '6.0518359000', '50.6523157000', '4701', 'Kettenis', 7, 0);
INSERT INTO `lokatie` VALUES(1926, 'eupen', '6.0319464000', '50.6305471000', '4700', 'Eupen', 7, 0);
INSERT INTO `lokatie` VALUES(1925, 'wonck', '5.6351156000', '50.7680390000', '4690', 'Wonck', 7, 0);
INSERT INTO `lokatie` VALUES(1924, 'roclenge-sur-geer', '5.5925221000', '50.7565948000', '4690', 'Roclenge-sur-Geer', 7, 0);
INSERT INTO `lokatie` VALUES(1923, 'glons', '5.5461329000', '50.7514668000', '4690', 'Glons', 7, 0);
INSERT INTO `lokatie` VALUES(1922, 'eben-emael', '5.6666255000', '50.7944909000', '4690', 'Eben-Emael', 7, 0);
INSERT INTO `lokatie` VALUES(1921, 'boirs', '5.5800620000', '50.7509166000', '4690', 'Boirs', 7, 0);
INSERT INTO `lokatie` VALUES(1920, 'bassenge', '5.6098258000', '50.7590787000', '4690', 'Bassenge', 7, 0);
INSERT INTO `lokatie` VALUES(1919, 'haccourt', '5.6566362000', '50.7372708000', '4684', 'Haccourt', 7, 0);
INSERT INTO `lokatie` VALUES(1918, 'vivegnis', '5.6546199000', '50.6957039000', '4683', 'Vivegnis', 7, 0);
INSERT INTO `lokatie` VALUES(1917, 'houtain-saint-simon', '5.6096096000', '50.7390940000', '4682', 'Houtain-Saint-Siméon', 7, 0);
INSERT INTO `lokatie` VALUES(1916, 'heure-le-romain', '5.6281959000', '50.7312354000', '4682', 'Heure-le-Romain', 7, 0);
INSERT INTO `lokatie` VALUES(1915, 'hermalle-sous-argenteau', '5.6798148000', '50.7108948000', '4681', 'Hermalle-sous-Argenteau', 7, 0);
INSERT INTO `lokatie` VALUES(1914, 'oupeye', '5.6449116000', '50.7102907000', '4680', 'Oupeye', 7, 0);
INSERT INTO `lokatie` VALUES(1913, 'herme', '5.6181651000', '50.7080484000', '4680', 'Hermée', 7, 0);
INSERT INTO `lokatie` VALUES(1912, 'saint-remy-liege', '5.7051723000', '50.6932395000', '4672', 'Saint-Remy, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1911, 'saive', '5.6818220000', '50.6528461000', '4671', 'Saive', 7, 0);
INSERT INTO `lokatie` VALUES(1910, 'housse', '5.6932581000', '50.6788979000', '4671', 'Housse', 7, 0);
INSERT INTO `lokatie` VALUES(1909, 'barchon', '5.6967601000', '50.6681296000', '4671', 'Barchon', 7, 0);
INSERT INTO `lokatie` VALUES(1908, 'trembleur', '5.7264807000', '50.6953792000', '4670', 'Trembleur', 7, 0);
INSERT INTO `lokatie` VALUES(1907, 'mortier', '5.7429216000', '50.6823447000', '4670', 'Mortier', 7, 0);
INSERT INTO `lokatie` VALUES(1906, 'blgny', '5.7249912000', '50.6723801000', '4670', 'Blégny', 7, 0);
INSERT INTO `lokatie` VALUES(1905, 'charneux', '5.8058064000', '50.6700471000', '4654', 'Charneux', 7, 0);
INSERT INTO `lokatie` VALUES(1904, 'bolland', '5.7557256000', '50.6595214000', '4653', 'Bolland', 7, 0);
INSERT INTO `lokatie` VALUES(1903, 'xhendelesse', '5.7830075000', '50.6061517000', '4652', 'Xhendelesse', 7, 0);
INSERT INTO `lokatie` VALUES(1902, 'battice', '5.8218942000', '50.6474960000', '4651', 'Battice', 7, 0);
INSERT INTO `lokatie` VALUES(1901, 'julmont', '5.7720628000', '50.6863440000', '4650', 'Julémont', 7, 0);
INSERT INTO `lokatie` VALUES(1900, 'herve', '5.7941455000', '50.6393775000', '4650', 'Herve', 7, 0);
INSERT INTO `lokatie` VALUES(1899, 'grand-rechain', '5.8115677000', '50.6078384000', '4650', 'Grand-Rechain', 7, 0);
INSERT INTO `lokatie` VALUES(1898, 'chaineux', '5.8340999000', '50.6318830000', '4650', 'Chaineux', 7, 0);
INSERT INTO `lokatie` VALUES(1897, 'melen', '5.7462340000', '50.6443802000', '4633', 'Melen', 7, 0);
INSERT INTO `lokatie` VALUES(1896, 'crexhe-heuseux', '5.7230825000', '50.6559263000', '4632', 'Cérexhe-Heuseux', 7, 0);
INSERT INTO `lokatie` VALUES(1895, 'evegne', '5.7073780000', '50.6419903000', '4631', 'Evegnée', 7, 0);
INSERT INTO `lokatie` VALUES(1894, 'tigne', '5.7048588000', '50.6496711000', '4630', 'Tignée', 7, 0);
INSERT INTO `lokatie` VALUES(1893, 'soumagne', '5.7476240000', '50.6119124000', '4630', 'Soumagne', 7, 0);
INSERT INTO `lokatie` VALUES(1892, 'micheroux', '5.7215821000', '50.6267037000', '4630', 'Micheroux', 7, 0);
INSERT INTO `lokatie` VALUES(1891, 'ayeneux', '5.7139990000', '50.6087239000', '4630', 'Ayeneux', 7, 0);
INSERT INTO `lokatie` VALUES(1890, 'romse', '5.6674115000', '50.6014376000', '4624', 'Romsée', 7, 0);
INSERT INTO `lokatie` VALUES(1889, 'magne', '5.6863110000', '50.6005161000', '4623', 'Magnée', 7, 0);
INSERT INTO `lokatie` VALUES(1888, 'retinne', '5.6988945000', '50.6311006000', '4621', 'Retinne', 7, 0);
INSERT INTO `lokatie` VALUES(1887, 'flron', '5.6831436000', '50.6162686000', '4620', 'Fléron', 7, 0);
INSERT INTO `lokatie` VALUES(1886, 'queue-du-bois', '5.6787283000', '50.6374128000', '4610', 'Queue-du-Bois', 7, 0);
INSERT INTO `lokatie` VALUES(1885, 'beyne-heusay', '5.6543417000', '50.6233009000', '4610', 'Beyne-Heusay', 7, 0);
INSERT INTO `lokatie` VALUES(1884, 'bellaire', '5.6659368000', '50.6449283000', '4610', 'Bellaire', 7, 0);
INSERT INTO `lokatie` VALUES(1883, 'warsage', '5.7690419000', '50.7350561000', '4608', 'Warsage', 7, 0);
INSERT INTO `lokatie` VALUES(1882, 'neufchteau-liege', '5.7764276000', '50.7200255000', '4608', 'Neufchâteau, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1881, 'mortroux', '5.7524996000', '50.7133163000', '4607', 'Mortroux', 7, 0);
INSERT INTO `lokatie` VALUES(1880, 'feneur', '5.7139672000', '50.7041182000', '4607', 'Feneur', 7, 0);
INSERT INTO `lokatie` VALUES(1879, 'dalhem', '5.7235489000', '50.7131351000', '4607', 'Dalhem', 7, 0);
INSERT INTO `lokatie` VALUES(1878, 'bombaye', '5.7434753000', '50.7302959000', '4607', 'Bombaye', 7, 0);
INSERT INTO `lokatie` VALUES(1877, 'berneau', '5.7306283000', '50.7427593000', '4607', 'Berneau', 7, 0);
INSERT INTO `lokatie` VALUES(1876, 'saint-andr', '5.7504936000', '50.6962180000', '4606', 'Saint-André', 7, 0);
INSERT INTO `lokatie` VALUES(1875, 'cheratte', '5.6778001000', '50.6841647000', '4602', 'Cheratte', 7, 0);
INSERT INTO `lokatie` VALUES(1874, 'argenteau', '5.6909430000', '50.7017455000', '4601', 'Argenteau', 7, 0);
INSERT INTO `lokatie` VALUES(1873, 'vis', '5.6964905000', '50.7331465000', '4600', 'Visé', 7, 0);
INSERT INTO `lokatie` VALUES(1872, 'richelle', '5.6923867000', '50.7163445000', '4600', 'Richelle', 7, 0);
INSERT INTO `lokatie` VALUES(1871, 'lixhe', '5.6798606000', '50.7548700000', '4600', 'Lixhe', 7, 0);
INSERT INTO `lokatie` VALUES(1870, 'lanaye', '5.6945709000', '50.7819877000', '4600', 'Lanaye', 7, 0);
INSERT INTO `lokatie` VALUES(1869, 'warze', '5.4282538000', '50.4492689000', '4590', 'Warzée', 7, 0);
INSERT INTO `lokatie` VALUES(1868, 'ouffet', '5.4665215000', '50.4373717000', '4590', 'Ouffet', 7, 0);
INSERT INTO `lokatie` VALUES(1867, 'ellemelle', '5.4444200000', '50.4675229000', '4590', 'Ellemelle', 7, 0);
INSERT INTO `lokatie` VALUES(1866, 'vierset-barse', '5.2983155000', '50.4826023000', '4577', 'Vierset-Barse', 7, 0);
INSERT INTO `lokatie` VALUES(1865, 'stre-lez-huy', '5.3243565000', '50.4887110000', '4577', 'Strée-lez-Huy', 7, 0);
INSERT INTO `lokatie` VALUES(1864, 'outrelouxhe', '5.3361749000', '50.5050249000', '4577', 'Outrelouxhe', 7, 0);
INSERT INTO `lokatie` VALUES(1863, 'modave', '5.3005599000', '50.4422937000', '4577', 'Modave', 7, 0);
INSERT INTO `lokatie` VALUES(1862, 'vyle-et-tharoul', '5.2613292000', '50.4445822000', '4570', 'Vyle-et-Tharoul', 7, 0);
INSERT INTO `lokatie` VALUES(1861, 'marchin', '5.2256726000', '50.4808956000', '4570', 'Marchin', 7, 0);
INSERT INTO `lokatie` VALUES(1860, 'terwagne', '5.3488500000', '50.4445428000', '4560', 'Terwagne', 7, 0);
INSERT INTO `lokatie` VALUES(1859, 'pailhe', '5.2586468000', '50.4231288000', '4560', 'Pailhe', 7, 0);
INSERT INTO `lokatie` VALUES(1858, 'ocquier', '5.3955412000', '50.3963094000', '4560', 'Ocquier', 7, 0);
INSERT INTO `lokatie` VALUES(1857, 'les-avins', '5.2985826000', '50.4153189000', '4560', 'Les Avins', 7, 0);
INSERT INTO `lokatie` VALUES(1856, 'clavier', '5.3579803000', '50.4112831000', '4560', 'Clavier', 7, 0);
INSERT INTO `lokatie` VALUES(1855, 'bois-et-borsu', '5.3375844000', '50.3973258000', '4560', 'Bois-et-Borsu', 7, 0);
INSERT INTO `lokatie` VALUES(1854, 'tinlot', '5.3874728000', '50.4823130000', '4557', 'Tinlot', 7, 0);
INSERT INTO `lokatie` VALUES(1853, 'soheit-tinlot', '5.3884832000', '50.4835206000', '4557', 'Soheit-Tinlot', 7, 0);
INSERT INTO `lokatie` VALUES(1852, 'seny', '5.4028119000', '50.4591809000', '4557', 'Seny', 7, 0);
INSERT INTO `lokatie` VALUES(1851, 'ramelot', '5.3289806000', '50.4648716000', '4557', 'Ramelot', 7, 0);
INSERT INTO `lokatie` VALUES(1850, 'fraiture', '5.4193470000', '50.4785078000', '4557', 'Fraiture', 7, 0);
INSERT INTO `lokatie` VALUES(1849, 'abe', '5.3563777000', '50.4732976000', '4557', 'Abée', 7, 0);
INSERT INTO `lokatie` VALUES(1848, 'yerne-fraineux', '5.3976438000', '50.5138891000', '4550', 'Yernée-Fraineux', 7, 0);
INSERT INTO `lokatie` VALUES(1847, 'villers-le-temple', '5.3708242000', '50.5083685000', '4550', 'Villers-le-Temple', 7, 0);
INSERT INTO `lokatie` VALUES(1846, 'saint-sverin', '5.4111118000', '50.5300264000', '4550', 'Saint-Séverin', 7, 0);
INSERT INTO `lokatie` VALUES(1845, 'nandrin', '5.4188581000', '50.5068158000', '4550', 'Nandrin', 7, 0);
INSERT INTO `lokatie` VALUES(1844, 'ombret', '5.3363024000', '50.5449464000', '4540', 'Ombret', 7, 0);
INSERT INTO `lokatie` VALUES(1843, 'jehay', '5.3127286000', '50.5730953000', '4540', 'Jehay', 7, 0);
INSERT INTO `lokatie` VALUES(1842, 'flne', '5.3326480000', '50.5589553000', '4540', 'Flône', 7, 0);
INSERT INTO `lokatie` VALUES(1841, 'ampsin', '5.2874711000', '50.5396334000', '4540', 'Ampsin', 7, 0);
INSERT INTO `lokatie` VALUES(1840, 'amay', '5.3175123000', '50.5485247000', '4540', 'Amay', 7, 0);
INSERT INTO `lokatie` VALUES(1839, 'verlaine', '5.3175709000', '50.6069818000', '4537', 'Verlaine', 7, 0);
INSERT INTO `lokatie` VALUES(1838, 'seraing-le-chteau', '5.2987004000', '50.6209183000', '4537', 'Seraing-le-Château', 7, 0);
INSERT INTO `lokatie` VALUES(1837, 'chapon-seraing', '5.2709656000', '50.6090953000', '4537', 'Chapon-Seraing', 7, 0);
INSERT INTO `lokatie` VALUES(1836, 'warnant-dreye', '5.2276287000', '50.5951652000', '4530', 'Warnant-Dreye', 7, 0);
INSERT INTO `lokatie` VALUES(1835, 'villers-le-bouillet', '5.2705525000', '50.5671805000', '4530', 'Villers-le-Bouillet', 7, 0);
INSERT INTO `lokatie` VALUES(1834, 'vieux-waleffe', '5.2048346000', '50.6167834000', '4530', 'Vieux-Waleffe', 7, 0);
INSERT INTO `lokatie` VALUES(1833, 'vaux-et-borset', '5.2318841000', '50.6136604000', '4530', 'Vaux-et-Borset', 7, 0);
INSERT INTO `lokatie` VALUES(1832, 'fize-fontaine', '5.2816455000', '50.5844190000', '4530', 'Fize-Fontaine', 7, 0);
INSERT INTO `lokatie` VALUES(1831, 'wanze', '5.2143035000', '50.5375522000', '4520', 'Wanze', 7, 0);
INSERT INTO `lokatie` VALUES(1830, 'vinalmont', '5.2298025000', '50.5662320000', '4520', 'Vinalmont', 7, 0);
INSERT INTO `lokatie` VALUES(1829, 'moha', '5.1861968000', '50.5477592000', '4520', 'Moha', 7, 0);
INSERT INTO `lokatie` VALUES(1828, 'huccorgne', '5.1643287000', '50.5673311000', '4520', 'Huccorgne', 7, 0);
INSERT INTO `lokatie` VALUES(1827, 'bas-oha', '5.1870709000', '50.5228262000', '4520', 'Bas-Oha', 7, 0);
INSERT INTO `lokatie` VALUES(1826, 'antheit', '5.2438690000', '50.5556890000', '4520', 'Antheit', 7, 0);
INSERT INTO `lokatie` VALUES(1825, 'tihange', '5.2564876000', '50.5266445000', '4500', 'Tihange', 7, 0);
INSERT INTO `lokatie` VALUES(1824, 'huy', '5.2394592000', '50.5187159000', '4500', 'Huy', 7, 0);
INSERT INTO `lokatie` VALUES(1823, 'ben-ahin', '5.1840788000', '50.5009879000', '4500', 'Ben-Ahin', 7, 0);
INSERT INTO `lokatie` VALUES(1822, 'hermalle-sous-huy', '5.3623727000', '50.5576434000', '4480', 'Hermalle-sous-Huy', 7, 0);
INSERT INTO `lokatie` VALUES(1821, 'engis', '5.4046914000', '50.5824517000', '4480', 'Engis', 7, 0);
INSERT INTO `lokatie` VALUES(1820, 'clermont-sous-huy', '5.3923765000', '50.5677172000', '4480', 'Clermont-sous-Huy', 7, 0);
INSERT INTO `lokatie` VALUES(1819, 'saint-georges-sur-meuse', '5.3643957000', '50.5924022000', '4470', 'Saint-Georges-sur-Meuse', 7, 0);
INSERT INTO `lokatie` VALUES(1818, 'velroux', '5.4253960000', '50.6437427000', '4460', 'Velroux', 7, 0);
INSERT INTO `lokatie` VALUES(1817, 'horion-hozmont', '5.3794883000', '50.6283435000', '4460', 'Horion-Hozémont', 7, 0);
INSERT INTO `lokatie` VALUES(1816, 'hollogne-aux-pierres', '5.4742006000', '50.6386614000', '4460', 'Hollogne-aux-Pierres', 7, 0);
INSERT INTO `lokatie` VALUES(1815, 'grce-hollogne', '5.4695226000', '50.6446979000', '4460', 'Grâce-Hollogne', 7, 0);
INSERT INTO `lokatie` VALUES(1814, 'grce-berleur', '5.4999594000', '50.6380640000', '4460', 'Grâce-Berleur', 7, 0);
INSERT INTO `lokatie` VALUES(1813, 'bierset', '5.4513067000', '50.6551330000', '4460', 'Bierset', 7, 0);
INSERT INTO `lokatie` VALUES(1812, 'fexhe-slins', '5.5792996000', '50.7175592000', '4458', 'Fexhe-Slins', 7, 0);
INSERT INTO `lokatie` VALUES(1811, 'villers-saint-simon', '5.5414646000', '50.7091650000', '4453', 'Villers-Saint-Siméon', 7, 0);
INSERT INTO `lokatie` VALUES(1810, 'wihogne', '5.5078719000', '50.7266603000', '4452', 'Wihogne', 7, 0);
INSERT INTO `lokatie` VALUES(1809, 'paifve', '5.5249093000', '50.7287419000', '4452', 'Paifve', 7, 0);
INSERT INTO `lokatie` VALUES(1808, 'voroux-lez-liers', '5.5452704000', '50.6905476000', '4451', 'Voroux-lez-Liers', 7, 0);
INSERT INTO `lokatie` VALUES(1807, 'slins', '5.5633189000', '50.7278965000', '4450', 'Slins', 7, 0);
INSERT INTO `lokatie` VALUES(1806, 'lantin', '5.5239522000', '50.6879991000', '4450', 'Lantin', 7, 0);
INSERT INTO `lokatie` VALUES(1805, 'juprelle', '5.5276177000', '50.7115129000', '4450', 'Juprelle', 7, 0);
INSERT INTO `lokatie` VALUES(1804, 'xhendremael', '5.4803345000', '50.7043744000', '4432', 'Xhendremael', 7, 0);
INSERT INTO `lokatie` VALUES(1803, 'alleur', '5.5132386000', '50.6742929000', '4432', 'Alleur', 7, 0);
INSERT INTO `lokatie` VALUES(1802, 'loncin', '5.4960854000', '50.6668571000', '4431', 'Loncin', 7, 0);
INSERT INTO `lokatie` VALUES(1801, 'ans', '5.5265524000', '50.6602130000', '4430', 'Ans', 7, 0);
INSERT INTO `lokatie` VALUES(1800, 'tilleur', '5.5259753000', '50.6195790000', '4420', 'Tilleur', 7, 0);
INSERT INTO `lokatie` VALUES(1799, 'saint-nicolas-liege', '5.5380624000', '50.6304954000', '4420', 'Saint-Nicolas, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1798, 'montegne', '5.5150148000', '50.6404414000', '4420', 'Montegnée', 7, 0);
INSERT INTO `lokatie` VALUES(1797, 'mons-lez-lige', '5.4600283000', '50.6268192000', '4400', 'Mons-lez-Liège', 7, 0);
INSERT INTO `lokatie` VALUES(1796, 'ivoz-ramet', '5.4439698000', '50.5836795000', '4400', 'Ivoz-Ramet', 7, 0);
INSERT INTO `lokatie` VALUES(1795, 'gleixhe', '5.3969187000', '50.6091734000', '4400', 'Gleixhe', 7, 0);
INSERT INTO `lokatie` VALUES(1794, 'flmalle-haute', '5.4482080000', '50.6000820000', '4400', 'Flémalle-Haute', 7, 0);
INSERT INTO `lokatie` VALUES(1793, 'flmalle-grande', '5.4747135000', '50.6140046000', '4400', 'Flémalle-Grande', 7, 0);
INSERT INTO `lokatie` VALUES(1792, 'flmalle', '5.4363682000', '50.6046555000', '4400', 'Flémalle', 7, 0);
INSERT INTO `lokatie` VALUES(1791, 'chokier', '5.4421319000', '50.5902126000', '4400', 'Chokier', 7, 0);
INSERT INTO `lokatie` VALUES(1790, 'awirs', '5.4076826000', '50.5993357000', '4400', 'Awirs', 7, 0);
INSERT INTO `lokatie` VALUES(1789, 'thys', '5.3899955000', '50.7227362000', '4367', 'Thys', 7, 0);
INSERT INTO `lokatie` VALUES(1788, 'odeur', '5.4162974000', '50.7065185000', '4367', 'Odeur', 7, 0);
INSERT INTO `lokatie` VALUES(1787, 'kemexhe', '5.4063755000', '50.6972547000', '4367', 'Kemexhe', 7, 0);
INSERT INTO `lokatie` VALUES(1786, 'fize-le-marsal', '5.3855360000', '50.7023753000', '4367', 'Fize-le-Marsal', 7, 0);
INSERT INTO `lokatie` VALUES(1785, 'crisne', '5.3975976000', '50.7175200000', '4367', 'Crisnée', 7, 0);
INSERT INTO `lokatie` VALUES(1784, 'otrange', '5.3842933000', '50.7368488000', '4360', 'Otrange', 7, 0);
INSERT INTO `lokatie` VALUES(1783, 'oreye', '5.3536941000', '50.7286779000', '4360', 'Oreye', 7, 0);
INSERT INTO `lokatie` VALUES(1782, 'lens-sur-geer', '5.3534526000', '50.7216887000', '4360', 'Lens-sur-Geer', 7, 0);
INSERT INTO `lokatie` VALUES(1781, 'grandville', '5.3384189000', '50.7218452000', '4360', 'Grandville', 7, 0);
INSERT INTO `lokatie` VALUES(1780, 'bergilers', '5.3284662000', '50.7161171000', '4360', 'Bergilers', 7, 0);
INSERT INTO `lokatie` VALUES(1779, 'limont', '5.3113701000', '50.6607258000', '4357', 'Limont', 7, 0);
INSERT INTO `lokatie` VALUES(1778, 'jeneffe-liege', '5.3561696000', '50.6528472000', '4357', 'Jeneffe, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1777, 'haneffe', '5.3199545000', '50.6384817000', '4357', 'Haneffe', 7, 0);
INSERT INTO `lokatie` VALUES(1776, 'donceel', '5.3200286000', '50.6484374000', '4357', 'Donceel', 7, 0);
INSERT INTO `lokatie` VALUES(1775, 'hodeige', '5.3490953000', '50.6945122000', '4351', 'Hodeige', 7, 0);
INSERT INTO `lokatie` VALUES(1774, 'remicourt', '5.3283568000', '50.6795837000', '4350', 'Remicourt', 7, 0);
INSERT INTO `lokatie` VALUES(1773, 'pousset', '5.3041069000', '50.6947740000', '4350', 'Pousset', 7, 0);
INSERT INTO `lokatie` VALUES(1772, 'momalle', '5.3730767000', '50.6850335000', '4350', 'Momalle', 7, 0);
INSERT INTO `lokatie` VALUES(1771, 'lamine', '5.3353064000', '50.6889449000', '4350', 'Lamine', 7, 0);
INSERT INTO `lokatie` VALUES(1770, 'voroux-goreux', '5.4288993000', '50.6544638000', '4347', 'Voroux-Goreux', 7, 0);
INSERT INTO `lokatie` VALUES(1769, 'roloux', '5.3960453000', '50.6494816000', '4347', 'Roloux', 7, 0);
INSERT INTO `lokatie` VALUES(1768, 'noville-liege', '5.3822475000', '50.6600114000', '4347', 'Noville, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1767, 'freloux', '5.4065636000', '50.6806353000', '4347', 'Freloux', 7, 0);
INSERT INTO `lokatie` VALUES(1766, 'fexhe-le-haut-clocher', '5.3994832000', '50.6653416000', '4347', 'Fexhe-le-Haut-Clocher', 7, 0);
INSERT INTO `lokatie` VALUES(1765, 'hognoul', '5.4613389000', '50.6841019000', '4342', 'Hognoul', 7, 0);
INSERT INTO `lokatie` VALUES(1764, 'villers-l039evque', '5.4399729000', '50.7044254000', '4340', 'Villers-l&#039;Evêque', 7, 0);
INSERT INTO `lokatie` VALUES(1763, 'othe', '5.4686253000', '50.7150407000', '4340', 'Othée', 7, 0);
INSERT INTO `lokatie` VALUES(1762, 'fooz', '5.4368928000', '50.6806255000', '4340', 'Fooz', 7, 0);
INSERT INTO `lokatie` VALUES(1761, 'awans', '5.4609702000', '50.6644335000', '4340', 'Awans', 7, 0);
INSERT INTO `lokatie` VALUES(1760, 'viemme', '5.2700404000', '50.6491359000', '4317', 'Viemme', 7, 0);
INSERT INTO `lokatie` VALUES(1759, 'les-waleffes', '5.2173945000', '50.6404014000', '4317', 'Les Waleffes', 7, 0);
INSERT INTO `lokatie` VALUES(1758, 'faimes', '5.2595073000', '50.6620875000', '4317', 'Faimes', 7, 0);
INSERT INTO `lokatie` VALUES(1757, 'celles-liege', '5.2447215000', '50.6539471000', '4317', 'Celles, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1756, 'borlez', '5.2456576000', '50.6332987000', '4317', 'Borlez', 7, 0);
INSERT INTO `lokatie` VALUES(1755, 'aineffe', '5.2568775000', '50.6222278000', '4317', 'Aineffe', 7, 0);
INSERT INTO `lokatie` VALUES(1754, 'waremme', '5.2551295000', '50.6977483000', '4300', 'Waremme', 7, 0);
INSERT INTO `lokatie` VALUES(1753, 'oleye', '5.2814488000', '50.7124757000', '4300', 'Oleye', 7, 0);
INSERT INTO `lokatie` VALUES(1752, 'lantremange', '5.2955926000', '50.7116722000', '4300', 'Lantremange', 7, 0);
INSERT INTO `lokatie` VALUES(1751, 'grand-axhe', '5.2243578000', '50.6790274000', '4300', 'Grand-Axhe', 7, 0);
INSERT INTO `lokatie` VALUES(1750, 'bovenistier', '5.2857840000', '50.6675994000', '4300', 'Bovenistier', 7, 0);
INSERT INTO `lokatie` VALUES(1749, 'bleret', '5.2859129000', '50.6887850000', '4300', 'Bleret', 7, 0);
INSERT INTO `lokatie` VALUES(1748, 'bettincourt', '5.2354095000', '50.7093021000', '4300', 'Bettincourt', 7, 0);
INSERT INTO `lokatie` VALUES(1747, 'racour', '5.0306090000', '50.7404537000', '4287', 'Racour', 7, 0);
INSERT INTO `lokatie` VALUES(1746, 'pellaines', '5.0071654000', '50.7259888000', '4287', 'Pellaines', 7, 0);
INSERT INTO `lokatie` VALUES(1745, 'lincent', '5.0306348000', '50.7129292000', '4287', 'Lincent', 7, 0);
INSERT INTO `lokatie` VALUES(1744, 'wansin', '5.0190942000', '50.6790170000', '4280', 'Wansin', 7, 0);
INSERT INTO `lokatie` VALUES(1743, 'villers-le-peuplier', '5.0952855000', '50.6564834000', '4280', 'Villers-le-Peuplier', 7, 0);
INSERT INTO `lokatie` VALUES(1742, 'trogne', '5.1246486000', '50.6869293000', '4280', 'Trognée', 7, 0);
INSERT INTO `lokatie` VALUES(1741, 'thisnes', '5.0467761000', '50.6658977000', '4280', 'Thisnes', 7, 0);
INSERT INTO `lokatie` VALUES(1740, 'poucet', '5.1123769000', '50.6779282000', '4280', 'Poucet', 7, 0);
INSERT INTO `lokatie` VALUES(1739, 'petit-hallet', '5.0179366000', '50.6877274000', '4280', 'Petit-Hallet', 7, 0);
INSERT INTO `lokatie` VALUES(1738, 'moxhe', '5.0837187000', '50.6299039000', '4280', 'Moxhe', 7, 0);
INSERT INTO `lokatie` VALUES(1737, 'merdorp', '4.9982853000', '50.6495115000', '4280', 'Merdorp', 7, 0);
INSERT INTO `lokatie` VALUES(1736, 'lens-saint-remy', '5.1331569000', '50.6543228000', '4280', 'Lens-Saint-Remy', 7, 0);
INSERT INTO `lokatie` VALUES(1735, 'hannut', '5.0776270000', '50.6710668000', '4280', 'Hannut', 7, 0);
INSERT INTO `lokatie` VALUES(1734, 'grand-hallet', '5.0334199000', '50.6934842000', '4280', 'Grand-Hallet', 7, 0);
INSERT INTO `lokatie` VALUES(1733, 'crehen', '5.0636892000', '50.6600826000', '4280', 'Crehen', 7, 0);
INSERT INTO `lokatie` VALUES(1732, 'cras-avernas', '5.1238502000', '50.6973180000', '4280', 'Cras-Avernas', 7, 0);
INSERT INTO `lokatie` VALUES(1731, 'blehen', '5.1206261000', '50.6615562000', '4280', 'Blehen', 7, 0);
INSERT INTO `lokatie` VALUES(1730, 'bertre', '5.0891413000', '50.6946215000', '4280', 'Bertrée', 7, 0);
INSERT INTO `lokatie` VALUES(1729, 'avin', '5.0723923000', '50.6200807000', '4280', 'Avin', 7, 0);
INSERT INTO `lokatie` VALUES(1728, 'avernas-le-bauduin', '5.0783283000', '50.6947221000', '4280', 'Avernas-le-Bauduin', 7, 0);
INSERT INTO `lokatie` VALUES(1727, 'abolens', '5.1497764000', '50.6721160000', '4280', 'Abolens', 7, 0);
INSERT INTO `lokatie` VALUES(1726, 'tourinne-liege', '5.1806443000', '50.6397004000', '4263', 'Tourinne, Liege', 7, 0);
INSERT INTO `lokatie` VALUES(1725, 'latinne', '5.1679273000', '50.6220710000', '4261', 'Latinne', 7, 0);
INSERT INTO `lokatie` VALUES(1724, 'ville-en-hesbaye', '5.1162099000', '50.6168499000', '4260', 'Ville-en-Hesbaye', 7, 0);
INSERT INTO `lokatie` VALUES(1723, 'fumal', '5.1831158000', '50.5864790000', '4260', 'Fumal', 7, 0);
INSERT INTO `lokatie` VALUES(1722, 'fallais', '5.1708933000', '50.6108784000', '4260', 'Fallais', 7, 0);
INSERT INTO `lokatie` VALUES(1721, 'ciplet', '5.0957952000', '50.6169788000', '4260', 'Ciplet', 7, 0);
INSERT INTO `lokatie` VALUES(1720, 'braives', '5.1455129000', '50.6296114000', '4260', 'Braives', 7, 0);
INSERT INTO `lokatie` VALUES(1719, 'avennes', '5.1147799000', '50.6292846000', '4260', 'Avennes', 7, 0);
INSERT INTO `lokatie` VALUES(1718, 'rosoux-crenwick', '5.1896088000', '50.7074763000', '4257', 'Rosoux-Crenwick', 7, 0);
INSERT INTO `lokatie` VALUES(1717, 'corswarem', '5.2130050000', '50.7098583000', '4257', 'Corswarem', 7, 0);
INSERT INTO `lokatie` VALUES(1716, 'berloz', '5.2134189000', '50.6981964000', '4257', 'Berloz', 7, 0);
INSERT INTO `lokatie` VALUES(1715, 'ligney', '5.1709829000', '50.6557286000', '4254', 'Ligney', 7, 0);
INSERT INTO `lokatie` VALUES(1714, 'darion', '5.1916801000', '50.6652101000', '4253', 'Darion', 7, 0);
INSERT INTO `lokatie` VALUES(1713, 'omal', '5.1960316000', '50.6546145000', '4252', 'Omal', 7, 0);
INSERT INTO `lokatie` VALUES(1712, 'lens-saint-servais', '5.1557262000', '50.6636039000', '4250', 'Lens-Saint-Servais', 7, 0);
INSERT INTO `lokatie` VALUES(1711, 'hollogne-sur-geer', '5.2049735000', '50.6769220000', '4250', 'Hollogne-sur-Geer', 7, 0);
INSERT INTO `lokatie` VALUES(1710, 'geer', '5.1709647000', '50.6685072000', '4250', 'Geer', 7, 0);
INSERT INTO `lokatie` VALUES(1709, 'bolhe', '5.1665335000', '50.6822338000', '4250', 'Boëlhe', 7, 0);
INSERT INTO `lokatie` VALUES(1708, 'wasseiges', '5.0054358000', '50.6227345000', '4219', 'Wasseiges', 7, 0);
INSERT INTO `lokatie` VALUES(1707, 'meeffe', '5.0177823000', '50.6079501000', '4219', 'Meeffe', 7, 0);
INSERT INTO `lokatie` VALUES(1706, 'ambresin', '5.0303884000', '50.6271009000', '4219', 'Ambresin', 7, 0);
INSERT INTO `lokatie` VALUES(1705, 'acosse', '5.0485283000', '50.5953586000', '4219', 'Acosse', 7, 0);
INSERT INTO `lokatie` VALUES(1704, 'couthuin', '5.1259301000', '50.5304417000', '4218', 'Couthuin', 7, 0);
INSERT INTO `lokatie` VALUES(1703, 'waret-l039evque', '5.0677728000', '50.5561140000', '4217', 'Waret-l&#039;Evêque', 7, 0);
INSERT INTO `lokatie` VALUES(1702, 'lavoir', '5.1205511000', '50.5489088000', '4217', 'Lavoir', 7, 0);
INSERT INTO `lokatie` VALUES(1701, 'hron', '5.0977729000', '50.5506309000', '4217', 'Héron', 7, 0);
INSERT INTO `lokatie` VALUES(1700, 'oteppe', '5.1263214000', '50.5821535000', '4210', 'Oteppe', 7, 0);
INSERT INTO `lokatie` VALUES(1699, 'marneffe', '5.1432349000', '50.5793359000', '4210', 'Marneffe', 7, 0);
INSERT INTO `lokatie` VALUES(1698, 'lamontze', '5.0903253000', '50.5838176000', '4210', 'Lamontzée', 7, 0);
INSERT INTO `lokatie` VALUES(1697, 'hannche', '5.0488361000', '50.5804359000', '4210', 'Hannêche', 7, 0);
INSERT INTO `lokatie` VALUES(1696, 'burdinne', '5.0723075000', '50.5834167000', '4210', 'Burdinne', 7, 0);
INSERT INTO `lokatie` VALUES(1695, 'xhoris', '5.6013951000', '50.4438009000', '4190', 'Xhoris', 7, 0);
INSERT INTO `lokatie` VALUES(1694, 'werbomont', '5.6859205000', '50.3798934000', '4190', 'Werbomont', 7, 0);
INSERT INTO `lokatie` VALUES(1693, 'vieuxville', '5.5521324000', '50.3963549000', '4190', 'Vieuxville', 7, 0);
INSERT INTO `lokatie` VALUES(1692, 'my', '5.5734416000', '50.4055029000', '4190', 'My', 7, 0);
INSERT INTO `lokatie` VALUES(1691, 'ferrires', '5.6061971000', '50.4003533000', '4190', 'Ferrières', 7, 0);
INSERT INTO `lokatie` VALUES(1690, 'filot', '5.5722192000', '50.4269441000', '4181', 'Filot', 7, 0);
INSERT INTO `lokatie` VALUES(1689, 'hamoir', '5.5322759000', '50.4268234000', '4180', 'Hamoir', 7, 0);
INSERT INTO `lokatie` VALUES(1688, 'comblain-la-tour', '5.5716035000', '50.4542906000', '4180', 'Comblain-la-Tour', 7, 0);
INSERT INTO `lokatie` VALUES(1687, 'comblain-fairon', '5.5427715000', '50.4450738000', '4180', 'Comblain-Fairon', 7, 0);
INSERT INTO `lokatie` VALUES(1686, 'poulseur', '5.5713674000', '50.5021907000', '4171', 'Poulseur', 7, 0);
INSERT INTO `lokatie` VALUES(1685, 'comblain-au-pont', '5.5626210000', '50.4740721000', '4170', 'Comblain-au-Pont', 7, 0);
INSERT INTO `lokatie` VALUES(1684, 'tavier', '5.4717462000', '50.4939446000', '4163', 'Tavier', 7, 0);
INSERT INTO `lokatie` VALUES(1683, 'hody', '5.4984011000', '50.4849059000', '4162', 'Hody', 7, 0);
INSERT INTO `lokatie` VALUES(1682, 'villers-aux-tours', '5.5113260000', '50.5024548000', '4161', 'Villers-aux-Tours', 7, 0);
INSERT INTO `lokatie` VALUES(1681, 'anthisnes', '5.5198048000', '50.4812987000', '4160', 'Anthisnes', 7, 0);
INSERT INTO `lokatie` VALUES(1680, 'louveign', '5.7183375000', '50.5236123000', '4141', 'Louveigné', 7, 0);
INSERT INTO `lokatie` VALUES(1679, 'sprimont', '5.6637084000', '50.5025407000', '4140', 'Sprimont', 7, 0);
INSERT INTO `lokatie` VALUES(1678, 'rouvreux', '5.6502021000', '50.4896744000', '4140', 'Rouvreux', 7, 0);
INSERT INTO `lokatie` VALUES(1677, 'gomz-andoumont', '5.6746767000', '50.5409863000', '4140', 'Gomzé-Andoumont', 7, 0);
INSERT INTO `lokatie` VALUES(1676, 'dolembreux', '5.6247413000', '50.5370102000', '4140', 'Dolembreux', 7, 0);
INSERT INTO `lokatie` VALUES(1675, 'tilff', '5.5844061000', '50.5695196000', '4130', 'Tilff', 7, 0);
INSERT INTO `lokatie` VALUES(1674, 'esneux', '5.5687215000', '50.5337444000', '4130', 'Esneux', 7, 0);
INSERT INTO `lokatie` VALUES(1673, 'plainevaux', '5.5319689000', '50.5430051000', '4122', 'Plainevaux', 7, 0);
INSERT INTO `lokatie` VALUES(1672, 'neuville-en-condroz', '5.4512211000', '50.5528039000', '4121', 'Neuville-en-Condroz', 7, 0);
INSERT INTO `lokatie` VALUES(1671, 'rotheux-rimire', '5.4814832000', '50.5344031000', '4120', 'Rotheux-Rimière', 7, 0);
INSERT INTO `lokatie` VALUES(1670, 'neupr', '5.4761468000', '50.5326636000', '4120', 'Neupré', 7, 0);
INSERT INTO `lokatie` VALUES(1669, 'ehein', '5.4444826000', '50.5452295000', '4120', 'Ehein', 7, 0);
INSERT INTO `lokatie` VALUES(1668, 'ougre', '5.5421391000', '50.5944726000', '4102', 'Ougrée', 7, 0);
INSERT INTO `lokatie` VALUES(1667, 'jemeppe-sur-meuse', '5.4985516000', '50.6147317000', '4101', 'Jemeppe-sur-Meuse', 7, 0);
INSERT INTO `lokatie` VALUES(1666, 'seraing', '5.5121344000', '50.5988987000', '4100', 'Seraing', 7, 0);
INSERT INTO `lokatie` VALUES(1665, 'boncelles', '5.5359176000', '50.5748650000', '4100', 'Boncelles', 7, 0);
INSERT INTO `lokatie` VALUES(1664, 'embourg', '5.6050202000', '50.5914627000', '4053', 'Embourg', 7, 0);
INSERT INTO `lokatie` VALUES(1663, 'beaufays', '5.6365602000', '50.5587632000', '4052', 'Beaufays', 7, 0);
INSERT INTO `lokatie` VALUES(1662, 'vaux-sous-chvremont', '5.6342322000', '50.6028592000', '4051', 'Vaux-sous-Chèvremont', 7, 0);
INSERT INTO `lokatie` VALUES(1661, 'chaudfontaine', '5.6427754000', '50.5896391000', '4050', 'Chaudfontaine', 7, 0);
INSERT INTO `lokatie` VALUES(1660, 'liers', '5.5715214000', '50.6945009000', '4042', 'Liers', 7, 0);
INSERT INTO `lokatie` VALUES(1659, 'vottem', '5.5864433000', '50.6766186000', '4041', 'Vottem', 7, 0);
INSERT INTO `lokatie` VALUES(1658, 'milmort', '5.5929367000', '50.6902094000', '4041', 'Milmort', 7, 0);
INSERT INTO `lokatie` VALUES(1657, 'herstal', '5.6308779000', '50.6655868000', '4040', 'Herstal', 7, 0);
INSERT INTO `lokatie` VALUES(1656, 'chne', '5.6253999000', '50.6138727000', '4032', 'Chênée', 7, 0);
INSERT INTO `lokatie` VALUES(1655, 'angleur', '5.5798611000', '50.5926711000', '4031', 'Angleur', 7, 0);
INSERT INTO `lokatie` VALUES(1654, 'grivegne', '5.6085724000', '50.6250840000', '4030', 'Grivegnée', 7, 0);
INSERT INTO `lokatie` VALUES(1653, 'wandre', '5.6606439000', '50.6694370000', '4020', 'Wandre', 7, 0);
INSERT INTO `lokatie` VALUES(1652, 'lige', '5.6279411000', '50.6423532000', '4020', 'Liège', 7, 0);
INSERT INTO `lokatie` VALUES(1651, 'jupille-sur-meuse', '5.6326457000', '50.6469854000', '4020', 'Jupille-sur-Meuse', 7, 0);
INSERT INTO `lokatie` VALUES(1650, 'bressoux', '5.6095803000', '50.6425369000', '4020', 'Bressoux', 7, 0);
INSERT INTO `lokatie` VALUES(1649, 'rocourt', '5.5462216000', '50.6753765000', '4000', 'Rocourt', 7, 0);
INSERT INTO `lokatie` VALUES(1648, 'lige', '5.5720466000', '50.6406495000', '4000', 'Liège', 7, 0);
INSERT INTO `lokatie` VALUES(1647, 'glain', '5.5436634000', '50.6479042000', '4000', 'Glain', 7, 0);
INSERT INTO `lokatie` VALUES(1646, 'stambruges', '3.7167452000', '50.5084227000', '7973', 'Stambruges', 6, 0);
INSERT INTO `lokatie` VALUES(1645, 'grandglise', '3.6964704000', '50.5043610000', '7973', 'Grandglise', 6, 0);
INSERT INTO `lokatie` VALUES(1644, 'quevaucamps', '3.6793519000', '50.5185563000', '7972', 'Quevaucamps', 6, 0);
INSERT INTO `lokatie` VALUES(1643, 'ellignies-sainte-anne', '3.6738618000', '50.5620822000', '7972', 'Ellignies-Sainte-Anne', 6, 0);
INSERT INTO `lokatie` VALUES(1642, 'aubechies', '3.6765843000', '50.5742974000', '7972', 'Aubechies', 6, 0);
INSERT INTO `lokatie` VALUES(1641, 'wadelincourt', '3.6473774000', '50.5374881000', '7971', 'Wadelincourt', 6, 0);
INSERT INTO `lokatie` VALUES(1640, 'thumaide', '3.6285127000', '50.5425966000', '7971', 'Thumaide', 6, 0);
INSERT INTO `lokatie` VALUES(1639, 'ramegnies', '3.6347215000', '50.5439835000', '7971', 'Ramegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1638, 'bascles', '3.6477728000', '50.5260518000', '7971', 'Basècles', 6, 0);
INSERT INTO `lokatie` VALUES(1637, 'beloeil', '3.7323646000', '50.5494814000', '7970', 'Beloeil', 6, 0);
INSERT INTO `lokatie` VALUES(1636, 'tongre-notre-dame', '3.7663933000', '50.5849033000', '7951', 'Tongre-Notre-Dame', 6, 0);
INSERT INTO `lokatie` VALUES(1635, 'tongre-saint-martin', '3.7913110000', '50.5864039000', '7950', 'Tongre-Saint-Martin', 6, 0);
INSERT INTO `lokatie` VALUES(1634, 'ladeuze', '3.7718817000', '50.5681664000', '7950', 'Ladeuze', 6, 0);
INSERT INTO `lokatie` VALUES(1633, 'huissignies', '3.7540580000', '50.5648264000', '7950', 'Huissignies', 6, 0);
INSERT INTO `lokatie` VALUES(1632, 'grosage', '3.7565612000', '50.5445997000', '7950', 'Grosage', 6, 0);
INSERT INTO `lokatie` VALUES(1631, 'chivres', '3.8065410000', '50.5880062000', '7950', 'Chièvres', 6, 0);
INSERT INTO `lokatie` VALUES(1630, 'gages', '3.8955629000', '50.6092020000', '7943', 'Gages', 6, 0);
INSERT INTO `lokatie` VALUES(1629, 'mvergnies-lez-lens', '3.8507361000', '50.6184767000', '7942', 'Mévergnies-lez-Lens', 6, 0);
INSERT INTO `lokatie` VALUES(1628, 'attre', '3.8309729000', '50.6087460000', '7941', 'Attre', 6, 0);
INSERT INTO `lokatie` VALUES(1627, 'cambron-casteau', '3.8786529000', '50.5893781000', '7940', 'Cambron-Casteau', 6, 0);
INSERT INTO `lokatie` VALUES(1626, 'brugelette', '3.8524578000', '50.5959506000', '7940', 'Brugelette', 6, 0);
INSERT INTO `lokatie` VALUES(1625, 'saint-sauveur', '3.5975753000', '50.7060552000', '7912', 'Saint-Sauveur', 6, 0);
INSERT INTO `lokatie` VALUES(1624, 'dergneau', '3.5781807000', '50.7144440000', '7912', 'Dergneau', 6, 0);
INSERT INTO `lokatie` VALUES(1623, 'oeudeghien', '3.7122843000', '50.6775136000', '7911', 'Oeudeghien', 6, 0);
INSERT INTO `lokatie` VALUES(1622, 'moustier-ht', '3.6197647000', '50.6552799000', '7911', 'Moustier (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1621, 'montroeul-au-bois', '3.5707953000', '50.6433270000', '7911', 'Montroeul-au-Bois', 6, 0);
INSERT INTO `lokatie` VALUES(1620, 'herquegies', '3.5780399000', '50.6347262000', '7911', 'Herquegies', 6, 0);
INSERT INTO `lokatie` VALUES(1619, 'hacquegnies', '3.5936426000', '50.6512991000', '7911', 'Hacquegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1618, 'frasnes-lez-buissenal', '3.6219435000', '50.6677103000', '7911', 'Frasnes-lez-Buissenal', 6, 0);
INSERT INTO `lokatie` VALUES(1617, 'buissenal', '3.6558282000', '50.6639776000', '7911', 'Buissenal', 6, 0);
INSERT INTO `lokatie` VALUES(1616, 'wattripont', '3.5482182000', '50.7283489000', '7910', 'Wattripont', 6, 0);
INSERT INTO `lokatie` VALUES(1615, 'frasnes-lez-anvaing', '3.5330692000', '50.6986439000', '7910', 'Frasnes-lez-Anvaing', 6, 0);
INSERT INTO `lokatie` VALUES(1614, 'forest-ht', '3.5366086000', '50.6733279000', '7910', 'Forest (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1613, 'ellignies-lez-frasnes', '3.5907122000', '50.6747367000', '7910', 'Ellignies-lez-Frasnes', 6, 0);
INSERT INTO `lokatie` VALUES(1612, 'cordes', '3.5328842000', '50.6885479000', '7910', 'Cordes', 6, 0);
INSERT INTO `lokatie` VALUES(1611, 'arc-wattripont', '3.5343454000', '50.6997622000', '7910', 'Arc-Wattripont', 6, 0);
INSERT INTO `lokatie` VALUES(1610, 'arc-ainires', '3.5535745000', '50.7008401000', '7910', 'Arc-Ainières', 6, 0);
INSERT INTO `lokatie` VALUES(1609, 'anvaing', '3.5330692000', '50.6986439000', '7910', 'Anvaing', 6, 0);
INSERT INTO `lokatie` VALUES(1608, 'gallaix', '3.5727411000', '50.6013719000', '7906', 'Gallaix', 6, 0);
INSERT INTO `lokatie` VALUES(1607, 'willaupuis', '3.6033150000', '50.5666647000', '7904', 'Willaupuis', 6, 0);
INSERT INTO `lokatie` VALUES(1606, 'tourpes', '3.6521348000', '50.5734083000', '7904', 'Tourpes', 6, 0);
INSERT INTO `lokatie` VALUES(1605, 'pipaix', '3.5748999000', '50.5829466000', '7904', 'Pipaix', 6, 0);
INSERT INTO `lokatie` VALUES(1604, 'chapelle--wattines', '3.6557448000', '50.6124277000', '7903', 'Chapelle-à-Wattines', 6, 0);
INSERT INTO `lokatie` VALUES(1603, 'chapelle--oie', '3.6706459000', '50.5966497000', '7903', 'Chapelle-à-Oie', 6, 0);
INSERT INTO `lokatie` VALUES(1602, 'blicquy', '3.6861599000', '50.5875422000', '7903', 'Blicquy', 6, 0);
INSERT INTO `lokatie` VALUES(1601, 'thieulain', '3.5902699000', '50.6189969000', '7901', 'Thieulain', 6, 0);
INSERT INTO `lokatie` VALUES(1600, 'leuze-en-hainaut', '3.6218685000', '50.6004563000', '7900', 'Leuze-en-Hainaut', 6, 0);
INSERT INTO `lokatie` VALUES(1599, 'grandmetz', '3.6319976000', '50.6229869000', '7900', 'Grandmetz', 6, 0);
INSERT INTO `lokatie` VALUES(1598, 'wodecq', '3.7470718000', '50.7183748000', '7890', 'Wodecq', 6, 0);
INSERT INTO `lokatie` VALUES(1597, 'lahamaide', '3.7250751000', '50.6948064000', '7890', 'Lahamaide', 6, 0);
INSERT INTO `lokatie` VALUES(1596, 'ellezelles', '3.6798733000', '50.7338594000', '7890', 'Ellezelles', 6, 0);
INSERT INTO `lokatie` VALUES(1595, 'flobecqvloesberg', '3.7368762000', '50.7546909000', '7880', 'Flobecq/Vloesberg', 6, 0);
INSERT INTO `lokatie` VALUES(1594, 'montignies-lez-lens', '3.9441111000', '50.5642975000', '7870', 'Montignies-lez-Lens', 6, 0);
INSERT INTO `lokatie` VALUES(1593, 'lombise', '3.9395717000', '50.5998018000', '7870', 'Lombise', 6, 0);
INSERT INTO `lokatie` VALUES(1592, 'lens', '3.9012347000', '50.5579099000', '7870', 'Lens', 6, 0);
INSERT INTO `lokatie` VALUES(1591, 'cambron-saint-vincent', '3.9173444000', '50.5826516000', '7870', 'Cambron-Saint-Vincent', 6, 0);
INSERT INTO `lokatie` VALUES(1590, 'bauffe', '3.8519475000', '50.5686083000', '7870', 'Bauffe', 6, 0);
INSERT INTO `lokatie` VALUES(1589, 'ollignies', '3.8574228000', '50.6876172000', '7866', 'Ollignies', 6, 0);
INSERT INTO `lokatie` VALUES(1588, 'bois-de-lessines', '3.8873146000', '50.6959633000', '7866', 'Bois-de-Lessines', 6, 0);
INSERT INTO `lokatie` VALUES(1587, 'deux-acren', '3.8636775000', '50.7349596000', '7864', 'Deux-Acren', 6, 0);
INSERT INTO `lokatie` VALUES(1586, 'ghoy', '3.8022765000', '50.7369754000', '7863', 'Ghoy', 6, 0);
INSERT INTO `lokatie` VALUES(1585, 'ogy', '3.7749437000', '50.7170626000', '7862', 'Ogy', 6, 0);
INSERT INTO `lokatie` VALUES(1584, 'wannebecq', '3.8002047000', '50.6939457000', '7861', 'Wannebecq', 6, 0);
INSERT INTO `lokatie` VALUES(1583, 'papignies', '3.8185913000', '50.6847053000', '7861', 'Papignies', 6, 0);
INSERT INTO `lokatie` VALUES(1582, 'lessines', '3.8348594000', '50.7047124000', '7860', 'Lessines', 6, 0);
INSERT INTO `lokatie` VALUES(1581, 'petit-enghienlettelingen', '4.0840829000', '50.6891201000', '7850', 'Petit-Enghien/Lettelingen', 6, 0);
INSERT INTO `lokatie` VALUES(1580, 'marcqmark', '4.0172347000', '50.6922238000', '7850', 'Marcq/Mark', 6, 0);
INSERT INTO `lokatie` VALUES(1579, 'enghienedingen', '4.0369978000', '50.6930498000', '7850', 'Enghien/Edingen', 6, 0);
INSERT INTO `lokatie` VALUES(1578, 'thoricourt', '3.9502248000', '50.6112069000', '7830', 'Thoricourt', 6, 0);
INSERT INTO `lokatie` VALUES(1577, 'silly', '3.9235204000', '50.6496997000', '7830', 'Silly', 6, 0);
INSERT INTO `lokatie` VALUES(1576, 'hoves-ht', '4.0368404000', '50.6713408000', '7830', 'Hoves (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1575, 'hellebecq', '3.8887298000', '50.6635980000', '7830', 'Hellebecq', 6, 0);
INSERT INTO `lokatie` VALUES(1574, 'graty', '3.9972019000', '50.6317725000', '7830', 'Graty', 6, 0);
INSERT INTO `lokatie` VALUES(1573, 'gondregnies', '3.9115699000', '50.6271045000', '7830', 'Gondregnies', 6, 0);
INSERT INTO `lokatie` VALUES(1572, 'fouleng', '3.9285556000', '50.6186431000', '7830', 'Fouleng', 6, 0);
INSERT INTO `lokatie` VALUES(1571, 'bassilly', '3.9368825000', '50.6726982000', '7830', 'Bassilly', 6, 0);
INSERT INTO `lokatie` VALUES(1570, 'gibecq', '3.8861843000', '50.6302806000', '7823', 'Gibecq', 6, 0);
INSERT INTO `lokatie` VALUES(1569, 'meslin-l039evque', '3.8465422000', '50.6482242000', '7822', 'Meslin-l&#039;Evêque', 6, 0);
INSERT INTO `lokatie` VALUES(1568, 'isires', '3.8185263000', '50.6627115000', '7822', 'Isières', 6, 0);
INSERT INTO `lokatie` VALUES(1567, 'ghislenghien', '3.8768505000', '50.6566135000', '7822', 'Ghislenghien', 6, 0);
INSERT INTO `lokatie` VALUES(1566, 'villers-saint-amand', '3.7300805000', '50.6226255000', '7812', 'Villers-Saint-Amand', 6, 0);
INSERT INTO `lokatie` VALUES(1565, 'villers-notre-dame', '3.7350489000', '50.6179934000', '7812', 'Villers-Notre-Dame', 6, 0);
INSERT INTO `lokatie` VALUES(1564, 'moulbaix', '3.7152410000', '50.6019988000', '7812', 'Moulbaix', 6, 0);
INSERT INTO `lokatie` VALUES(1563, 'mainvault', '3.7163982000', '50.6484676000', '7812', 'Mainvault', 6, 0);
INSERT INTO `lokatie` VALUES(1562, 'ligne', '3.7049809000', '50.6210963000', '7812', 'Ligne', 6, 0);
INSERT INTO `lokatie` VALUES(1561, 'houtaing', '3.6818027000', '50.6374963000', '7812', 'Houtaing', 6, 0);
INSERT INTO `lokatie` VALUES(1560, 'arbre-ht', '3.8201529000', '50.6194823000', '7811', 'Arbre (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1559, 'maffle', '3.8018102000', '50.6200815000', '7810', 'Maffle', 6, 0);
INSERT INTO `lokatie` VALUES(1558, 'rebaix', '3.7837823000', '50.6598422000', '7804', 'Rebaix', 6, 0);
INSERT INTO `lokatie` VALUES(1557, 'ostiches', '3.7590373000', '50.6784089000', '7804', 'Ostiches', 6, 0);
INSERT INTO `lokatie` VALUES(1556, 'bouvignies', '3.7570750000', '50.6526848000', '7803', 'Bouvignies', 6, 0);
INSERT INTO `lokatie` VALUES(1555, 'ormeignies', '3.7460727000', '50.5933403000', '7802', 'Ormeignies', 6, 0);
INSERT INTO `lokatie` VALUES(1554, 'irchonwelz', '3.7590319000', '50.6214677000', '7801', 'Irchonwelz', 6, 0);
INSERT INTO `lokatie` VALUES(1553, 'lanquesaint', '3.8034337000', '50.6540172000', '7800', 'Lanquesaint', 6, 0);
INSERT INTO `lokatie` VALUES(1552, 'ath', '3.7882733000', '50.6335009000', '7800', 'Ath', 6, 0);
INSERT INTO `lokatie` VALUES(1551, 'warnetonwaasten', '2.9500627000', '50.7528134000', '7784', 'Warneton/Waasten', 6, 0);
INSERT INTO `lokatie` VALUES(1550, 'bas-warnetonneerwaasten', '2.9612713000', '50.7587031000', '7784', 'Bas-Warneton/Neerwaasten', 6, 0);
INSERT INTO `lokatie` VALUES(1549, 'bizet', '2.8831195000', '50.7087307000', '7783', 'Bizet', 6, 0);
INSERT INTO `lokatie` VALUES(1548, 'ploegsteert', '2.8733669000', '50.7323288000', '7782', 'Ploegsteert', 6, 0);
INSERT INTO `lokatie` VALUES(1547, 'houthem-comineskomen', '2.9672606000', '50.7897794000', '7781', 'Houthem (Comines/Komen)', 6, 0);
INSERT INTO `lokatie` VALUES(1546, 'comines-warnetonkomen-waasten', '2.9997573000', '50.7811468000', '7780', 'Comines-Warneton/Komen-Waasten', 6, 0);
INSERT INTO `lokatie` VALUES(1545, 'comineskomen', '2.9997573000', '50.7811468000', '7780', 'Comines/Komen', 6, 0);
INSERT INTO `lokatie` VALUES(1544, 'velaines', '3.4877864000', '50.6670183000', '7760', 'Velaines', 6, 0);
INSERT INTO `lokatie` VALUES(1543, 'pottes', '3.4044221000', '50.7324461000', '7760', 'Pottes', 6, 0);
INSERT INTO `lokatie` VALUES(1542, 'popuelles', '3.5168331000', '50.6617073000', '7760', 'Popuelles', 6, 0);
INSERT INTO `lokatie` VALUES(1541, 'molenbaix', '3.4299841000', '50.6933018000', '7760', 'Molenbaix', 6, 0);
INSERT INTO `lokatie` VALUES(1540, 'escanaffles', '3.4480145000', '50.7561968000', '7760', 'Escanaffles', 6, 0);
INSERT INTO `lokatie` VALUES(1539, 'celles-ht', '3.4573421000', '50.7118885000', '7760', 'Celles (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1538, 'russeignies', '3.5307987000', '50.7446658000', '7750', 'Russeignies', 6, 0);
INSERT INTO `lokatie` VALUES(1537, 'orroir', '3.4803367000', '50.7480780000', '7750', 'Orroir', 6, 0);
INSERT INTO `lokatie` VALUES(1536, 'mont-de-l039enclus', '3.5138588000', '50.7408102000', '7750', 'Mont-de-l&#039;Enclus', 6, 0);
INSERT INTO `lokatie` VALUES(1535, 'anseroeul', '3.5204343000', '50.7277594000', '7750', 'Anseroeul', 6, 0);
INSERT INTO `lokatie` VALUES(1534, 'amougies', '3.5066250000', '50.7437971000', '7750', 'Amougies', 6, 0);
INSERT INTO `lokatie` VALUES(1533, 'obigies', '3.3640052000', '50.6618694000', '7743', 'Obigies', 6, 0);
INSERT INTO `lokatie` VALUES(1532, 'esquelmes', '3.3479213000', '50.6656461000', '7743', 'Esquelmes', 6, 0);
INSERT INTO `lokatie` VALUES(1531, 'hrinnes-lez-pecq', '3.3679529000', '50.6983273000', '7742', 'Hérinnes-lez-Pecq', 6, 0);
INSERT INTO `lokatie` VALUES(1530, 'warcoing', '3.3459012000', '50.7030807000', '7740', 'Warcoing', 6, 0);
INSERT INTO `lokatie` VALUES(1529, 'pecq', '3.3404652000', '50.6853980000', '7740', 'Pecq', 6, 0);
INSERT INTO `lokatie` VALUES(1528, 'saint-lger-ht', '3.3146842000', '50.7054978000', '7730', 'Saint-Léger (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1527, 'nchin', '3.2680395000', '50.6672639000', '7730', 'Néchin', 6, 0);
INSERT INTO `lokatie` VALUES(1526, 'leers-nord', '3.2718004000', '50.6876099000', '7730', 'Leers-Nord', 6, 0);
INSERT INTO `lokatie` VALUES(1525, 'evregnies', '3.2876439000', '50.7126628000', '7730', 'Evregnies', 6, 0);
INSERT INTO `lokatie` VALUES(1524, 'estaimpuis', '3.2635876000', '50.7065645000', '7730', 'Estaimpuis', 6, 0);
INSERT INTO `lokatie` VALUES(1523, 'estaimbourg', '3.3177945000', '50.6825456000', '7730', 'Estaimbourg', 6, 0);
INSERT INTO `lokatie` VALUES(1522, 'bailleul', '3.3171579000', '50.6694585000', '7730', 'Bailleul', 6, 0);
INSERT INTO `lokatie` VALUES(1521, 'herseaux', '3.2366679000', '50.7228271000', '7712', 'Herseaux', 6, 0);
INSERT INTO `lokatie` VALUES(1520, 'dottigniesdottenijs', '3.2986552000', '50.7314889000', '7711', 'Dottignies/Dottenijs', 6, 0);
INSERT INTO `lokatie` VALUES(1519, 'mouscronmoeskroen', '3.2140302000', '50.7436094000', '7700', 'Mouscron/Moeskroen', 6, 0);
INSERT INTO `lokatie` VALUES(1518, 'luingne', '3.2336364000', '50.7384883000', '7700', 'Luingne', 6, 0);
INSERT INTO `lokatie` VALUES(1517, 'fontenoy', '3.4770475000', '50.5679535000', '7643', 'Fontenoy', 6, 0);
INSERT INTO `lokatie` VALUES(1516, 'calonne', '3.4291522000', '50.5745570000', '7642', 'Calonne', 6, 0);
INSERT INTO `lokatie` VALUES(1515, 'bruyelle', '3.4272595000', '50.5590567000', '7641', 'Bruyelle', 6, 0);
INSERT INTO `lokatie` VALUES(1514, 'pronnes-lez-antoing', '3.4537419000', '50.5515675000', '7640', 'Péronnes-lez-Antoing', 6, 0);
INSERT INTO `lokatie` VALUES(1513, 'maubray', '3.5001758000', '50.5515258000', '7640', 'Maubray', 6, 0);
INSERT INTO `lokatie` VALUES(1512, 'antoing', '3.4500573000', '50.5676945000', '7640', 'Antoing', 6, 0);
INSERT INTO `lokatie` VALUES(1511, 'howardries', '3.3490219000', '50.5146855000', '7624', 'Howardries', 6, 0);
INSERT INTO `lokatie` VALUES(1510, 'rongy', '3.3807184000', '50.5008205000', '7623', 'Rongy', 6, 0);
INSERT INTO `lokatie` VALUES(1509, 'laplaigne', '3.4437238000', '50.5196989000', '7622', 'Laplaigne', 6, 0);
INSERT INTO `lokatie` VALUES(1508, 'lesdain', '3.3859181000', '50.5188010000', '7621', 'Lesdain', 6, 0);
INSERT INTO `lokatie` VALUES(1507, 'wez-velvain', '3.3880728000', '50.5466125000', '7620', 'Wez-Velvain', 6, 0);
INSERT INTO `lokatie` VALUES(1506, 'jollain-merlin', '3.4039930000', '50.5392806000', '7620', 'Jollain-Merlin', 6, 0);
INSERT INTO `lokatie` VALUES(1505, 'hollain', '3.4265177000', '50.5385594000', '7620', 'Hollain', 6, 0);
INSERT INTO `lokatie` VALUES(1504, 'guignies', '3.3727285000', '50.5499808000', '7620', 'Guignies', 6, 0);
INSERT INTO `lokatie` VALUES(1503, 'brunehaut', '3.3978021000', '50.5417750000', '7620', 'Brunehaut', 6, 0);
INSERT INTO `lokatie` VALUES(1502, 'blharies', '3.4147110000', '50.5129847000', '7620', 'Bléharies', 6, 0);
INSERT INTO `lokatie` VALUES(1501, 'taintignies', '3.3372879000', '50.5435221000', '7618', 'Taintignies', 6, 0);
INSERT INTO `lokatie` VALUES(1500, 'la-glanerie', '3.3085550000', '50.5313845000', '7611', 'La Glanerie', 6, 0);
INSERT INTO `lokatie` VALUES(1499, 'rumes', '3.3022239000', '50.5548870000', '7610', 'Rumes', 6, 0);
INSERT INTO `lokatie` VALUES(1498, 'wiers', '3.5339674000', '50.5118175000', '7608', 'Wiers', 6, 0);
INSERT INTO `lokatie` VALUES(1497, 'wasmes-audemez-briffoeil', '3.5346817000', '50.5544063000', '7604', 'Wasmes-Audemez-Briffoeil', 6, 0);
INSERT INTO `lokatie` VALUES(1496, 'callenelle', '3.5258453000', '50.5296599000', '7604', 'Callenelle', 6, 0);
INSERT INTO `lokatie` VALUES(1495, 'brasmenil', '3.5464212000', '50.5416420000', '7604', 'Brasmenil', 6, 0);
INSERT INTO `lokatie` VALUES(1494, 'braffe', '3.5824019000', '50.5523606000', '7604', 'Braffe', 6, 0);
INSERT INTO `lokatie` VALUES(1493, 'baugnies', '3.5519253000', '50.5615620000', '7604', 'Baugnies', 6, 0);
INSERT INTO `lokatie` VALUES(1492, 'bon-secours', '3.6128621000', '50.4977429000', '7603', 'Bon-Secours', 6, 0);
INSERT INTO `lokatie` VALUES(1491, 'bury', '3.6053344000', '50.5459113000', '7602', 'Bury', 6, 0);
INSERT INTO `lokatie` VALUES(1490, 'roucourt', '3.5817609000', '50.5284958000', '7601', 'Roucourt', 6, 0);
INSERT INTO `lokatie` VALUES(1489, 'pruwelz', '3.6013594000', '50.5149368000', '7600', 'Péruwelz', 6, 0);
INSERT INTO `lokatie` VALUES(1488, 'warchin', '3.4335752000', '50.6107392000', '7548', 'Warchin', 6, 0);
INSERT INTO `lokatie` VALUES(1487, 'mourcourt', '3.4435133000', '50.6541333000', '7543', 'Mourcourt', 6, 0);
INSERT INTO `lokatie` VALUES(1486, 'mont-saint-aubert', '3.4128557000', '50.6658548000', '7542', 'Mont-Saint-Aubert', 6, 0);
INSERT INTO `lokatie` VALUES(1485, 'rumillies', '3.4368722000', '50.6199314000', '7540', 'Rumillies', 6, 0);
INSERT INTO `lokatie` VALUES(1484, 'quartes', '3.5115437000', '50.6516312000', '7540', 'Quartes', 6, 0);
INSERT INTO `lokatie` VALUES(1483, 'melles', '3.4806812000', '50.6466732000', '7540', 'Melles', 6, 0);
INSERT INTO `lokatie` VALUES(1482, 'kain', '3.3814146000', '50.6383817000', '7540', 'Kain', 6, 0);
INSERT INTO `lokatie` VALUES(1481, 'vezon', '3.5107552000', '50.5695367000', '7538', 'Vezon', 6, 0);
INSERT INTO `lokatie` VALUES(1480, 'vaulx', '3.4404657000', '50.5923774000', '7536', 'Vaulx', 6, 0);
INSERT INTO `lokatie` VALUES(1479, 'maulde', '3.5470846000', '50.6165736000', '7534', 'Maulde', 6, 0);
INSERT INTO `lokatie` VALUES(1478, 'barry', '3.5429854000', '50.5874938000', '7534', 'Barry', 6, 0);
INSERT INTO `lokatie` VALUES(1477, 'thimougies', '3.5225390000', '50.6392295000', '7533', 'Thimougies', 6, 0);
INSERT INTO `lokatie` VALUES(1476, 'beclers', '3.5033758000', '50.6211194000', '7532', 'Beclers', 6, 0);
INSERT INTO `lokatie` VALUES(1475, 'havinnes', '3.4685791000', '50.6226778000', '7531', 'Havinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1474, 'gaurain-ramecroix', '3.4768924000', '50.5912975000', '7530', 'Gaurain-Ramecroix', 6, 0);
INSERT INTO `lokatie` VALUES(1473, 'marquain', '3.3221547000', '50.6079141000', '7522', 'Marquain', 6, 0);
INSERT INTO `lokatie` VALUES(1472, 'lamain', '3.2927512000', '50.5976536000', '7522', 'Lamain', 6, 0);
INSERT INTO `lokatie` VALUES(1471, 'hertain', '3.2887327000', '50.6136688000', '7522', 'Hertain', 6, 0);
INSERT INTO `lokatie` VALUES(1470, 'blandain', '3.3029624000', '50.6250723000', '7522', 'Blandain', 6, 0);
INSERT INTO `lokatie` VALUES(1469, 'chercq', '3.4212671000', '50.5888321000', '7521', 'Chercq', 6, 0);
INSERT INTO `lokatie` VALUES(1468, 'templeuve', '3.2833068000', '50.6447886000', '7520', 'Templeuve', 6, 0);
INSERT INTO `lokatie` VALUES(1467, 'ramegnies-chin', '3.3363221000', '50.6513761000', '7520', 'Ramegnies-Chin', 6, 0);
INSERT INTO `lokatie` VALUES(1466, 'willemeau', '3.3530858000', '50.5741752000', '7506', 'Willemeau', 6, 0);
INSERT INTO `lokatie` VALUES(1465, 'froidmont', '3.3281659000', '50.5784624000', '7504', 'Froidmont', 6, 0);
INSERT INTO `lokatie` VALUES(1464, 'froyennes', '3.3437928000', '50.6237251000', '7503', 'Froyennes', 6, 0);
INSERT INTO `lokatie` VALUES(1463, 'esplechin', '3.2925544000', '50.5758993000', '7502', 'Esplechin', 6, 0);
INSERT INTO `lokatie` VALUES(1462, 'orcq', '3.3473905000', '50.6028664000', '7501', 'Orcq', 6, 0);
INSERT INTO `lokatie` VALUES(1461, 'tournai', '3.3884498000', '50.6058658000', '7500', 'Tournai', 6, 0);
INSERT INTO `lokatie` VALUES(1460, 'saint-maur', '3.3915019000', '50.5716974000', '7500', 'Saint-Maur', 6, 0);
INSERT INTO `lokatie` VALUES(1459, 'ere', '3.3670897000', '50.5819911000', '7500', 'Ere', 6, 0);
INSERT INTO `lokatie` VALUES(1458, 'wasmuel', '3.8467895000', '50.4456497000', '7390', 'Wasmuel', 6, 0);
INSERT INTO `lokatie` VALUES(1457, 'quaregnon', '3.8663338000', '50.4409397000', '7390', 'Quaregnon', 6, 0);
INSERT INTO `lokatie` VALUES(1456, 'roisin', '3.6955776000', '50.3320105000', '7387', 'Roisin', 6, 0);
INSERT INTO `lokatie` VALUES(1455, 'onnezies', '3.7165797000', '50.3631805000', '7387', 'Onnezies', 6, 0);
INSERT INTO `lokatie` VALUES(1454, 'montignies-sur-roc', '3.7319160000', '50.3708516000', '7387', 'Montignies-sur-Roc', 6, 0);
INSERT INTO `lokatie` VALUES(1453, 'marchipont', '3.6671791000', '50.3780722000', '7387', 'Marchipont', 6, 0);
INSERT INTO `lokatie` VALUES(1452, 'honnelles', '3.7334067000', '50.3606946000', '7387', 'Honnelles', 6, 0);
INSERT INTO `lokatie` VALUES(1451, 'fayt-le-franc', '3.7722321000', '50.3570354000', '7387', 'Fayt-le-Franc', 6, 0);
INSERT INTO `lokatie` VALUES(1450, 'erquennes', '3.7927503000', '50.3595269000', '7387', 'Erquennes', 6, 0);
INSERT INTO `lokatie` VALUES(1449, 'autreppe', '3.7342687000', '50.3483681000', '7387', 'Autreppe', 6, 0);
INSERT INTO `lokatie` VALUES(1448, 'athis', '3.7766720000', '50.3650090000', '7387', 'Athis', 6, 0);
INSERT INTO `lokatie` VALUES(1447, 'angreau', '3.6908308000', '50.3518120000', '7387', 'Angreau', 6, 0);
INSERT INTO `lokatie` VALUES(1446, 'angre', '3.6956421000', '50.3683563000', '7387', 'Angre', 6, 0);
INSERT INTO `lokatie` VALUES(1445, 'audregnies', '3.7213401000', '50.3843464000', '7382', 'Audregnies', 6, 0);
INSERT INTO `lokatie` VALUES(1444, 'quivrain', '3.6828281000', '50.4075951000', '7380', 'Quiévrain', 6, 0);
INSERT INTO `lokatie` VALUES(1443, 'baisieux', '3.6961734000', '50.3883547000', '7380', 'Baisieux', 6, 0);
INSERT INTO `lokatie` VALUES(1442, 'wihries', '3.7530487000', '50.3851767000', '7370', 'Wihéries', 6, 0);
INSERT INTO `lokatie` VALUES(1441, 'elouges', '3.7519278000', '50.4026279000', '7370', 'Elouges', 6, 0);
INSERT INTO `lokatie` VALUES(1440, 'dour', '3.7785911000', '50.3965748000', '7370', 'Dour', 6, 0);
INSERT INTO `lokatie` VALUES(1439, 'blaugies', '3.8046909000', '50.3728646000', '7370', 'Blaugies', 6, 0);
INSERT INTO `lokatie` VALUES(1438, 'thulin', '3.7389254000', '50.4291311000', '7350', 'Thulin', 6, 0);
INSERT INTO `lokatie` VALUES(1437, 'montroeul-sur-haine', '3.7059281000', '50.4384453000', '7350', 'Montroeul-sur-Haine', 6, 0);
INSERT INTO `lokatie` VALUES(1436, 'hensies', '3.6846209000', '50.4324097000', '7350', 'Hensies', 6, 0);
INSERT INTO `lokatie` VALUES(1435, 'hainin', '3.7656413000', '50.4306532000', '7350', 'Hainin', 6, 0);
INSERT INTO `lokatie` VALUES(1434, 'wasmes', '3.8471316000', '50.4144370000', '7340', 'Wasmes', 6, 0);
INSERT INTO `lokatie` VALUES(1433, 'warquignies', '3.8223364000', '50.4010045000', '7340', 'Warquignies', 6, 0);
INSERT INTO `lokatie` VALUES(1432, 'paturages', '3.8531801000', '50.4042138000', '7340', 'Paturages', 6, 0);
INSERT INTO `lokatie` VALUES(1431, 'colfontaine', '3.8427402000', '50.4036794000', '7340', 'Colfontaine', 6, 0);
INSERT INTO `lokatie` VALUES(1430, 'villerot', '3.7908877000', '50.4864379000', '7334', 'Villerot', 6, 0);
INSERT INTO `lokatie` VALUES(1429, 'hautrage', '3.7631367000', '50.4818862000', '7334', 'Hautrage', 6, 0);
INSERT INTO `lokatie` VALUES(1428, 'tertre', '3.8025278000', '50.4671082000', '7333', 'Tertre', 6, 0);
INSERT INTO `lokatie` VALUES(1427, 'sirault', '3.7877341000', '50.5056428000', '7332', 'Sirault', 6, 0);
INSERT INTO `lokatie` VALUES(1426, 'neufmaison', '3.7936245000', '50.5293211000', '7332', 'Neufmaison', 6, 0);
INSERT INTO `lokatie` VALUES(1425, 'baudour', '3.8418542000', '50.4865354000', '7331', 'Baudour', 6, 0);
INSERT INTO `lokatie` VALUES(1424, 'saint-ghislain', '3.8152846000', '50.4485696000', '7330', 'Saint-Ghislain', 6, 0);
INSERT INTO `lokatie` VALUES(1423, 'ville-pommeroeul', '3.7319588000', '50.4724177000', '7322', 'Ville-Pommeroeul', 6, 0);
INSERT INTO `lokatie` VALUES(1422, 'pommeroeul', '3.7109647000', '50.4606724000', '7322', 'Pommeroeul', 6, 0);
INSERT INTO `lokatie` VALUES(1421, 'harchies', '3.6928904000', '50.4787528000', '7321', 'Harchies', 6, 0);
INSERT INTO `lokatie` VALUES(1420, 'blaton', '3.6617443000', '50.5011488000', '7321', 'Blaton', 6, 0);
INSERT INTO `lokatie` VALUES(1419, 'bernissart', '3.6459245000', '50.4824696000', '7320', 'Bernissart', 6, 0);
INSERT INTO `lokatie` VALUES(1418, 'hornu', '3.8212501000', '50.4250826000', '7301', 'Hornu', 6, 0);
INSERT INTO `lokatie` VALUES(1417, 'boussu', '3.7969506000', '50.4258770000', '7300', 'Boussu', 6, 0);
INSERT INTO `lokatie` VALUES(1416, 'ecaussinnes-lalaing', '4.2004115000', '50.5648888000', '7191', 'Ecaussinnes-Lalaing', 6, 0);
INSERT INTO `lokatie` VALUES(1415, 'marche-lez-ecaussinnes', '4.1813737000', '50.5467245000', '7190', 'Marche-lez-Ecaussinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1414, 'ecaussinnes-d039enghien', '4.1608713000', '50.5689008000', '7190', 'Ecaussinnes-d&#039;Enghien', 6, 0);
INSERT INTO `lokatie` VALUES(1413, 'ecaussinnes', '4.1593411000', '50.5585797000', '7190', 'Ecaussinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1412, 'petit-roeulx-lez-nivelles', '4.3134840000', '50.5537960000', '7181', 'Petit-Roeulx-lez-Nivelles', 6, 0);
INSERT INTO `lokatie` VALUES(1411, 'feluy', '4.2503594000', '50.5624349000', '7181', 'Feluy', 6, 0);
INSERT INTO `lokatie` VALUES(1410, 'familleureux', '4.2112149000', '50.5219161000', '7181', 'Familleureux', 6, 0);
INSERT INTO `lokatie` VALUES(1409, 'arquennes', '4.2740745000', '50.5681988000', '7181', 'Arquennes', 6, 0);
INSERT INTO `lokatie` VALUES(1408, 'seneffe', '4.2721491000', '50.5285674000', '7180', 'Seneffe', 6, 0);
INSERT INTO `lokatie` VALUES(1407, 'manage', '4.2339976000', '50.5037088000', '7170', 'Manage', 6, 0);
INSERT INTO `lokatie` VALUES(1406, 'la-hestre', '4.2371834000', '50.4748213000', '7170', 'La Hestre', 6, 0);
INSERT INTO `lokatie` VALUES(1405, 'fayt-lez-manage', '4.2269991000', '50.4902311000', '7170', 'Fayt-lez-Manage', 6, 0);
INSERT INTO `lokatie` VALUES(1404, 'bois-d039haine', '4.2159271000', '50.5042728000', '7170', 'Bois-d&#039;Haine', 6, 0);
INSERT INTO `lokatie` VALUES(1403, 'bellecourt', '4.2546618000', '50.4847255000', '7170', 'Bellecourt', 6, 0);
INSERT INTO `lokatie` VALUES(1402, 'piton', '4.2973119000', '50.4414671000', '7160', 'Piéton', 6, 0);
INSERT INTO `lokatie` VALUES(1401, 'godarville', '4.2857100000', '50.4954264000', '7160', 'Godarville', 6, 0);
INSERT INTO `lokatie` VALUES(1400, 'chapelle-lez-herlaimont', '4.2849618000', '50.4701396000', '7160', 'Chapelle-lez-Herlaimont', 6, 0);
INSERT INTO `lokatie` VALUES(1399, 'mont-sainte-aldegonde', '4.2318875000', '50.4292421000', '7141', 'Mont-Sainte-Aldegonde', 6, 0);
INSERT INTO `lokatie` VALUES(1398, 'carnires', '4.2570161000', '50.4410292000', '7141', 'Carnières', 6, 0);
INSERT INTO `lokatie` VALUES(1397, 'morlanwelz-mariemont', '4.2297719000', '50.4523812000', '7140', 'Morlanwelz-Mariemont', 6, 0);
INSERT INTO `lokatie` VALUES(1396, 'morlanwelz', '4.2297719000', '50.4523812000', '7140', 'Morlanwelz', 6, 0);
INSERT INTO `lokatie` VALUES(1395, 'ressaix', '4.1920601000', '50.4237277000', '7134', 'Ressaix', 6, 0);
INSERT INTO `lokatie` VALUES(1394, 'pronnes-lez-binche', '4.1457086000', '50.4358603000', '7134', 'Péronnes-lez-Binche', 6, 0);
INSERT INTO `lokatie` VALUES(1393, 'leval-trahegnies', '4.2215886000', '50.4245659000', '7134', 'Leval-Trahegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1392, 'epinois', '4.2041808000', '50.4035876000', '7134', 'Epinois', 6, 0);
INSERT INTO `lokatie` VALUES(1391, 'buvrinnes', '4.2067162000', '50.3807548000', '7133', 'Buvrinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1390, 'waudrez', '4.1504698000', '50.4133658000', '7131', 'Waudrez', 6, 0);
INSERT INTO `lokatie` VALUES(1389, 'bray', '4.1053409000', '50.4311216000', '7130', 'Bray', 6, 0);
INSERT INTO `lokatie` VALUES(1388, 'binche', '4.1663035000', '50.4123838000', '7130', 'Binche', 6, 0);
INSERT INTO `lokatie` VALUES(1387, 'battignies', '4.1690015000', '50.4171330000', '7130', 'Battignies', 6, 0);
INSERT INTO `lokatie` VALUES(1386, 'vellereille-le-sec', '4.0583717000', '50.4019745000', '7120', 'Vellereille-le-Sec', 6, 0);
INSERT INTO `lokatie` VALUES(1385, 'vellereille-les-brayeux', '4.1501613000', '50.3795425000', '7120', 'Vellereille-les-Brayeux', 6, 0);
INSERT INTO `lokatie` VALUES(1384, 'rouveroy-ht', '4.0654412000', '50.3572414000', '7120', 'Rouveroy (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1383, 'peissant', '4.1188181000', '50.3516994000', '7120', 'Peissant', 6, 0);
INSERT INTO `lokatie` VALUES(1382, 'haulchin', '4.0821106000', '50.3837644000', '7120', 'Haulchin', 6, 0);
INSERT INTO `lokatie` VALUES(1381, 'fauroeulx', '4.1074825000', '50.3707981000', '7120', 'Fauroeulx', 6, 0);
INSERT INTO `lokatie` VALUES(1380, 'estinnes-au-val', '4.1040147000', '50.4115339000', '7120', 'Estinnes-au-Val', 6, 0);
INSERT INTO `lokatie` VALUES(1379, 'estinnes-au-mont', '4.0960938000', '50.3946011000', '7120', 'Estinnes-au-Mont', 6, 0);
INSERT INTO `lokatie` VALUES(1378, 'estinnes', '4.1007199000', '50.3690200000', '7120', 'Estinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1377, 'croix-lez-rouveroy', '4.0748463000', '50.3611889000', '7120', 'Croix-lez-Rouveroy', 6, 0);
INSERT INTO `lokatie` VALUES(1376, 'strpy-bracquegnies', '4.1203347000', '50.4736360000', '7110', 'Strépy-Bracquegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1375, 'maurage', '4.0991709000', '50.4568110000', '7110', 'Maurage', 6, 0);
INSERT INTO `lokatie` VALUES(1374, 'houdeng-goegnies', '4.1568564000', '50.4842706000', '7110', 'Houdeng-Goegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1373, 'houdeng-aimeries', '4.1500016000', '50.4827253000', '7110', 'Houdeng-Aimeries', 6, 0);
INSERT INTO `lokatie` VALUES(1372, 'boussoit', '4.0835631000', '50.4598641000', '7110', 'Boussoit', 6, 0);
INSERT INTO `lokatie` VALUES(1371, 'trivires', '4.1454460000', '50.4474226000', '7100', 'Trivières', 6, 0);
INSERT INTO `lokatie` VALUES(1370, 'saint-vaast', '4.1611313000', '50.4528399000', '7100', 'Saint-Vaast', 6, 0);
INSERT INTO `lokatie` VALUES(1369, 'la-louvire', '4.1879755000', '50.4778799000', '7100', 'La Louvière', 6, 0);
INSERT INTO `lokatie` VALUES(1368, 'haine-saint-pierre', '4.2011986000', '50.4540192000', '7100', 'Haine-Saint-Pierre', 6, 0);
INSERT INTO `lokatie` VALUES(1367, 'haine-saint-paul', '4.1885239000', '50.4549772000', '7100', 'Haine-Saint-Paul', 6, 0);
INSERT INTO `lokatie` VALUES(1366, 'steenkerque-ht', '4.0686545000', '50.6430493000', '7090', 'Steenkerque (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1365, 'ronquires', '4.2211350000', '50.6085982000', '7090', 'Ronquières', 6, 0);
INSERT INTO `lokatie` VALUES(1364, 'petit-roeulx-lez-braine', '4.0883882000', '50.6251304000', '7090', 'Petit-Roeulx-lez-Braine', 6, 0);
INSERT INTO `lokatie` VALUES(1363, 'henripont', '4.1841071000', '50.5973804000', '7090', 'Henripont', 6, 0);
INSERT INTO `lokatie` VALUES(1362, 'hennuyres', '4.1695296000', '50.6383914000', '7090', 'Hennuyères', 6, 0);
INSERT INTO `lokatie` VALUES(1361, 'braine-le-comte', '4.1364208000', '50.6127273000', '7090', 'Braine-le-Comte', 6, 0);
INSERT INTO `lokatie` VALUES(1360, 'sars-la-bruyre', '3.8780546000', '50.3719507000', '7080', 'Sars-la-Bruyère', 6, 0);
INSERT INTO `lokatie` VALUES(1359, 'noirchain', '3.9308687000', '50.4005704000', '7080', 'Noirchain', 6, 0);
INSERT INTO `lokatie` VALUES(1358, 'la-bouverie', '3.8747703000', '50.4055130000', '7080', 'La Bouverie', 6, 0);
INSERT INTO `lokatie` VALUES(1357, 'frameries', '3.8932273000', '50.4104781000', '7080', 'Frameries', 6, 0);
INSERT INTO `lokatie` VALUES(1356, 'eugies-frameries', '3.8878672000', '50.3902905000', '7080', 'Eugies (Frameries)', 6, 0);
INSERT INTO `lokatie` VALUES(1355, 'ville-sur-haine-le-roeulx', '4.0630442000', '50.4766031000', '7070', 'Ville-sur-Haine (Le Roeulx)', 6, 0);
INSERT INTO `lokatie` VALUES(1354, 'thieu', '4.0914939000', '50.4735204000', '7070', 'Thieu', 6, 0);
INSERT INTO `lokatie` VALUES(1353, 'mignault', '4.1521460000', '50.5289023000', '7070', 'Mignault', 6, 0);
INSERT INTO `lokatie` VALUES(1352, 'le-roeulx', '4.1087519000', '50.5028994000', '7070', 'Le Roeulx', 6, 0);
INSERT INTO `lokatie` VALUES(1351, 'gottignies', '4.0619317000', '50.4960239000', '7070', 'Gottignies', 6, 0);
INSERT INTO `lokatie` VALUES(1350, 'neufvilles', '4.0027161000', '50.5679938000', '7063', 'Neufvilles', 6, 0);
INSERT INTO `lokatie` VALUES(1349, 'chausse-notre-dame-louvignies', '3.9984055000', '50.5928987000', '7063', 'Chaussée-Notre-Dame-Louvignies', 6, 0);
INSERT INTO `lokatie` VALUES(1348, 'naast', '4.0964803000', '50.5504316000', '7062', 'Naast', 6, 0);
INSERT INTO `lokatie` VALUES(1347, 'thieusies', '4.0487617000', '50.5153719000', '7061', 'Thieusies', 6, 0);
INSERT INTO `lokatie` VALUES(1346, 'casteau-soignies', '4.0157233000', '50.5133388000', '7061', 'Casteau (Soignies)', 6, 0);
INSERT INTO `lokatie` VALUES(1345, 'soignies', '4.0712466000', '50.5795964000', '7060', 'Soignies', 6, 0);
INSERT INTO `lokatie` VALUES(1344, 'horrues', '4.0421494000', '50.6086073000', '7060', 'Horrues', 6, 0);
INSERT INTO `lokatie` VALUES(1343, 'masnuy-saint-pierre', '3.9596438000', '50.5371585000', '7050', 'Masnuy-Saint-Pierre', 6, 0);
INSERT INTO `lokatie` VALUES(1342, 'masnuy-saint-jean-jurbise', '3.9402826000', '50.5325972000', '7050', 'Masnuy-Saint-Jean (Jurbise)', 6, 0);
INSERT INTO `lokatie` VALUES(1341, 'jurbise', '3.9110404000', '50.5333333000', '7050', 'Jurbise', 6, 0);
INSERT INTO `lokatie` VALUES(1340, 'herchies', '3.8577814000', '50.5288983000', '7050', 'Herchies', 6, 0);
INSERT INTO `lokatie` VALUES(1339, 'erbisoeul', '3.8966975000', '50.5147340000', '7050', 'Erbisoeul', 6, 0);
INSERT INTO `lokatie` VALUES(1338, 'erbaut', '3.8860485000', '50.5325417000', '7050', 'Erbaut', 6, 0);
INSERT INTO `lokatie` VALUES(1337, 'havay', '3.9842382000', '50.3624675000', '7041', 'Havay', 6, 0);
INSERT INTO `lokatie` VALUES(1336, 'givry', '4.0289700000', '50.3796607000', '7041', 'Givry', 6, 0);
INSERT INTO `lokatie` VALUES(1335, 'quvy-le-petit', '3.9376920000', '50.3672737000', '7040', 'Quévy-le-Petit', 6, 0);
INSERT INTO `lokatie` VALUES(1334, 'quvy-le-grand', '3.9472017000', '50.3606875000', '7040', 'Quévy-le-Grand', 6, 0);
INSERT INTO `lokatie` VALUES(1333, 'quvy', '3.9303164000', '50.3748962000', '7040', 'Quévy', 6, 0);
INSERT INTO `lokatie` VALUES(1332, 'goegnies-chausse', '3.9495629000', '50.3437454000', '7040', 'Goegnies-Chaussée', 6, 0);
INSERT INTO `lokatie` VALUES(1331, 'genly', '3.9183422000', '50.3922365000', '7040', 'Genly', 6, 0);
INSERT INTO `lokatie` VALUES(1330, 'bougnies', '3.9420831000', '50.3879819000', '7040', 'Bougnies', 6, 0);
INSERT INTO `lokatie` VALUES(1329, 'blaregnies', '3.8975237000', '50.3570012000', '7040', 'Blaregnies', 6, 0);
INSERT INTO `lokatie` VALUES(1328, 'aulnois', '3.9032254000', '50.3397583000', '7040', 'Aulnois', 6, 0);
INSERT INTO `lokatie` VALUES(1327, 'asquillies', '3.9582913000', '50.4023242000', '7040', 'Asquillies', 6, 0);
INSERT INTO `lokatie` VALUES(1326, 'saint-denis-ht', '4.0181044000', '50.4907206000', '7034', 'Saint-Denis (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1325, 'obourg', '4.0079885000', '50.4736486000', '7034', 'Obourg', 6, 0);
INSERT INTO `lokatie` VALUES(1324, 'cuesmes', '3.9199815000', '50.4321532000', '7033', 'Cuesmes', 6, 0);
INSERT INTO `lokatie` VALUES(1323, 'spiennes', '3.9896660000', '50.4271996000', '7032', 'Spiennes', 6, 0);
INSERT INTO `lokatie` VALUES(1322, 'villers-saint-ghislain', '4.0452797000', '50.4304576000', '7031', 'Villers-Saint-Ghislain', 6, 0);
INSERT INTO `lokatie` VALUES(1321, 'saint-symphorien', '4.0189381000', '50.4391342000', '7030', 'Saint-Symphorien', 6, 0);
INSERT INTO `lokatie` VALUES(1320, 'ciply', '3.9448508000', '50.4132006000', '7024', 'Ciply', 6, 0);
INSERT INTO `lokatie` VALUES(1319, 'nouvelles', '3.9675988000', '50.4104946000', '7022', 'Nouvelles', 6, 0);
INSERT INTO `lokatie` VALUES(1318, 'mesvin', '3.9593432000', '50.4267918000', '7022', 'Mesvin', 6, 0);
INSERT INTO `lokatie` VALUES(1317, 'hyon', '3.9636618000', '50.4401680000', '7022', 'Hyon', 6, 0);
INSERT INTO `lokatie` VALUES(1316, 'harveng', '3.9867549000', '50.3946524000', '7022', 'Harveng', 6, 0);
INSERT INTO `lokatie` VALUES(1315, 'harmignies', '4.0182229000', '50.4038165000', '7022', 'Harmignies', 6, 0);
INSERT INTO `lokatie` VALUES(1314, 'havr', '4.0463096000', '50.4588978000', '7021', 'Havré', 6, 0);
INSERT INTO `lokatie` VALUES(1313, 'nimy', '3.9569823000', '50.4769996000', '7020', 'Nimy', 6, 0);
INSERT INTO `lokatie` VALUES(1312, 'maisires', '3.9652709000', '50.4886066000', '7020', 'Maisières', 6, 0);
INSERT INTO `lokatie` VALUES(1311, 'jemappes', '3.8893442000', '50.4482019000', '7012', 'Jemappes', 6, 0);
INSERT INTO `lokatie` VALUES(1310, 'flnu', '3.8879075000', '50.4369914000', '7012', 'Flénu', 6, 0);
INSERT INTO `lokatie` VALUES(1309, 'ghlin', '3.8959785000', '50.4795587000', '7011', 'Ghlin', 6, 0);
INSERT INTO `lokatie` VALUES(1308, 'mons', '3.9730745000', '50.4614181000', '7000', 'Mons', 6, 0);
INSERT INTO `lokatie` VALUES(1307, 'seloignes', '4.2561211000', '50.0164911000', '6596', 'Seloignes', 6, 0);
INSERT INTO `lokatie` VALUES(1306, 'forges-philippe', '4.2524049000', '49.9658445000', '6596', 'Forges-Philippe', 6, 0);
INSERT INTO `lokatie` VALUES(1305, 'beauwelz', '4.1565846000', '50.0155784000', '6594', 'Beauwelz', 6, 0);
INSERT INTO `lokatie` VALUES(1304, 'macquenoise', '4.2128323000', '49.9732455000', '6593', 'Macquenoise', 6, 0);
INSERT INTO `lokatie` VALUES(1303, 'monceau-imbrechies', '4.2243237000', '50.0363309000', '6592', 'Monceau-Imbrechies', 6, 0);
INSERT INTO `lokatie` VALUES(1302, 'macon', '4.2061955000', '50.0506091000', '6591', 'Macon', 6, 0);
INSERT INTO `lokatie` VALUES(1301, 'momignies', '4.1789941000', '50.0310150000', '6590', 'Momignies', 6, 0);
INSERT INTO `lokatie` VALUES(1300, 'merbes-sainte-marie', '4.1704478000', '50.3551045000', '6567', 'Merbes-Sainte-Marie', 6, 0);
INSERT INTO `lokatie` VALUES(1299, 'merbes-le-chteau', '4.1642471000', '50.3239056000', '6567', 'Merbes-le-Château', 6, 0);
INSERT INTO `lokatie` VALUES(1298, 'labuissire', '4.1857308000', '50.3155049000', '6567', 'Labuissière', 6, 0);
INSERT INTO `lokatie` VALUES(1297, 'fontaine-valmont', '4.2138673000', '50.3216074000', '6567', 'Fontaine-Valmont', 6, 0);
INSERT INTO `lokatie` VALUES(1296, 'solre-sur-sambre', '4.1524985000', '50.3092727000', '6560', 'Solre-sur-Sambre', 6, 0);
INSERT INTO `lokatie` VALUES(1295, 'montignies-saint-christophe', '4.1883750000', '50.2816509000', '6560', 'Montignies-Saint-Christophe', 6, 0);
INSERT INTO `lokatie` VALUES(1294, 'hantes-wihries', '4.1770932000', '50.3064598000', '6560', 'Hantes-Wihéries', 6, 0);
INSERT INTO `lokatie` VALUES(1293, 'grand-reng', '4.0698884000', '50.3280771000', '6560', 'Grand-Reng', 6, 0);
INSERT INTO `lokatie` VALUES(1292, 'erquelinnes', '4.1192106000', '50.3093346000', '6560', 'Erquelinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1291, 'bersillies-l039abbaye', '4.1523037000', '50.2624949000', '6560', 'Bersillies-l&#039;Abbaye', 6, 0);
INSERT INTO `lokatie` VALUES(1290, 'bienne-lez-happart', '4.2124062000', '50.3572760000', '6543', 'Bienne-lez-Happart', 6, 0);
INSERT INTO `lokatie` VALUES(1289, 'sars-la-buissire', '4.2127589000', '50.3391680000', '6542', 'Sars-la-Buissière', 6, 0);
INSERT INTO `lokatie` VALUES(1288, 'mont-sainte-genevive', '4.2326517000', '50.3751126000', '6540', 'Mont-Sainte-Geneviève', 6, 0);
INSERT INTO `lokatie` VALUES(1287, 'lobbes', '4.2664776000', '50.3461857000', '6540', 'Lobbes', 6, 0);
INSERT INTO `lokatie` VALUES(1286, 'thuillies', '4.3277436000', '50.2946898000', '6536', 'Thuillies', 6, 0);
INSERT INTO `lokatie` VALUES(1285, 'donstiennes', '4.3106966000', '50.2849958000', '6536', 'Donstiennes', 6, 0);
INSERT INTO `lokatie` VALUES(1284, 'goze', '4.3486884000', '50.3445085000', '6534', 'Gozée', 6, 0);
INSERT INTO `lokatie` VALUES(1283, 'bierce', '4.2626790000', '50.3244285000', '6533', 'Biercée', 6, 0);
INSERT INTO `lokatie` VALUES(1282, 'ragnies', '4.2690998000', '50.3061069000', '6532', 'Ragnies', 6, 0);
INSERT INTO `lokatie` VALUES(1281, 'biesme-sous-thuin', '4.3107260000', '50.3174907000', '6531', 'Biesme-sous-Thuin', 6, 0);
INSERT INTO `lokatie` VALUES(1280, 'thuin', '4.2880650000', '50.3398933000', '6530', 'Thuin', 6, 0);
INSERT INTO `lokatie` VALUES(1279, 'leers-et-fosteau', '4.2452632000', '50.3043705000', '6530', 'Leers-et-Fosteau', 6, 0);
INSERT INTO `lokatie` VALUES(1278, 'stre-ht', '4.2766073000', '50.2748384000', '6511', 'Strée (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1277, 'thirimont', '4.2357547000', '50.2612149000', '6500', 'Thirimont', 6, 0);
INSERT INTO `lokatie` VALUES(1276, 'solre-saint-gry', '4.2443016000', '50.2168292000', '6500', 'Solre-Saint-Géry', 6, 0);
INSERT INTO `lokatie` VALUES(1275, 'renlies', '4.2652463000', '50.1919834000', '6500', 'Renlies', 6, 0);
INSERT INTO `lokatie` VALUES(1274, 'leval-chaudeville', '4.2102403000', '50.2358602000', '6500', 'Leval-Chaudeville', 6, 0);
INSERT INTO `lokatie` VALUES(1273, 'leugnies', '4.1960986000', '50.2244225000', '6500', 'Leugnies', 6, 0);
INSERT INTO `lokatie` VALUES(1272, 'beaumont', '4.2351718000', '50.2373840000', '6500', 'Beaumont', 6, 0);
INSERT INTO `lokatie` VALUES(1271, 'barbenon', '4.2786517000', '50.2201983000', '6500', 'Barbençon', 6, 0);
INSERT INTO `lokatie` VALUES(1270, 'sivry-rance', '4.1813855000', '50.1699509000', '6470', 'Sivry-Rance', 6, 0);
INSERT INTO `lokatie` VALUES(1269, 'sivry', '4.1813855000', '50.1699509000', '6470', 'Sivry', 6, 0);
INSERT INTO `lokatie` VALUES(1268, 'sautin', '4.2264823000', '50.1639883000', '6470', 'Sautin', 6, 0);
INSERT INTO `lokatie` VALUES(1267, 'rance', '4.2691963000', '50.1434603000', '6470', 'Rance', 6, 0);
INSERT INTO `lokatie` VALUES(1266, 'montbliart', '4.2236837000', '50.1338172000', '6470', 'Montbliart', 6, 0);
INSERT INTO `lokatie` VALUES(1265, 'grandrieu', '4.1705984000', '50.2015674000', '6470', 'Grandrieu', 6, 0);
INSERT INTO `lokatie` VALUES(1264, 'rizes', '4.3682218000', '49.9607133000', '6464', 'Rièzes', 6, 0);
INSERT INTO `lokatie` VALUES(1263, 'l039escaillre', '4.4316464000', '49.9471621000', '6464', 'l&#039;Escaillère', 6, 0);
INSERT INTO `lokatie` VALUES(1262, 'forges', '4.3200378000', '50.0223654000', '6464', 'Forges', 6, 0);
INSERT INTO `lokatie` VALUES(1261, 'bourlers', '4.3409814000', '50.0252080000', '6464', 'Bourlers', 6, 0);
INSERT INTO `lokatie` VALUES(1260, 'baileux', '4.3754986000', '50.0295525000', '6464', 'Baileux', 6, 0);
INSERT INTO `lokatie` VALUES(1259, 'lompret', '4.3830032000', '50.0723775000', '6463', 'Lompret', 6, 0);
INSERT INTO `lokatie` VALUES(1258, 'vaulx-lez-chimay', '4.3632258000', '50.0628279000', '6462', 'Vaulx-lez-Chimay', 6, 0);
INSERT INTO `lokatie` VALUES(1257, 'virelles', '4.3318706000', '50.0768689000', '6461', 'Virelles', 6, 0);
INSERT INTO `lokatie` VALUES(1256, 'villers-la-tour', '4.2631037000', '50.0344607000', '6460', 'Villers-la-Tour', 6, 0);
INSERT INTO `lokatie` VALUES(1255, 'salles', '4.2463494000', '50.0557441000', '6460', 'Salles', 6, 0);
INSERT INTO `lokatie` VALUES(1254, 'saint-remy-ht', '4.2971022000', '50.0459170000', '6460', 'Saint-Remy (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1253, 'robechies', '4.2783833000', '50.0730655000', '6460', 'Robechies', 6, 0);
INSERT INTO `lokatie` VALUES(1252, 'chimay', '4.3117863000', '50.0483970000', '6460', 'Chimay', 6, 0);
INSERT INTO `lokatie` VALUES(1251, 'bailivre', '4.2384262000', '50.0691978000', '6460', 'Bailièvre', 6, 0);
INSERT INTO `lokatie` VALUES(1250, 'erpion', '4.3508443000', '50.1998292000', '6441', 'Erpion', 6, 0);
INSERT INTO `lokatie` VALUES(1249, 'vergnies', '4.3052991000', '50.1990792000', '6440', 'Vergnies', 6, 0);
INSERT INTO `lokatie` VALUES(1248, 'froidchapelle', '4.3270829000', '50.1508366000', '6440', 'Froidchapelle', 6, 0);
INSERT INTO `lokatie` VALUES(1247, 'fourbechies', '4.3072961000', '50.1634408000', '6440', 'Fourbechies', 6, 0);
INSERT INTO `lokatie` VALUES(1246, 'boussu-lez-walcourt', '4.3759403000', '50.2256214000', '6440', 'Boussu-lez-Walcourt', 6, 0);
INSERT INTO `lokatie` VALUES(1245, 'villers-poterie', '4.5491359000', '50.3539320000', '6280', 'Villers-Poterie', 6, 0);
INSERT INTO `lokatie` VALUES(1244, 'loverval', '4.4736015000', '50.3747442000', '6280', 'Loverval', 6, 0);
INSERT INTO `lokatie` VALUES(1243, 'joncret', '4.5133153000', '50.3534373000', '6280', 'Joncret', 6, 0);
INSERT INTO `lokatie` VALUES(1242, 'gougnies', '4.5753483000', '50.3551798000', '6280', 'Gougnies', 6, 0);
INSERT INTO `lokatie` VALUES(1241, 'gerpinnes', '4.5261517000', '50.3373113000', '6280', 'Gerpinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1240, 'acoz', '4.5307169000', '50.3593652000', '6280', 'Acoz', 6, 0);
INSERT INTO `lokatie` VALUES(1239, 'roselies', '4.5732369000', '50.4290630000', '6250', 'Roselies', 6, 0);
INSERT INTO `lokatie` VALUES(1238, 'presles', '4.5785708000', '50.3854726000', '6250', 'Presles', 6, 0);
INSERT INTO `lokatie` VALUES(1237, 'pont-de-loup', '4.5461032000', '50.4168098000', '6250', 'Pont-de-Loup', 6, 0);
INSERT INTO `lokatie` VALUES(1236, 'aiseau-presles', '4.5809294000', '50.4080301000', '6250', 'Aiseau-Presles', 6, 0);
INSERT INTO `lokatie` VALUES(1235, 'aiseau', '4.5809294000', '50.4080301000', '6250', 'Aiseau', 6, 0);
INSERT INTO `lokatie` VALUES(1234, 'pironchamps', '4.5323273000', '50.4236453000', '6240', 'Pironchamps', 6, 0);
INSERT INTO `lokatie` VALUES(1233, 'farciennes', '4.5541287000', '50.4289687000', '6240', 'Farciennes', 6, 0);
INSERT INTO `lokatie` VALUES(1232, 'luttre', '4.3956236000', '50.5088342000', '6238', 'Luttre', 6, 0);
INSERT INTO `lokatie` VALUES(1231, 'liberchies', '4.4211124000', '50.5137505000', '6238', 'Liberchies', 6, 0);
INSERT INTO `lokatie` VALUES(1230, 'viesville', '4.4092432000', '50.4914536000', '6230', 'Viesville', 6, 0);
INSERT INTO `lokatie` VALUES(1229, 'thimon', '4.4280163000', '50.4902443000', '6230', 'Thiméon', 6, 0);
INSERT INTO `lokatie` VALUES(1228, 'pont--celles', '4.3617574000', '50.5118576000', '6230', 'Pont-à-Celles', 6, 0);
INSERT INTO `lokatie` VALUES(1227, 'obaix', '4.3622834000', '50.5267712000', '6230', 'Obaix', 6, 0);
INSERT INTO `lokatie` VALUES(1226, 'buzet', '4.3670724000', '50.5381877000', '6230', 'Buzet', 6, 0);
INSERT INTO `lokatie` VALUES(1225, 'wanferce-baulet', '4.5803692000', '50.4805689000', '6224', 'Wanfercée-Baulet', 6, 0);
INSERT INTO `lokatie` VALUES(1224, 'wagnele', '4.5280484000', '50.5214974000', '6223', 'Wagnelée', 6, 0);
INSERT INTO `lokatie` VALUES(1223, 'brye', '4.5605756000', '50.5306016000', '6222', 'Brye', 6, 0);
INSERT INTO `lokatie` VALUES(1222, 'saint-amand', '4.5343872000', '50.5031025000', '6221', 'Saint-Amand', 6, 0);
INSERT INTO `lokatie` VALUES(1221, 'wangenies', '4.5186629000', '50.4769478000', '6220', 'Wangenies', 6, 0);
INSERT INTO `lokatie` VALUES(1220, 'lambusart', '4.5519456000', '50.4563277000', '6220', 'Lambusart', 6, 0);
INSERT INTO `lokatie` VALUES(1219, 'heppignies', '4.4932598000', '50.4814121000', '6220', 'Heppignies', 6, 0);
INSERT INTO `lokatie` VALUES(1218, 'fleurus', '4.5496719000', '50.4830743000', '6220', 'Fleurus', 6, 0);
INSERT INTO `lokatie` VALUES(1217, 'mellet', '4.4850788000', '50.5050113000', '6211', 'Mellet', 6, 0);
INSERT INTO `lokatie` VALUES(1216, 'wayaux', '4.4731558000', '50.4897549000', '6210', 'Wayaux', 6, 0);
INSERT INTO `lokatie` VALUES(1215, 'villers-perwin', '4.4779597000', '50.5262364000', '6210', 'Villers-Perwin', 6, 0);
INSERT INTO `lokatie` VALUES(1214, 'rves', '4.4165755000', '50.5383203000', '6210', 'Rèves', 6, 0);
INSERT INTO `lokatie` VALUES(1213, 'les-bons-villers', '4.4476802000', '50.5427462000', '6210', 'Les Bons Villers', 6, 0);
INSERT INTO `lokatie` VALUES(1212, 'frasnes-lez-gosselies', '4.4463924000', '50.5316033000', '6210', 'Frasnes-lez-Gosselies', 6, 0);
INSERT INTO `lokatie` VALUES(1211, 'chtelineau', '4.5191475000', '50.4140136000', '6200', 'Châtelineau', 6, 0);
INSERT INTO `lokatie` VALUES(1210, 'chtelet', '4.5219753000', '50.4034824000', '6200', 'Châtelet', 6, 0);
INSERT INTO `lokatie` VALUES(1209, 'bouffioulx', '4.5147355000', '50.3896204000', '6200', 'Bouffioulx', 6, 0);
INSERT INTO `lokatie` VALUES(1208, 'trazegnies', '4.3171534000', '50.4595342000', '6183', 'Trazegnies', 6, 0);
INSERT INTO `lokatie` VALUES(1207, 'souvret', '4.3401048000', '50.4483224000', '6182', 'Souvret', 6, 0);
INSERT INTO `lokatie` VALUES(1206, 'gouy-lez-piton', '4.3219095000', '50.4904448000', '6181', 'Gouy-lez-Piéton', 6, 0);
INSERT INTO `lokatie` VALUES(1205, 'courcelles', '4.3662504000', '50.4577042000', '6180', 'Courcelles', 6, 0);
INSERT INTO `lokatie` VALUES(1204, 'anderlues', '4.2778508000', '50.4040326000', '6150', 'Anderlues', 6, 0);
INSERT INTO `lokatie` VALUES(1203, 'leernes', '4.3183285000', '50.3870152000', '6142', 'Leernes', 6, 0);
INSERT INTO `lokatie` VALUES(1202, 'forchies-la-marche', '4.3219947000', '50.4308720000', '6141', 'Forchies-la-Marche', 6, 0);
INSERT INTO `lokatie` VALUES(1201, 'fontaine-l039evque', '4.3249526000', '50.4100558000', '6140', 'Fontaine-l&#039;Evêque', 6, 0);
INSERT INTO `lokatie` VALUES(1200, 'nalinnes', '4.4452356000', '50.3247185000', '6120', 'Nalinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1199, 'marbaix-ht', '4.3692589000', '50.3269512000', '6120', 'Marbaix (Ht.)', 6, 0);
INSERT INTO `lokatie` VALUES(1198, 'jamioulx', '4.4134563000', '50.3544821000', '6120', 'Jamioulx', 6, 0);
INSERT INTO `lokatie` VALUES(1197, 'ham-sur-heure-nalinnes', '4.4151808000', '50.3368349000', '6120', 'Ham-sur-Heure-Nalinnes', 6, 0);
INSERT INTO `lokatie` VALUES(1196, 'ham-sur-heure', '4.4151808000', '50.3368349000', '6120', 'Ham-sur-Heure', 6, 0);
INSERT INTO `lokatie` VALUES(1195, 'cour-sur-heure', '4.3868041000', '50.2965671000', '6120', 'Cour-sur-Heure', 6, 0);
INSERT INTO `lokatie` VALUES(1194, 'landelies', '4.3454781000', '50.3834182000', '6111', 'Landelies', 6, 0);
INSERT INTO `lokatie` VALUES(1193, 'montigny-le-tilleul', '4.3779578000', '50.3744413000', '6110', 'Montigny-le-Tilleul', 6, 0);
INSERT INTO `lokatie` VALUES(1192, 'montignies-sur-sambre', '4.4729564000', '50.4096402000', '6061', 'Montignies-sur-Sambre', 6, 0);
INSERT INTO `lokatie` VALUES(1191, 'gilly', '4.4858661000', '50.4324417000', '6060', 'Gilly', 6, 0);
INSERT INTO `lokatie` VALUES(1190, 'roux', '4.3910647000', '50.4386442000', '6044', 'Roux', 6, 0);
INSERT INTO `lokatie` VALUES(1189, 'ransart', '4.4768560000', '50.4535052000', '6043', 'Ransart', 6, 0);
INSERT INTO `lokatie` VALUES(1188, 'lodelinsart', '4.4455173000', '50.4314000000', '6042', 'Lodelinsart', 6, 0);
INSERT INTO `lokatie` VALUES(1187, 'gosselies', '4.4415956000', '50.4652162000', '6041', 'Gosselies', 6, 0);
INSERT INTO `lokatie` VALUES(1186, 'jumet', '4.4383382000', '50.4446203000', '6040', 'Jumet', 6, 0);
INSERT INTO `lokatie` VALUES(1185, 'mont-sur-marchienne', '4.4186648000', '50.3900465000', '6032', 'Mont-sur-Marchienne', 6, 0);
INSERT INTO `lokatie` VALUES(1184, 'monceau-sur-sambre', '4.3755799000', '50.4185168000', '6031', 'Monceau-sur-Sambre', 6, 0);
INSERT INTO `lokatie` VALUES(1183, 'marchienne-au-pont', '4.3957984000', '50.4073452000', '6030', 'Marchienne-au-Pont', 6, 0);
INSERT INTO `lokatie` VALUES(1182, 'goutroux', '4.3567302000', '50.4125204000', '6030', 'Goutroux', 6, 0);
INSERT INTO `lokatie` VALUES(1181, 'dampremy', '4.4246593000', '50.4166622000', '6020', 'Dampremy', 6, 0);
INSERT INTO `lokatie` VALUES(1180, 'couillet', '4.4721299000', '50.3864776000', '6010', 'Couillet', 6, 0);
INSERT INTO `lokatie` VALUES(1179, 'marcinelle', '4.4408527000', '50.3824059000', '6001', 'Marcinelle', 6, 0);
INSERT INTO `lokatie` VALUES(1178, 'charleroi', '4.4442400000', '50.4114604000', '6000', 'Charleroi', 6, 0);
INSERT INTO `lokatie` VALUES(1176, 'zonnebeke', '2.9878171000', '50.8727532000', '8980', 'Zonnebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1175, 'zandvoorde-zonnebeke', '2.9811906000', '50.8129046000', '8980', 'Zandvoorde (Zonnebeke)', 5, 0);
INSERT INTO `lokatie` VALUES(1174, 'passendale', '3.0212261000', '50.9007200000', '8980', 'Passendale', 5, 0);
INSERT INTO `lokatie` VALUES(1173, 'geluveld', '2.9939528000', '50.8338520000', '8980', 'Geluveld', 5, 0);
INSERT INTO `lokatie` VALUES(1172, 'beselare', '3.0245939000', '50.8479184000', '8980', 'Beselare', 5, 0);
INSERT INTO `lokatie` VALUES(1171, 'watou', '2.6467507000', '50.8260940000', '8978', 'Watou', 5, 0);
INSERT INTO `lokatie` VALUES(1170, 'roesbrugge-haringe', '2.6251090000', '50.9151450000', '8972', 'Roesbrugge-Haringe', 5, 0);
INSERT INTO `lokatie` VALUES(1169, 'proven', '2.6568372000', '50.8914400000', '8972', 'Proven', 5, 0);
INSERT INTO `lokatie` VALUES(1168, 'krombeke', '2.6884907000', '50.9148184000', '8972', 'Krombeke', 5, 0);
INSERT INTO `lokatie` VALUES(1167, 'reningelst', '2.7632526000', '50.8170048000', '8970', 'Reningelst', 5, 0);
INSERT INTO `lokatie` VALUES(1166, 'poperinge', '2.7270385000', '50.8555799000', '8970', 'Poperinge', 5, 0);
INSERT INTO `lokatie` VALUES(1165, 'mesenmessines', '2.8974417000', '50.7603257000', '8957', 'Mesen/Messines', 5, 0);
INSERT INTO `lokatie` VALUES(1164, 'loker', '2.7847702000', '50.7838666000', '8958', 'Loker', 5, 0);
INSERT INTO `lokatie` VALUES(1163, 'kemmel', '2.8303268000', '50.7853730000', '8956', 'Kemmel', 5, 0);
INSERT INTO `lokatie` VALUES(1162, 'westouter', '2.7458207000', '50.7977892000', '8954', 'Westouter', 5, 0);
INSERT INTO `lokatie` VALUES(1161, 'wijtschate', '2.9083912000', '50.7782550000', '8953', 'Wijtschate', 5, 0);
INSERT INTO `lokatie` VALUES(1160, 'wulvergem', '2.8435926000', '50.7668483000', '8952', 'Wulvergem', 5, 0);
INSERT INTO `lokatie` VALUES(1159, 'dranouter', '2.7909855000', '50.7551180000', '8951', 'Dranouter', 5, 0);
INSERT INTO `lokatie` VALUES(1158, 'nieuwkerke', '2.8250977000', '50.7335060000', '8950', 'Nieuwkerke', 5, 0);
INSERT INTO `lokatie` VALUES(1157, 'heuvelland', '2.8250977000', '50.7335060000', '8950', 'Heuvelland', 5, 0);
INSERT INTO `lokatie` VALUES(1156, 'wervik', '3.0455371000', '50.7796872000', '8940', 'Wervik', 5, 0);
INSERT INTO `lokatie` VALUES(1155, 'geluwe', '3.0772288000', '50.8106434000', '8940', 'Geluwe', 5, 0);
INSERT INTO `lokatie` VALUES(1154, 'rekkem', '3.1622287000', '50.7860124000', '8930', 'Rekkem', 5, 0);
INSERT INTO `lokatie` VALUES(1153, 'menen', '3.1169344000', '50.7966926000', '8930', 'Menen', 5, 0);
INSERT INTO `lokatie` VALUES(1152, 'lauwe', '3.1867307000', '50.7946681000', '8930', 'Lauwe', 5, 0);
INSERT INTO `lokatie` VALUES(1151, 'poelkapelle', '2.9575598000', '50.9183966000', '8920', 'Poelkapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1150, 'langemark-poelkapelle', '2.9235205000', '50.9236776000', '8920', 'Langemark-Poelkapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1149, 'langemark', '2.9235205000', '50.9236776000', '8920', 'Langemark', 5, 0);
INSERT INTO `lokatie` VALUES(1148, 'bikschote', '2.8647833000', '50.9257396000', '8920', 'Bikschote', 5, 0);
INSERT INTO `lokatie` VALUES(1147, 'vlamertinge', '2.8245127000', '50.8479624000', '8908', 'Vlamertinge', 5, 0);
INSERT INTO `lokatie` VALUES(1146, 'elverdinge', '2.8162074000', '50.8848669000', '8906', 'Elverdinge', 5, 0);
INSERT INTO `lokatie` VALUES(1145, 'zuidschote', '2.8283525000', '50.9136603000', '8904', 'Zuidschote', 5, 0);
INSERT INTO `lokatie` VALUES(1144, 'boezinge', '2.8563982000', '50.8958339000', '8904', 'Boezinge', 5, 0);
INSERT INTO `lokatie` VALUES(1143, 'zillebeke', '2.9243234000', '50.8336732000', '8902', 'Zillebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1142, 'voormezele', '2.8757493000', '50.8165377000', '8902', 'Voormezele', 5, 0);
INSERT INTO `lokatie` VALUES(1141, 'hollebeke', '2.9369760000', '50.8053687000', '8902', 'Hollebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1140, 'sint-jan', '2.9044546000', '50.8648940000', '8900', 'Sint-Jan', 5, 0);
INSERT INTO `lokatie` VALUES(1139, 'ieper', '2.8841917000', '50.8512822000', '8900', 'Ieper', 5, 0);
INSERT INTO `lokatie` VALUES(1138, 'dikkebus', '2.8322155000', '50.8198334000', '8900', 'Dikkebus', 5, 0);
INSERT INTO `lokatie` VALUES(1137, 'brielen', '2.8491872000', '50.8676598000', '8900', 'Brielen', 5, 0);
INSERT INTO `lokatie` VALUES(1136, 'moorslede', '3.0624010000', '50.8916615000', '8890', 'Moorslede', 5, 0);
INSERT INTO `lokatie` VALUES(1135, 'dadizele', '3.0947109000', '50.8515914000', '8890', 'Dadizele', 5, 0);
INSERT INTO `lokatie` VALUES(1134, 'sint-eloois-winkel', '3.1787537000', '50.8760936000', '8880', 'Sint-Eloois-Winkel', 5, 0);
INSERT INTO `lokatie` VALUES(1133, 'rollegem-kapelle', '3.1454220000', '50.8683926000', '8880', 'Rollegem-Kapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1132, 'ledegem', '3.1267933000', '50.8528245000', '8880', 'Ledegem', 5, 0);
INSERT INTO `lokatie` VALUES(1131, 'kachtem', '3.1920846000', '50.9316763000', '8870', 'Kachtem', 5, 0);
INSERT INTO `lokatie` VALUES(1130, 'izegem', '3.2150258000', '50.9171066000', '8870', 'Izegem', 5, 0);
INSERT INTO `lokatie` VALUES(1129, 'emelgem', '3.2309409000', '50.9222761000', '8870', 'Emelgem', 5, 0);
INSERT INTO `lokatie` VALUES(1128, 'lendelede', '3.2314593000', '50.8895138000', '8860', 'Lendelede', 5, 0);
INSERT INTO `lokatie` VALUES(1127, 'koolskamp', '3.1956495000', '51.0052491000', '8851', 'Koolskamp', 5, 0);
INSERT INTO `lokatie` VALUES(1126, 'ardooie', '3.1988027000', '50.9790650000', '8850', 'Ardooie', 5, 0);
INSERT INTO `lokatie` VALUES(1125, 'westrozebeke', '3.0118590000', '50.9312734000', '8840', 'Westrozebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1124, 'staden', '3.0147353000', '50.9746248000', '8840', 'Staden', 5, 0);
INSERT INTO `lokatie` VALUES(1123, 'oostnieuwkerke', '3.0596374000', '50.9402935000', '8840', 'Oostnieuwkerke', 5, 0);
INSERT INTO `lokatie` VALUES(1122, 'hooglede', '3.0815457000', '50.9781013000', '8830', 'Hooglede', 5, 0);
INSERT INTO `lokatie` VALUES(1121, 'gits', '3.0955577000', '50.9967536000', '8830', 'Gits', 5, 0);
INSERT INTO `lokatie` VALUES(1120, 'torhout', '3.1009941000', '51.0655436000', '8820', 'Torhout', 5, 0);
INSERT INTO `lokatie` VALUES(1119, 'lichtervelde', '3.1545349000', '51.0220282000', '8810', 'Lichtervelde', 5, 0);
INSERT INTO `lokatie` VALUES(1118, 'rumbeke', '3.1536040000', '50.9333325000', '8800', 'Rumbeke', 5, 0);
INSERT INTO `lokatie` VALUES(1117, 'roeselare', '3.1233724000', '50.9446581000', '8800', 'Roeselare', 5, 0);
INSERT INTO `lokatie` VALUES(1116, 'oekene', '3.1603630000', '50.9203557000', '8800', 'Oekene', 5, 0);
INSERT INTO `lokatie` VALUES(1115, 'beveren-roeselare', '3.1441556000', '50.9686766000', '8800', 'Beveren (Roeselare)', 5, 0);
INSERT INTO `lokatie` VALUES(1114, 'sint-eloois-vijve', '3.3957222000', '50.9031014000', '8793', 'Sint-Eloois-Vijve', 5, 0);
INSERT INTO `lokatie` VALUES(1113, 'desselgem', '3.3659687000', '50.8857190000', '8792', 'Desselgem', 5, 0);
INSERT INTO `lokatie` VALUES(1112, 'beveren-leie', '3.3463890000', '50.8755560000', '8791', 'Beveren (Leie)', 5, 0);
INSERT INTO `lokatie` VALUES(1111, 'waregem', '3.4069354000', '50.8688999000', '8790', 'Waregem', 5, 0);
INSERT INTO `lokatie` VALUES(1110, 'oostrozebeke', '3.3341985000', '50.9283343000', '8780', 'Oostrozebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1109, 'ingelmunster', '3.2650296000', '50.9146433000', '8770', 'Ingelmunster', 5, 0);
INSERT INTO `lokatie` VALUES(1108, 'meulebeke', '3.2943867000', '50.9555417000', '8760', 'Meulebeke', 5, 0);
INSERT INTO `lokatie` VALUES(1107, 'ruiselede', '3.3805077000', '51.0575102000', '8755', 'Ruiselede', 5, 0);
INSERT INTO `lokatie` VALUES(1106, 'zwevezele', '3.2103512000', '51.0362049000', '8750', 'Zwevezele', 5, 0);
INSERT INTO `lokatie` VALUES(1105, 'wingene', '3.2785301000', '51.0579019000', '8750', 'Wingene', 5, 0);
INSERT INTO `lokatie` VALUES(1104, 'pittem', '3.2676415000', '50.9949738000', '8740', 'Pittem', 5, 0);
INSERT INTO `lokatie` VALUES(1103, 'egem', '3.2592667000', '51.0152757000', '8740', 'Egem', 5, 0);
INSERT INTO `lokatie` VALUES(1102, 'sint-joris-beernem', '3.3714256000', '51.1274837000', '8730', 'Sint-Joris (Beernem)', 5, 0);
INSERT INTO `lokatie` VALUES(1101, 'oedelem', '3.3390429000', '51.1694952000', '8730', 'Oedelem', 5, 0);
INSERT INTO `lokatie` VALUES(1100, 'beernem', '3.3407403000', '51.1427610000', '8730', 'Beernem', 5, 0);
INSERT INTO `lokatie` VALUES(1099, 'wakken', '3.3985085000', '50.9302684000', '8720', 'Wakken', 5, 0);
INSERT INTO `lokatie` VALUES(1098, 'oeselgem', '3.4320200000', '50.9349703000', '8720', 'Oeselgem', 5, 0);
INSERT INTO `lokatie` VALUES(1097, 'markegem', '3.4025915000', '50.9459728000', '8720', 'Markegem', 5, 0);
INSERT INTO `lokatie` VALUES(1096, 'dentergem', '3.4194398000', '50.9639098000', '8720', 'Dentergem', 5, 0);
INSERT INTO `lokatie` VALUES(1095, 'wielsbeke', '3.3697673000', '50.9094999000', '8710', 'Wielsbeke', 5, 0);
INSERT INTO `lokatie` VALUES(1094, 'sint-baafs-vijve', '3.3915347000', '50.9097435000', '8710', 'Sint-Baafs-Vijve', 5, 0);
INSERT INTO `lokatie` VALUES(1093, 'ooigem', '3.3367226000', '50.8931563000', '8710', 'Ooigem', 5, 0);
INSERT INTO `lokatie` VALUES(1092, 'tielt', '3.3249677000', '51.0000497000', '8700', 'Tielt', 5, 0);
INSERT INTO `lokatie` VALUES(1091, 'schuiferskapelle', '3.3338141000', '51.0328488000', '8700', 'Schuiferskapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1090, 'kanegem', '3.4026063000', '51.0133525000', '8700', 'Kanegem', 5, 0);
INSERT INTO `lokatie` VALUES(1089, 'aarsele', '3.4221357000', '50.9971866000', '8700', 'Aarsele', 5, 0);
INSERT INTO `lokatie` VALUES(1088, 'stavele', '2.6733606000', '50.9402646000', '8691', 'Stavele', 5, 0);
INSERT INTO `lokatie` VALUES(1087, 'leisele', '2.6225261000', '50.9842964000', '8691', 'Leisele', 5, 0);
INSERT INTO `lokatie` VALUES(1086, 'izenberge', '2.6547301000', '50.9942545000', '8691', 'Izenberge', 5, 0);
INSERT INTO `lokatie` VALUES(1085, 'gijverinkhove', '2.6739310000', '50.9756261000', '8691', 'Gijverinkhove', 5, 0);
INSERT INTO `lokatie` VALUES(1084, 'beveren-aan-den-ijzer', '2.6423354000', '50.9389635000', '8691', 'Beveren-aan-den-Ijzer', 5, 0);
INSERT INTO `lokatie` VALUES(1083, 'sint-rijkers', '2.6906855000', '50.9957244000', '8690', 'Sint-Rijkers', 5, 0);
INSERT INTO `lokatie` VALUES(1082, 'oeren', '2.7052759000', '51.0230302000', '8690', 'Oeren', 5, 0);
INSERT INTO `lokatie` VALUES(1081, 'hoogstade', '2.6932127000', '50.9793365000', '8690', 'Hoogstade', 5, 0);
INSERT INTO `lokatie` VALUES(1080, 'alveringem', '2.7099155000', '51.0114970000', '8690', 'Alveringem', 5, 0);
INSERT INTO `lokatie` VALUES(1079, 'zande', '2.9222626000', '51.1200784000', '8680', 'Zande', 5, 0);
INSERT INTO `lokatie` VALUES(1078, 'koekelare', '2.9803297000', '51.0905055000', '8680', 'Koekelare', 5, 0);
INSERT INTO `lokatie` VALUES(1077, 'bovekerke', '2.9630112000', '51.0538425000', '8680', 'Bovekerke', 5, 0);
INSERT INTO `lokatie` VALUES(1076, 'wulpen', '2.6994096000', '51.1009091000', '8670', 'Wulpen', 5, 0);
INSERT INTO `lokatie` VALUES(1075, 'oostduinkerke', '2.6820111000', '51.1161895000', '8670', 'Oostduinkerke', 5, 0);
INSERT INTO `lokatie` VALUES(1074, 'koksijde', '2.6547930000', '51.1032910000', '8670', 'Koksijde', 5, 0);
INSERT INTO `lokatie` VALUES(1073, 'de-panne', '2.5915813000', '51.1019559000', '8660', 'De Panne', 5, 0);
INSERT INTO `lokatie` VALUES(1072, 'adinkerke', '2.6025470000', '51.0753997000', '8660', 'Adinkerke', 5, 0);
INSERT INTO `lokatie` VALUES(1071, 'merkem', '2.8501241000', '50.9549101000', '8650', 'Merkem', 5, 0);
INSERT INTO `lokatie` VALUES(1070, 'klerken', '2.9075980000', '50.9967029000', '8650', 'Klerken', 5, 0);
INSERT INTO `lokatie` VALUES(1069, 'houthulst', '2.9506920000', '50.9783361000', '8650', 'Houthulst', 5, 0);
INSERT INTO `lokatie` VALUES(1068, 'reninge', '2.7891722000', '50.9477884000', '8647', 'Reninge', 5, 0);
INSERT INTO `lokatie` VALUES(1067, 'pollinkhove', '2.7323192000', '50.9710810000', '8647', 'Pollinkhove', 5, 0);
INSERT INTO `lokatie` VALUES(1066, 'noordschote', '2.8103758000', '50.9545440000', '8647', 'Noordschote', 5, 0);
INSERT INTO `lokatie` VALUES(1065, 'lo-reninge', '2.7818969000', '50.9688486000', '8647', 'Lo-Reninge', 5, 0);
INSERT INTO `lokatie` VALUES(1064, 'lo', '2.7818969000', '50.9688486000', '8647', 'Lo', 5, 0);
INSERT INTO `lokatie` VALUES(1063, 'woesten', '2.7894548000', '50.9000912000', '8640', 'Woesten', 5, 0);
INSERT INTO `lokatie` VALUES(1062, 'westvleteren', '2.7171065000', '50.9275759000', '8640', 'Westvleteren', 5, 0);
INSERT INTO `lokatie` VALUES(1061, 'vleteren', '2.7272379000', '50.9075694000', '8640', 'Vleteren', 5, 0);
INSERT INTO `lokatie` VALUES(1060, 'oostvleteren', '2.7419994000', '50.9342522000', '8640', 'Oostvleteren', 5, 0);
INSERT INTO `lokatie` VALUES(1059, 'zoutenaaie', '2.7490825000', '51.0490643000', '8630', 'Zoutenaaie', 5, 0);
INSERT INTO `lokatie` VALUES(1058, 'wulveringem', '2.6558529000', '51.0159040000', '8630', 'Wulveringem', 5, 0);
INSERT INTO `lokatie` VALUES(1057, 'vinkem', '2.6628311000', '51.0162289000', '8630', 'Vinkem', 5, 0);
INSERT INTO `lokatie` VALUES(1056, 'veurne', '2.6625059000', '51.0726510000', '8630', 'Veurne', 5, 0);
INSERT INTO `lokatie` VALUES(1055, 'steenkerke-west-vlaanderen', '2.6889443000', '51.0575284000', '8630', 'Steenkerke, West-vlaanderen', 5, 0);
INSERT INTO `lokatie` VALUES(1054, 'houtem-west-vlaanderen', '2.6073771000', '51.0120890000', '8630', 'Houtem, West-vlaanderen', 5, 0);
INSERT INTO `lokatie` VALUES(1053, 'eggewaartskapelle', '2.7217623000', '51.0496986000', '8630', 'Eggewaartskapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1052, 'de-moeren', '2.6004986000', '51.0433862000', '8630', 'De Moeren', 5, 0);
INSERT INTO `lokatie` VALUES(1051, 'bulskamp', '2.6501345000', '51.0432467000', '8630', 'Bulskamp', 5, 0);
INSERT INTO `lokatie` VALUES(1050, 'booitshoeke', '2.7440942000', '51.0873534000', '8630', 'Booitshoeke', 5, 0);
INSERT INTO `lokatie` VALUES(1049, 'beauvoorde', '2.6589210000', '51.0186710000', '8630', 'Beauvoorde', 5, 0);
INSERT INTO `lokatie` VALUES(1048, 'avekapelle', '2.7337362000', '51.0659107000', '8630', 'Avekapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1047, 'sint-joris-nieuwpoort', '2.7783875000', '51.1301690000', '8620', 'Sint-Joris (Nieuwpoort)', 5, 0);
INSERT INTO `lokatie` VALUES(1046, 'ramskapelle-nieuwpoort', '2.7619895000', '51.1095560000', '8620', 'Ramskapelle (Nieuwpoort)', 5, 0);
INSERT INTO `lokatie` VALUES(1045, 'nieuwpoort', '2.7500104000', '51.1292820000', '8620', 'Nieuwpoort', 5, 0);
INSERT INTO `lokatie` VALUES(1044, 'zarren', '2.9588138000', '51.0183251000', '8610', 'Zarren', 5, 0);
INSERT INTO `lokatie` VALUES(1043, 'werken', '2.9648399000', '51.0291127000', '8610', 'Werken', 5, 0);
INSERT INTO `lokatie` VALUES(1042, 'kortemark', '3.0443083000', '51.0285539000', '8610', 'Kortemark', 5, 0);
INSERT INTO `lokatie` VALUES(1041, 'handzame', '3.0033770000', '51.0260926000', '8610', 'Handzame', 5, 0);
INSERT INTO `lokatie` VALUES(1040, 'woumen', '2.8696561000', '51.0015912000', '8600', 'Woumen', 5, 0);
INSERT INTO `lokatie` VALUES(1039, 'vladslo', '2.9163847000', '51.0463027000', '8600', 'Vladslo', 5, 0);
INSERT INTO `lokatie` VALUES(1038, 'stuivekenskerke', '2.8250746000', '51.0766973000', '8600', 'Stuivekenskerke', 5, 0);
INSERT INTO `lokatie` VALUES(1037, 'sint-jacobs-kapelle', '2.8337891000', '51.0164901000', '8600', 'Sint-Jacobs-Kapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1036, 'pervijze', '2.7943947000', '51.0733205000', '8600', 'Pervijze', 5, 0);
INSERT INTO `lokatie` VALUES(1035, 'oudekapelle', '2.8080178000', '51.0135263000', '8600', 'Oudekapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1034, 'oostkerke-diksmuide', '2.7964856000', '51.0465083000', '8600', 'Oostkerke (Diksmuide)', 5, 0);
INSERT INTO `lokatie` VALUES(1033, 'nieuwkapelle', '2.7998800000', '50.9993956000', '8600', 'Nieuwkapelle', 5, 0);
INSERT INTO `lokatie` VALUES(1032, 'leke', '2.8909046000', '51.1014829000', '8600', 'Leke', 5, 0);
INSERT INTO `lokatie` VALUES(1031, 'lampernisse', '2.7683533000', '51.0325201000', '8600', 'Lampernisse', 5, 0);
INSERT INTO `lokatie` VALUES(1030, 'keiem', '2.8821894000', '51.0814378000', '8600', 'Keiem', 5, 0);
INSERT INTO `lokatie` VALUES(1029, 'kaaskerke', '2.8367637000', '51.0364146000', '8600', 'Kaaskerke', 5, 0);
INSERT INTO `lokatie` VALUES(1028, 'esen', '2.9021306000', '51.0294638000', '8600', 'Esen', 5, 0);
INSERT INTO `lokatie` VALUES(1027, 'driekapellen', '3.9865752000', '50.7064502000', '8600', 'Driekapellen', 5, 0);
INSERT INTO `lokatie` VALUES(1026, 'diksmuide', '2.8637681000', '51.0317985000', '8600', 'Diksmuide', 5, 0);
INSERT INTO `lokatie` VALUES(1025, 'beerst', '2.8869089000', '51.0588750000', '8600', 'Beerst', 5, 0);
INSERT INTO `lokatie` VALUES(1024, 'spiere-helkijnespierres-helchin', '3.3595085000', '50.7297543000', '8587', 'Spiere-Helkijn/Espierres-Helchin', 5, 0);
INSERT INTO `lokatie` VALUES(1023, 'spiereespierres', '3.3595085000', '50.7297543000', '8587', 'Spiere/Espierres', 5, 0);
INSERT INTO `lokatie` VALUES(1022, 'helkijnhelchin', '3.3832415000', '50.7301453000', '8587', 'Helkijn/Helchin', 5, 0);
INSERT INTO `lokatie` VALUES(1021, 'bossuit', '3.4063396000', '50.7504958000', '8583', 'Bossuit', 5, 0);
INSERT INTO `lokatie` VALUES(1020, 'outrijve', '3.4269519000', '50.7563938000', '8582', 'Outrijve', 5, 0);
INSERT INTO `lokatie` VALUES(1019, 'waarmaarde', '3.4854308000', '50.7908324000', '8581', 'Waarmaarde', 5, 0);
INSERT INTO `lokatie` VALUES(1018, 'kerkhove', '3.5008416000', '50.7982751000', '8581', 'Kerkhove', 5, 0);
INSERT INTO `lokatie` VALUES(1017, 'avelgem', '3.4511795000', '50.7790895000', '8580', 'Avelgem', 5, 0);
INSERT INTO `lokatie` VALUES(1016, 'tiegem', '3.4672437000', '50.8098395000', '8573', 'Tiegem', 5, 0);
INSERT INTO `lokatie` VALUES(1015, 'kaster', '3.4957435000', '50.8167992000', '8572', 'Kaster', 5, 0);
INSERT INTO `lokatie` VALUES(1014, 'vichte', '3.4036119000', '50.8379731000', '8570', 'Vichte', 5, 0);
INSERT INTO `lokatie` VALUES(1013, 'ingooigem', '3.4341932000', '50.8173213000', '8570', 'Ingooigem', 5, 0);
INSERT INTO `lokatie` VALUES(1012, 'gijzelbrechtegem', '3.5058000000', '50.8286179000', '8570', 'Gijzelbrechtegem', 5, 0);
INSERT INTO `lokatie` VALUES(1011, 'anzegem', '3.4787653000', '50.8325599000', '8570', 'Anzegem', 5, 0);
INSERT INTO `lokatie` VALUES(1010, 'wevelgem', '3.1844111000', '50.8090860000', '8560', 'Wevelgem', 5, 0);
INSERT INTO `lokatie` VALUES(1009, 'moorsele', '3.1644616000', '50.8408719000', '8560', 'Moorsele', 5, 0);
INSERT INTO `lokatie` VALUES(1008, 'gullegem', '3.2045802000', '50.8434430000', '8560', 'Gullegem', 5, 0);
INSERT INTO `lokatie` VALUES(1007, 'sint-denijs', '3.3455713000', '50.7665549000', '8554', 'Sint-Denijs', 5, 0);
INSERT INTO `lokatie` VALUES(1006, 'otegem', '3.4210724000', '50.8085977000', '8553', 'Otegem', 5, 0);
INSERT INTO `lokatie` VALUES(1005, 'moen', '3.3888739000', '50.7705085000', '8552', 'Moen', 5, 0);
INSERT INTO `lokatie` VALUES(1004, 'heestert', '3.4035918000', '50.7908923000', '8551', 'Heestert', 5, 0);
INSERT INTO `lokatie` VALUES(1003, 'zwevegem', '3.3505258000', '50.8080392000', '8550', 'Zwevegem', 5, 0);
INSERT INTO `lokatie` VALUES(1002, 'deerlijk', '3.3609825000', '50.8441846000', '8540', 'Deerlijk', 5, 0);
INSERT INTO `lokatie` VALUES(1001, 'hulste', '3.2959678000', '50.8820723000', '8531', 'Hulste', 5, 0);
INSERT INTO `lokatie` VALUES(1000, 'bavikhove', '3.3113744000', '50.8753581000', '8531', 'Bavikhove', 5, 0);
INSERT INTO `lokatie` VALUES(999, 'harelbeke', '3.3121073000', '50.8455798000', '8530', 'Harelbeke', 5, 0);
INSERT INTO `lokatie` VALUES(998, 'kuurne', '3.2766908000', '50.8569946000', '8520', 'Kuurne', 5, 0);
INSERT INTO `lokatie` VALUES(997, 'aalbeke', '3.2183209000', '50.7753313000', '8511', 'Aalbeke', 5, 0);
INSERT INTO `lokatie` VALUES(996, 'rollegem', '3.2629686000', '50.7689400000', '8510', 'Rollegem', 5, 0);
INSERT INTO `lokatie` VALUES(995, 'marke', '3.2329053000', '50.8073310000', '8510', 'Marke', 5, 0);
INSERT INTO `lokatie` VALUES(994, 'kooigem', '3.3312922000', '50.7397278000', '8510', 'Kooigem', 5, 0);
INSERT INTO `lokatie` VALUES(993, 'bellegem', '3.2802084000', '50.7778232000', '8510', 'Bellegem', 5, 0);
INSERT INTO `lokatie` VALUES(992, 'heule', '3.2346591000', '50.8432636000', '8501', 'Heule', 5, 0);
INSERT INTO `lokatie` VALUES(991, 'bissegem', '3.2271207000', '50.8234148000', '8501', 'Bissegem', 5, 0);
INSERT INTO `lokatie` VALUES(990, 'kortrijk', '3.2718398000', '50.8154740000', '8500', 'Kortrijk', 5, 0);
INSERT INTO `lokatie` VALUES(989, 'zerkegem', '3.0704166000', '51.1667726000', '8490', 'Zerkegem', 5, 0);
INSERT INTO `lokatie` VALUES(988, 'varsenare', '3.1422056000', '51.1890772000', '8490', 'Varsenare', 5, 0);
INSERT INTO `lokatie` VALUES(987, 'stalhille', '3.0719024000', '51.2144127000', '8490', 'Stalhille', 5, 0);
INSERT INTO `lokatie` VALUES(986, 'snellegem', '3.1230501000', '51.1692561000', '8490', 'Snellegem', 5, 0);
INSERT INTO `lokatie` VALUES(985, 'jabbeke', '3.0929529000', '51.1824684000', '8490', 'Jabbeke', 5, 0);
INSERT INTO `lokatie` VALUES(984, 'ichtegem', '3.0105053000', '51.0928872000', '8480', 'Ichtegem', 5, 0);
INSERT INTO `lokatie` VALUES(983, 'eernegem', '3.0302782000', '51.1259989000', '8480', 'Eernegem', 5, 0);
INSERT INTO `lokatie` VALUES(982, 'bekegem', '3.0454135000', '51.1595959000', '8480', 'Bekegem', 5, 0);
INSERT INTO `lokatie` VALUES(981, 'zevekote', '2.9199852000', '51.1375440000', '8470', 'Zevekote', 5, 0);
INSERT INTO `lokatie` VALUES(980, 'snaaskerke', '2.9368371000', '51.1743203000', '8470', 'Snaaskerke', 5, 0);
INSERT INTO `lokatie` VALUES(979, 'moere', '2.9559126000', '51.1225918000', '8470', 'Moere', 5, 0);
INSERT INTO `lokatie` VALUES(978, 'gistel', '2.9671999000', '51.1561106000', '8470', 'Gistel', 5, 0);
INSERT INTO `lokatie` VALUES(977, 'westkerke', '3.0156356000', '51.1647255000', '8460', 'Westkerke', 5, 0);
INSERT INTO `lokatie` VALUES(976, 'roksem', '3.0321263000', '51.1705192000', '8460', 'Roksem', 5, 0);
INSERT INTO `lokatie` VALUES(975, 'oudenburg', '3.0047264000', '51.1845166000', '8460', 'Oudenburg', 5, 0);
INSERT INTO `lokatie` VALUES(974, 'ettelgem', '3.0326798000', '51.1787507000', '8460', 'Ettelgem', 5, 0);
INSERT INTO `lokatie` VALUES(973, 'bredene', '2.9809796000', '51.2357846000', '8450', 'Bredene', 5, 0);
INSERT INTO `lokatie` VALUES(972, 'westende', '2.7689403000', '51.1594526000', '8434', 'Westende', 5, 0);
INSERT INTO `lokatie` VALUES(971, 'lombardsijde', '2.7567072000', '51.1485971000', '8434', 'Lombardsijde', 5, 0);
INSERT INTO `lokatie` VALUES(970, 'spermalie', '2.8554611000', '51.1320987000', '8433', 'Spermalie', 5, 0);
INSERT INTO `lokatie` VALUES(969, 'slijpe', '2.8472220000', '51.1553132000', '8433', 'Slijpe', 5, 0);
INSERT INTO `lokatie` VALUES(968, 'sint-pieters-kapelle-west-vlaanderen', '2.8748019000', '51.1266899000', '8433', 'Sint-Pieters-Kapelle, West-vlaanderen', 5, 0);
INSERT INTO `lokatie` VALUES(967, 'schore', '2.8391978000', '51.1118279000', '8433', 'Schore', 5, 0);
INSERT INTO `lokatie` VALUES(966, 'mannekensvere', '2.8180513000', '51.1259734000', '8433', 'Mannekensvere', 5, 0);
INSERT INTO `lokatie` VALUES(965, 'leffinge', '2.8761840000', '51.1755695000', '8432', 'Leffinge', 5, 0);
INSERT INTO `lokatie` VALUES(964, 'wilskerke', '2.8427583000', '51.1790017000', '8431', 'Wilskerke', 5, 0);
INSERT INTO `lokatie` VALUES(963, 'middelkerke', '2.8060231000', '51.1798869000', '8430', 'Middelkerke', 5, 0);
INSERT INTO `lokatie` VALUES(962, 'vlissegem', '3.0638644000', '51.2598471000', '8421', 'Vlissegem', 5, 0);
INSERT INTO `lokatie` VALUES(961, 'wenduine', '3.0825524000', '51.2983120000', '8420', 'Wenduine', 5, 0);
INSERT INTO `lokatie` VALUES(960, 'klemskerke', '3.0242805000', '51.2425843000', '8420', 'Klemskerke', 5, 0);
INSERT INTO `lokatie` VALUES(959, 'de-haan', '3.0353128000', '51.2714128000', '8420', 'De Haan', 5, 0);
INSERT INTO `lokatie` VALUES(958, 'zandvoorde-oostende', '2.9759358000', '51.2007640000', '8400', 'Zandvoorde (Oostende)', 5, 0);
INSERT INTO `lokatie` VALUES(957, 'stene', '2.9307745000', '51.2105793000', '8400', 'Stene', 5, 0);
INSERT INTO `lokatie` VALUES(956, 'oostende', '2.9133725000', '51.2254102000', '8400', 'Oostende', 5, 0);
INSERT INTO `lokatie` VALUES(955, 'zuienkerke', '3.1562560000', '51.2650828000', '8377', 'Zuienkerke', 5, 0);
INSERT INTO `lokatie` VALUES(954, 'nieuwmunster', '3.0983368000', '51.2736897000', '8377', 'Nieuwmunster', 5, 0);
INSERT INTO `lokatie` VALUES(953, 'meetkerke', '3.1519455000', '51.2355310000', '8377', 'Meetkerke', 5, 0);
INSERT INTO `lokatie` VALUES(952, 'houtave', '3.1103331000', '51.2360918000', '8377', 'Houtave', 5, 0);
INSERT INTO `lokatie` VALUES(951, 'uitkerke', '3.1430383000', '51.3036218000', '8370', 'Uitkerke', 5, 0);
INSERT INTO `lokatie` VALUES(950, 'blankenberge', '3.1310489000', '51.3150697000', '8370', 'Blankenberge', 5, 0);
INSERT INTO `lokatie` VALUES(949, 'sijsele', '3.3231555000', '51.2014613000', '8340', 'Sijsele', 5, 0);
INSERT INTO `lokatie` VALUES(948, 'oostkerke-damme', '3.2958858000', '51.2779569000', '8340', 'Oostkerke (Damme)', 5, 0);
INSERT INTO `lokatie` VALUES(947, 'moerkerke', '3.3391618000', '51.2455314000', '8340', 'Moerkerke', 5, 0);
INSERT INTO `lokatie` VALUES(946, 'lapscheure', '3.3567461000', '51.2776741000', '8340', 'Lapscheure', 5, 0);
INSERT INTO `lokatie` VALUES(945, 'hoeke', '3.3302565000', '51.2928100000', '8340', 'Hoeke', 5, 0);
INSERT INTO `lokatie` VALUES(944, 'damme', '3.2812048000', '51.2516269000', '8340', 'Damme', 5, 0);
INSERT INTO `lokatie` VALUES(943, 'ramskapelle-knokke-heist', '3.2508010000', '51.3152279000', '8301', 'Ramskapelle (Knokke-Heist)', 5, 0);
INSERT INTO `lokatie` VALUES(942, 'heist-aan-zee', '3.2353071000', '51.3398001000', '8301', 'Heist-aan-Zee', 5, 0);
INSERT INTO `lokatie` VALUES(941, 'westkapelle', '3.3027081000', '51.3148428000', '8300', 'Westkapelle', 5, 0);
INSERT INTO `lokatie` VALUES(940, 'knokke-heist', '3.3140885000', '51.3317067000', '8300', 'Knokke-Heist', 5, 0);
INSERT INTO `lokatie` VALUES(939, 'knokke', '3.2870421000', '51.3413561000', '8300', 'Knokke', 5, 0);
INSERT INTO `lokatie` VALUES(938, 'aartrijke', '3.0925657000', '51.1282033000', '8211', 'Aartrijke', 5, 0);
INSERT INTO `lokatie` VALUES(937, 'zedelgem', '3.1362114000', '51.1431594000', '8210', 'Zedelgem', 5, 0);
INSERT INTO `lokatie` VALUES(936, 'veldegem', '3.1597427000', '51.1046248000', '8210', 'Veldegem', 5, 0);
INSERT INTO `lokatie` VALUES(935, 'loppem', '3.1958265000', '51.1554495000', '8210', 'Loppem', 5, 0);
INSERT INTO `lokatie` VALUES(934, 'waardamme', '3.2202317000', '51.1117767000', '8020', 'Waardamme', 5, 0);
INSERT INTO `lokatie` VALUES(933, 'ruddervoorde', '3.2056487000', '51.0956112000', '8020', 'Ruddervoorde', 5, 0);
INSERT INTO `lokatie` VALUES(932, 'oostkamp', '3.2351877000', '51.1544358000', '8020', 'Oostkamp', 5, 0);
INSERT INTO `lokatie` VALUES(931, 'hertsberge', '3.2731020000', '51.1053772000', '8020', 'Hertsberge', 5, 0);
INSERT INTO `lokatie` VALUES(930, 'zeebrugge', '3.2068372000', '51.3313458000', '8380', 'Zeebrugge', 5, 0);
INSERT INTO `lokatie` VALUES(929, 'lissewege', '3.1994146000', '51.2948381000', '8380', 'Lissewege', 5, 0);
INSERT INTO `lokatie` VALUES(928, 'dudzele', '3.2276464000', '51.2751509000', '8380', 'Dudzele', 5, 0);
INSERT INTO `lokatie` VALUES(927, 'sint-kruis', '3.2503635000', '51.2139044000', '8310', 'Sint-Kruis', 5, 0);
INSERT INTO `lokatie` VALUES(926, 'assebroek', '3.2537394000', '51.1963627000', '8310', 'Assebroek', 5, 0);
INSERT INTO `lokatie` VALUES(925, 'sint-michiels', '3.2117955000', '51.1885991000', '8200', 'Sint-Michiels', 5, 0);
INSERT INTO `lokatie` VALUES(924, 'sint-andries', '3.1802664000', '51.1971662000', '8200', 'Sint-Andries', 5, 0);
INSERT INTO `lokatie` VALUES(923, 'koolkerke', '3.2497512000', '51.2416655000', '8000', 'Koolkerke', 5, 0);
INSERT INTO `lokatie` VALUES(922, 'brugge', '3.2252302000', '51.2094107000', '8000', 'Brugge', 5, 0);
INSERT INTO `lokatie` VALUES(921, 'waanrode', '4.9926901000', '50.9109915000', '3473', 'Waanrode', 4, 0);
INSERT INTO `lokatie` VALUES(920, 'kersbeek-miskom', '5.0015754000', '50.8897326000', '3472', 'Kersbeek-Miskom', 4, 0);
INSERT INTO `lokatie` VALUES(919, 'hoeleden', '5.0104490000', '50.8684803000', '3471', 'Hoeleden', 4, 0);
INSERT INTO `lokatie` VALUES(918, 'ransberg', '5.0400366000', '50.8751211000', '3470', 'Ransberg', 4, 0);
INSERT INTO `lokatie` VALUES(917, 'kortenaken', '5.0579228000', '50.9097728000', '3470', 'Kortenaken', 4, 0);
INSERT INTO `lokatie` VALUES(916, 'molenbeek-wersbeek', '4.9423469000', '50.9131330000', '3461', 'Molenbeek-Wersbeek', 4, 0);
INSERT INTO `lokatie` VALUES(915, 'bekkevoort', '4.9732786000', '50.9443979000', '3460', 'Bekkevoort', 4, 0);
INSERT INTO `lokatie` VALUES(914, 'assent', '5.0135274000', '50.9521255000', '3460', 'Assent', 4, 0);
INSERT INTO `lokatie` VALUES(913, 'rummen', '5.1546511000', '50.8935133000', '3454', 'Rummen', 4, 0);
INSERT INTO `lokatie` VALUES(912, 'grazen', '5.1260398000', '50.8724455000', '3450', 'Grazen', 4, 0);
INSERT INTO `lokatie` VALUES(911, 'geetbets', '5.1155146000', '50.8899665000', '3450', 'Geetbets', 4, 0);
INSERT INTO `lokatie` VALUES(910, 'zoutleeuw', '5.1036264000', '50.8333864000', '3440', 'Zoutleeuw', 4, 0);
INSERT INTO `lokatie` VALUES(909, 'helen-bos', '5.0838800000', '50.8204541000', '3440', 'Helen-Bos', 4, 0);
INSERT INTO `lokatie` VALUES(908, 'halle-booienhoven', '5.1075836000', '50.8071466000', '3440', 'Halle-Booienhoven', 4, 0);
INSERT INTO `lokatie` VALUES(907, 'dormaal', '5.1012615000', '50.8093853000', '3440', 'Dormaal', 4, 0);
INSERT INTO `lokatie` VALUES(906, 'budingen', '5.1046511000', '50.8638239000', '3440', 'Budingen', 4, 0);
INSERT INTO `lokatie` VALUES(905, 'neerlanden', '5.0791969000', '50.7779680000', '3404', 'Neerlanden', 4, 0);
INSERT INTO `lokatie` VALUES(904, 'attenhoven', '5.0909919000', '50.7680924000', '3404', 'Attenhoven', 4, 0);
INSERT INTO `lokatie` VALUES(903, 'wezeren', '5.1043070000', '50.7288610000', '3401', 'Wezeren', 4, 0);
INSERT INTO `lokatie` VALUES(902, 'walshoutem', '5.0962378000', '50.7235590000', '3401', 'Walshoutem', 4, 0);
INSERT INTO `lokatie` VALUES(901, 'walsbets', '5.0852047000', '50.7372870000', '3401', 'Walsbets', 4, 0);
INSERT INTO `lokatie` VALUES(900, 'waasmont', '5.0636421000', '50.7292593000', '3401', 'Waasmont', 4, 0);
INSERT INTO `lokatie` VALUES(899, 'wange', '5.0304358000', '50.7854969000', '3400', 'Wange', 4, 0);
INSERT INTO `lokatie` VALUES(898, 'rumsdorp', '5.0755183000', '50.7667558000', '3400', 'Rumsdorp', 4, 0);
INSERT INTO `lokatie` VALUES(897, 'overwinden', '5.0493124000', '50.7526876000', '3400', 'Overwinden', 4, 0);
INSERT INTO `lokatie` VALUES(896, 'neerwinden', '5.0376647000', '50.7653309000', '3400', 'Neerwinden', 4, 0);
INSERT INTO `lokatie` VALUES(895, 'landen', '5.0802846000', '50.7559123000', '3400', 'Landen', 4, 0);
INSERT INTO `lokatie` VALUES(894, 'laar', '5.0254942000', '50.7707447000', '3400', 'Laar', 4, 0);
INSERT INTO `lokatie` VALUES(893, 'ezemaal', '5.0002249000', '50.7760826000', '3400', 'Ezemaal', 4, 0);
INSERT INTO `lokatie` VALUES(892, 'eliksem', '5.0104064000', '50.7840465000', '3400', 'Eliksem', 4, 0);
INSERT INTO `lokatie` VALUES(891, 'meensel-kiezegem', '4.9135474000', '50.8934701000', '3391', 'Meensel-Kiezegem', 4, 0);
INSERT INTO `lokatie` VALUES(890, 'tielt-winge', '4.8866603000', '50.9206968000', '3390', 'Tielt-Winge', 4, 0);
INSERT INTO `lokatie` VALUES(889, 'tielt-vlaams-brabant', '4.8866603000', '50.9206968000', '3390', 'Tielt, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(888, 'sint-joris-winge', '4.8767046000', '50.9077520000', '3390', 'Sint-Joris-Winge', 4, 0);
INSERT INTO `lokatie` VALUES(887, 'houwaart', '4.8612641000', '50.9344333000', '3390', 'Houwaart', 4, 0);
INSERT INTO `lokatie` VALUES(886, 'attenrode', '4.9188741000', '50.8697661000', '3384', 'Attenrode', 4, 0);
INSERT INTO `lokatie` VALUES(885, 'kapellen-vlaams-brabant', '4.9638352000', '50.8913432000', '3381', 'Kapellen, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(884, 'glabbeek-zuurbemde', '4.9484411000', '50.8729951000', '3380', 'Glabbeek-Zuurbemde', 4, 0);
INSERT INTO `lokatie` VALUES(883, 'bunsbeek', '4.9443147000', '50.8424919000', '3380', 'Bunsbeek', 4, 0);
INSERT INTO `lokatie` VALUES(882, 'willebringen', '4.8398264000', '50.8115033000', '3370', 'Willebringen', 4, 0);
INSERT INTO `lokatie` VALUES(881, 'vertrijk', '4.8346263000', '50.8297021000', '3370', 'Vertrijk', 4, 0);
INSERT INTO `lokatie` VALUES(880, 'roosbeek', '4.8620278000', '50.8338371000', '3370', 'Roosbeek', 4, 0);
INSERT INTO `lokatie` VALUES(879, 'neervelp', '4.8103239000', '50.8198597000', '3370', 'Neervelp', 4, 0);
INSERT INTO `lokatie` VALUES(878, 'kerkom', '4.8710787000', '50.8533968000', '3370', 'Kerkom', 4, 0);
INSERT INTO `lokatie` VALUES(877, 'boutersem', '4.8318525000', '50.8395164000', '3370', 'Boutersem', 4, 0);
INSERT INTO `lokatie` VALUES(876, 'opvelp', '4.7949493000', '50.8083432000', '3360', 'Opvelp', 4, 0);
INSERT INTO `lokatie` VALUES(875, 'lovenjoel', '4.7826072000', '50.8531552000', '3360', 'Lovenjoel', 4, 0);
INSERT INTO `lokatie` VALUES(874, 'korbeek-lo', '4.7627193000', '50.8599823000', '3360', 'Korbeek-Lo', 4, 0);
INSERT INTO `lokatie` VALUES(873, 'bierbeek', '4.7591436000', '50.8278959000', '3360', 'Bierbeek', 4, 0);
INSERT INTO `lokatie` VALUES(872, 'wommersom', '5.0179563000', '50.8135172000', '3350', 'Wommersom', 4, 0);
INSERT INTO `lokatie` VALUES(871, 'overhespen', '5.0393276000', '50.7949557000', '3350', 'Overhespen', 4, 0);
INSERT INTO `lokatie` VALUES(870, 'orsmaal-gussenhoven', '5.0564368000', '50.8027589000', '3350', 'Orsmaal-Gussenhoven', 4, 0);
INSERT INTO `lokatie` VALUES(869, 'neerlinter', '5.0196164000', '50.8389076000', '3350', 'Neerlinter', 4, 0);
INSERT INTO `lokatie` VALUES(868, 'neerhespen', '5.0529507000', '50.7943798000', '3350', 'Neerhespen', 4, 0);
INSERT INTO `lokatie` VALUES(867, 'melkwezer', '5.0583908000', '50.8222825000', '3350', 'Melkwezer', 4, 0);
INSERT INTO `lokatie` VALUES(866, 'linter', '5.0479412000', '50.8303555000', '3350', 'Linter', 4, 0);
INSERT INTO `lokatie` VALUES(865, 'drieslinter', '5.0477264000', '50.8450967000', '3350', 'Drieslinter', 4, 0);
INSERT INTO `lokatie` VALUES(864, 'outgaarden', '4.9275167000', '50.7573406000', '3321', 'Outgaarden', 4, 0);
INSERT INTO `lokatie` VALUES(863, 'meldert-vlaams-brabant', '4.8378587000', '50.7880084000', '3320', 'Meldert, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(862, 'hoegaarden', '4.8875986000', '50.7733257000', '3320', 'Hoegaarden', 4, 0);
INSERT INTO `lokatie` VALUES(861, 'vissenaken', '4.9105742000', '50.8355202000', '3300', 'Vissenaken', 4, 0);
INSERT INTO `lokatie` VALUES(860, 'tienen', '4.9394348000', '50.8056024000', '3300', 'Tienen', 4, 0);
INSERT INTO `lokatie` VALUES(859, 'sint-margriete-houtem-tienen', '4.9561235000', '50.8285325000', '3300', 'Sint-Margriete-Houtem (Tienen)', 4, 0);
INSERT INTO `lokatie` VALUES(858, 'oplinter', '4.9897399000', '50.8291685000', '3300', 'Oplinter', 4, 0);
INSERT INTO `lokatie` VALUES(857, 'oorbeek', '4.8905356000', '50.7986421000', '3300', 'Oorbeek', 4, 0);
INSERT INTO `lokatie` VALUES(856, 'kumtich', '4.8864289000', '50.8179933000', '3300', 'Kumtich', 4, 0);
INSERT INTO `lokatie` VALUES(855, 'hakendover', '4.9814621000', '50.7940157000', '3300', 'Hakendover', 4, 0);
INSERT INTO `lokatie` VALUES(854, 'goetsenhoven', '4.9511786000', '50.7678215000', '3300', 'Goetsenhoven', 4, 0);
INSERT INTO `lokatie` VALUES(853, 'bost', '4.9408001000', '50.7898457000', '3300', 'Bost', 4, 0);
INSERT INTO `lokatie` VALUES(852, 'molenstede', '5.0346516000', '51.0032297000', '3294', 'Molenstede', 4, 0);
INSERT INTO `lokatie` VALUES(851, 'kaggevinne', '5.0309157000', '50.9824809000', '3293', 'Kaggevinne', 4, 0);
INSERT INTO `lokatie` VALUES(850, 'webbekom', '5.0712370000', '50.9728720000', '3290', 'Webbekom', 4, 0);
INSERT INTO `lokatie` VALUES(849, 'schaffen', '5.0819803000', '51.0003282000', '3290', 'Schaffen', 4, 0);
INSERT INTO `lokatie` VALUES(848, 'diest', '5.0505022000', '50.9846460000', '3290', 'Diest', 4, 0);
INSERT INTO `lokatie` VALUES(847, 'deurne-vlaams-brabant', '5.0956050000', '51.0386199000', '3290', 'Deurne, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(846, 'testelt', '4.9518674000', '51.0087082000', '3272', 'Testelt', 4, 0);
INSERT INTO `lokatie` VALUES(845, 'messelbroek', '4.9374406000', '50.9957571000', '3272', 'Messelbroek', 4, 0);
INSERT INTO `lokatie` VALUES(844, 'zichem', '4.9841232000', '51.0053958000', '3271', 'Zichem', 4, 0);
INSERT INTO `lokatie` VALUES(843, 'averbode', '4.9806859000', '51.0261822000', '3271', 'Averbode', 4, 0);
INSERT INTO `lokatie` VALUES(842, 'scherpenheuvel-zichem', '4.9785767000', '50.9742707000', '3270', 'Scherpenheuvel-Zichem', 4, 0);
INSERT INTO `lokatie` VALUES(841, 'scherpenheuvel', '4.9785767000', '50.9742707000', '3270', 'Scherpenheuvel', 4, 0);
INSERT INTO `lokatie` VALUES(840, 'nieuwrode', '4.8345841000', '50.9489726000', '3221', 'Nieuwrode', 4, 0);
INSERT INTO `lokatie` VALUES(839, 'sint-pieters-rode', '4.8202103000', '50.9323592000', '3220', 'Sint-Pieters-Rode', 4, 0);
INSERT INTO `lokatie` VALUES(838, 'kortrijk-dutsel', '4.8067775000', '50.9256501000', '3220', 'Kortrijk-Dutsel', 4, 0);
INSERT INTO `lokatie` VALUES(837, 'holsbeek', '4.7561019000', '50.9209367000', '3220', 'Holsbeek', 4, 0);
INSERT INTO `lokatie` VALUES(836, 'pellenberg', '4.7844449000', '50.8779602000', '3212', 'Pellenberg', 4, 0);
INSERT INTO `lokatie` VALUES(835, 'binkom', '4.8973531000', '50.8732792000', '3211', 'Binkom', 4, 0);
INSERT INTO `lokatie` VALUES(834, 'lubbeek', '4.8413284000', '50.8815304000', '3210', 'Lubbeek', 4, 0);
INSERT INTO `lokatie` VALUES(833, 'linden', '4.7679070000', '50.8955361000', '3210', 'Linden', 4, 0);
INSERT INTO `lokatie` VALUES(832, 'rillaar', '4.8903385000', '50.9779972000', '3202', 'Rillaar', 4, 0);
INSERT INTO `lokatie` VALUES(831, 'langdorp', '4.8957877000', '51.0091297000', '3201', 'Langdorp', 4, 0);
INSERT INTO `lokatie` VALUES(830, 'gelrode', '4.8028445000', '50.9655370000', '3200', 'Gelrode', 4, 0);
INSERT INTO `lokatie` VALUES(829, 'aarschot', '4.8317896000', '50.9849236000', '3200', 'Aarschot', 4, 0);
INSERT INTO `lokatie` VALUES(828, 'hever', '4.5368456000', '50.9818048000', '3191', 'Hever', 4, 0);
INSERT INTO `lokatie` VALUES(827, 'boortmeerbeek', '4.5744373000', '50.9803397000', '3190', 'Boortmeerbeek', 4, 0);
INSERT INTO `lokatie` VALUES(826, 'wespelaar', '4.6330236000', '50.9590836000', '3150', 'Wespelaar', 4, 0);
INSERT INTO `lokatie` VALUES(825, 'tildonk', '4.6446919000', '50.9435682000', '3150', 'Tildonk', 4, 0);
INSERT INTO `lokatie` VALUES(824, 'haacht', '4.6384322000', '50.9771772000', '3150', 'Haacht', 4, 0);
INSERT INTO `lokatie` VALUES(823, 'keerbergen', '4.6548667000', '51.0085174000', '3140', 'Keerbergen', 4, 0);
INSERT INTO `lokatie` VALUES(822, 'betekom', '4.7817066000', '50.9849813000', '3130', 'Betekom', 4, 0);
INSERT INTO `lokatie` VALUES(821, 'begijnendijk', '4.7825200000', '51.0189748000', '3130', 'Begijnendijk', 4, 0);
INSERT INTO `lokatie` VALUES(820, 'baal', '4.7428591000', '51.0049803000', '3128', 'Baal', 4, 0);
INSERT INTO `lokatie` VALUES(819, 'tremelo', '4.7159551000', '50.9956159000', '3120', 'Tremelo', 4, 0);
INSERT INTO `lokatie` VALUES(818, 'werchter', '4.7124551000', '50.9748563000', '3118', 'Werchter', 4, 0);
INSERT INTO `lokatie` VALUES(817, 'wezemaal', '4.7717425000', '50.9515561000', '3111', 'Wezemaal', 4, 0);
INSERT INTO `lokatie` VALUES(816, 'rotselaar', '4.7215113000', '50.9535967000', '3110', 'Rotselaar', 4, 0);
INSERT INTO `lokatie` VALUES(815, 'overijse', '4.5336216000', '50.7681029000', '3090', 'Overijse', 4, 0);
INSERT INTO `lokatie` VALUES(814, 'vossem', '4.5576270000', '50.8346073000', '3080', 'Vossem', 4, 0);
INSERT INTO `lokatie` VALUES(813, 'tervuren', '4.5141045000', '50.8245321000', '3080', 'Tervuren', 4, 0);
INSERT INTO `lokatie` VALUES(812, 'duisburg', '4.5522760000', '50.8159388000', '3080', 'Duisburg', 4, 0);
INSERT INTO `lokatie` VALUES(811, 'meerbeek', '4.5854940000', '50.8821891000', '3078', 'Meerbeek', 4, 0);
INSERT INTO `lokatie` VALUES(810, 'everberg', '4.5703840000', '50.8781978000', '3078', 'Everberg', 4, 0);
INSERT INTO `lokatie` VALUES(809, 'erps-kwerps', '4.5733837000', '50.8968496000', '3071', 'Erps-Kwerps', 4, 0);
INSERT INTO `lokatie` VALUES(808, 'kortenberg', '4.5369170000', '50.8852298000', '3070', 'Kortenberg', 4, 0);
INSERT INTO `lokatie` VALUES(807, 'leefdaal', '4.5898822000', '50.8440508000', '3061', 'Leefdaal', 4, 0);
INSERT INTO `lokatie` VALUES(806, 'korbeek-dijle', '4.6410354000', '50.8398285000', '3060', 'Korbeek-Dijle', 4, 0);
INSERT INTO `lokatie` VALUES(805, 'bertem', '4.6292288000', '50.8627275000', '3060', 'Bertem', 4, 0);
INSERT INTO `lokatie` VALUES(804, 'vaalbeek', '4.6898969000', '50.8218329000', '3054', 'Vaalbeek', 4, 0);
INSERT INTO `lokatie` VALUES(803, 'haasrode', '4.6970956000', '50.8085156000', '3053', 'Haasrode', 4, 0);
INSERT INTO `lokatie` VALUES(802, 'blanden', '4.7095095000', '50.8262552000', '3052', 'Blanden', 4, 0);
INSERT INTO `lokatie` VALUES(801, 'sint-joris-weert', '4.6489898000', '50.8026261000', '3051', 'Sint-Joris-Weert', 4, 0);
INSERT INTO `lokatie` VALUES(800, 'oud-heverlee', '4.6595340000', '50.8282606000', '3050', 'Oud-Heverlee', 4, 0);
INSERT INTO `lokatie` VALUES(799, 'sint-agatha-rode', '4.6336929000', '50.7869501000', '3040', 'Sint-Agatha-Rode', 4, 0);
INSERT INTO `lokatie` VALUES(798, 'ottenburg', '4.6153339000', '50.7527894000', '3040', 'Ottenburg', 4, 0);
INSERT INTO `lokatie` VALUES(797, 'neerijse', '4.6253697000', '50.8174155000', '3040', 'Neerijse', 4, 0);
INSERT INTO `lokatie` VALUES(796, 'loonbeek', '4.6069926000', '50.8074398000', '3040', 'Loonbeek', 4, 0);
INSERT INTO `lokatie` VALUES(795, 'huldenberg', '4.5831760000', '50.7892516000', '3040', 'Huldenberg', 4, 0);
INSERT INTO `lokatie` VALUES(794, 'winksele', '4.6434699000', '50.8974963000', '3020', 'Winksele', 4, 0);
INSERT INTO `lokatie` VALUES(793, 'veltem-beisem', '4.6225868000', '50.9013146000', '3020', 'Veltem-Beisem', 4, 0);
INSERT INTO `lokatie` VALUES(792, 'herent', '4.6737711000', '50.9069232000', '3020', 'Herent', 4, 0);
INSERT INTO `lokatie` VALUES(791, 'wijgmaal-vlaams-brabant', '4.6929276000', '50.9338612000', '3018', 'Wijgmaal, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(790, 'wilsele', '4.7019807000', '50.9126170000', '3012', 'Wilsele', 4, 0);
INSERT INTO `lokatie` VALUES(789, 'kessel-lo', '4.7223376000', '50.8839668000', '3010', 'Kessel-Lo', 4, 0);
INSERT INTO `lokatie` VALUES(788, 'heverlee', '4.6935744000', '50.8644065000', '3001', 'Heverlee', 4, 0);
INSERT INTO `lokatie` VALUES(787, 'leuven', '4.6967578000', '50.8815197000', '3000', 'Leuven', 4, 0);
INSERT INTO `lokatie` VALUES(786, 'weerde', '4.4796055000', '50.9719460000', '1982', 'Weerde', 4, 0);
INSERT INTO `lokatie` VALUES(785, 'elewijt', '4.4969878000', '50.9601434000', '1982', 'Elewijt', 4, 0);
INSERT INTO `lokatie` VALUES(784, 'hofstade-vlaams-brabant', '4.5009462000', '50.9936415000', '1981', 'Hofstade, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(783, 'zemst', '4.4647125000', '50.9840679000', '1980', 'Zemst', 4, 0);
INSERT INTO `lokatie` VALUES(782, 'eppegem', '4.4558663000', '50.9618149000', '1980', 'Eppegem', 4, 0);
INSERT INTO `lokatie` VALUES(781, 'wezembeek-oppem', '4.4901061000', '50.8479299000', '1970', 'Wezembeek-Oppem', 4, 0);
INSERT INTO `lokatie` VALUES(780, 'kraainem', '4.4687138000', '50.8513570000', '1950', 'Kraainem', 4, 0);
INSERT INTO `lokatie` VALUES(779, 'sterrebeek', '4.5167076000', '50.8573308000', '1933', 'Sterrebeek', 4, 0);
INSERT INTO `lokatie` VALUES(778, 'sint-stevens-woluwe', '4.4435639000', '50.8705648000', '1932', 'Sint-Stevens-Woluwe', 4, 0);
INSERT INTO `lokatie` VALUES(777, 'zaventem', '4.4701262000', '50.8876870000', '1930', 'Zaventem', 4, 0);
INSERT INTO `lokatie` VALUES(776, 'nossegem', '4.5042210000', '50.8792372000', '1930', 'Nossegem', 4, 0);
INSERT INTO `lokatie` VALUES(775, 'nederokkerzeel', '4.5642589000', '50.9187704000', '1910', 'Nederokkerzeel', 4, 0);
INSERT INTO `lokatie` VALUES(774, 'kampenhout', '4.5491512000', '50.9419562000', '1910', 'Kampenhout', 4, 0);
INSERT INTO `lokatie` VALUES(773, 'buken', '4.6174406000', '50.9373175000', '1910', 'Buken', 4, 0);
INSERT INTO `lokatie` VALUES(772, 'berg-vlaams-brabant', '4.5410062000', '50.9308826000', '1910', 'Berg, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(771, 'ramsdonk', '4.3352389000', '51.0149429000', '1880', 'Ramsdonk', 4, 0);
INSERT INTO `lokatie` VALUES(770, 'nieuwenrode', '4.3502589000', '50.9794577000', '1880', 'Nieuwenrode', 4, 0);
INSERT INTO `lokatie` VALUES(769, 'kapelle-op-den-bos', '4.3595258000', '51.0137057000', '1880', 'Kapelle-op-den-Bos', 4, 0);
INSERT INTO `lokatie` VALUES(768, 'wolvertem', '4.3085432000', '50.9695502000', '1861', 'Wolvertem', 4, 0);
INSERT INTO `lokatie` VALUES(767, 'meise', '4.3302827000', '50.9478621000', '1860', 'Meise', 4, 0);
INSERT INTO `lokatie` VALUES(766, 'strombeek-bever', '4.3398332000', '50.9083671000', '1853', 'Strombeek-Bever', 4, 0);
INSERT INTO `lokatie` VALUES(765, 'beigem', '4.3658006000', '50.9543719000', '1852', 'Beigem', 4, 0);
INSERT INTO `lokatie` VALUES(764, 'humbeek', '4.3834362000', '50.9667658000', '1851', 'Humbeek', 4, 0);
INSERT INTO `lokatie` VALUES(763, 'grimbergen', '4.3785596000', '50.9356235000', '1850', 'Grimbergen', 4, 0);
INSERT INTO `lokatie` VALUES(762, 'steenhuffel', '4.2673407000', '50.9958290000', '1840', 'Steenhuffel', 4, 0);
INSERT INTO `lokatie` VALUES(761, 'malderen', '4.2428427000', '51.0201013000', '1840', 'Malderen', 4, 0);
INSERT INTO `lokatie` VALUES(760, 'londerzeel', '4.3018641000', '51.0019953000', '1840', 'Londerzeel', 4, 0);
INSERT INTO `lokatie` VALUES(759, 'diegem', '4.4468571000', '50.8913010000', '1831', 'Diegem', 4, 0);
INSERT INTO `lokatie` VALUES(758, 'machelen-vlaams-brabant', '4.4376749000', '50.9125185000', '1830', 'Machelen, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(757, 'steenokkerzeel', '4.5126955000', '50.9102555000', '1820', 'Steenokkerzeel', 4, 0);
INSERT INTO `lokatie` VALUES(756, 'perk', '4.4968360000', '50.9330705000', '1820', 'Perk', 4, 0);
INSERT INTO `lokatie` VALUES(755, 'melsbroek', '4.4753219000', '50.9164121000', '1820', 'Melsbroek', 4, 0);
INSERT INTO `lokatie` VALUES(754, 'vilvoorde', '4.4605278000', '50.9377435000', '1800', 'Vilvoorde', 4, 0);
INSERT INTO `lokatie` VALUES(753, 'peutie', '4.4541935000', '50.9283542000', '1800', 'Peutie', 4, 0);
INSERT INTO `lokatie` VALUES(752, 'teralfene', '4.0987534000', '50.8923363000', '1790', 'Teralfene', 4, 0);
INSERT INTO `lokatie` VALUES(751, 'hekelgem', '4.1131729000', '50.9167932000', '1790', 'Hekelgem', 4, 0);
INSERT INTO `lokatie` VALUES(750, 'essene', '4.1369031000', '50.9018055000', '1790', 'Essene', 4, 0);
INSERT INTO `lokatie` VALUES(749, 'affligem', '4.1109971000', '50.9036003000', '1790', 'Affligem', 4, 0);
INSERT INTO `lokatie` VALUES(748, 'merchtem', '4.2328109000', '50.9595203000', '1785', 'Merchtem', 4, 0);
INSERT INTO `lokatie` VALUES(747, 'hamme-vlaams-brabant', '4.2769163000', '50.9140646000', '1785', 'Hamme, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(746, 'brussegem', '4.2671999000', '50.9276965000', '1785', 'Brussegem', 4, 0);
INSERT INTO `lokatie` VALUES(745, 'wemmel', '4.3114128000', '50.9068107000', '1780', 'Wemmel', 4, 0);
INSERT INTO `lokatie` VALUES(744, 'liedekerke', '4.0925208000', '50.8625365000', '1770', 'Liedekerke', 4, 0);
INSERT INTO `lokatie` VALUES(743, 'borchtlombeek', '4.1184892000', '50.8485944000', '1761', 'Borchtlombeek', 4, 0);
INSERT INTO `lokatie` VALUES(742, 'strijtem', '4.1169317000', '50.8412140000', '1760', 'Strijtem', 4, 0);
INSERT INTO `lokatie` VALUES(741, 'roosdaal', '4.0826909000', '50.8383581000', '1760', 'Roosdaal', 4, 0);
INSERT INTO `lokatie` VALUES(740, 'pamel', '4.0685616000', '50.8457745000', '1760', 'Pamel', 4, 0);
INSERT INTO `lokatie` VALUES(739, 'onze-lieve-vrouw-lombeek', '4.1136280000', '50.8224850000', '1760', 'Onze-Lieve-Vrouw-Lombeek', 4, 0);
INSERT INTO `lokatie` VALUES(738, 'oetingen', '4.0632523000', '50.7735310000', '1755', 'Oetingen', 4, 0);
INSERT INTO `lokatie` VALUES(737, 'leerbeek', '4.1180308000', '50.7754445000', '1755', 'Leerbeek', 4, 0);
INSERT INTO `lokatie` VALUES(736, 'kester', '4.1194650000', '50.7642320000', '1755', 'Kester', 4, 0);
INSERT INTO `lokatie` VALUES(735, 'gooik', '4.1172748000', '50.7953447000', '1755', 'Gooik', 4, 0);
INSERT INTO `lokatie` VALUES(734, 'sint-martens-lennik', '4.1671969000', '50.8119264000', '1750', 'Sint-Martens-Lennik', 4, 0);
INSERT INTO `lokatie` VALUES(733, 'sint-kwintens-lennik', '4.1538281000', '50.8068661000', '1750', 'Sint-Kwintens-Lennik', 4, 0);
INSERT INTO `lokatie` VALUES(732, 'lennik', '4.1645967000', '50.8026788000', '1750', 'Lennik', 4, 0);
INSERT INTO `lokatie` VALUES(731, 'gaasbeek', '4.1892067000', '50.7998534000', '1750', 'Gaasbeek', 4, 0);
INSERT INTO `lokatie` VALUES(730, 'opwijk', '4.1892269000', '50.9699176000', '1745', 'Opwijk', 4, 0);
INSERT INTO `lokatie` VALUES(729, 'mazenzele', '4.1715804000', '50.9429436000', '1745', 'Mazenzele', 4, 0);
INSERT INTO `lokatie` VALUES(728, 'sint-katherina-lombeek', '4.1347029000', '50.8740836000', '1742', 'Sint-Katherina-Lombeek', 4, 0);
INSERT INTO `lokatie` VALUES(727, 'wambeek', '4.1653390000', '50.8495390000', '1741', 'Wambeek', 4, 0);
INSERT INTO `lokatie` VALUES(726, 'ternat', '4.1808317000', '50.8698353000', '1740', 'Ternat', 4, 0);
INSERT INTO `lokatie` VALUES(725, 'zellik', '4.2629726000', '50.8865782000', '1731', 'Zellik', 4, 0);
INSERT INTO `lokatie` VALUES(724, 'relegem', '4.2805587000', '50.9003279000', '1731', 'Relegem', 4, 0);
INSERT INTO `lokatie` VALUES(723, 'mollem', '4.2270056000', '50.9306745000', '1730', 'Mollem', 4, 0);
INSERT INTO `lokatie` VALUES(722, 'kobbegem', '4.2498054000', '50.9102913000', '1730', 'Kobbegem', 4, 0);
INSERT INTO `lokatie` VALUES(721, 'bekkerzeel', '4.2382690000', '50.8852034000', '1730', 'Bekkerzeel', 4, 0);
INSERT INTO `lokatie` VALUES(720, 'asse', '4.2000248000', '50.9105738000', '1730', 'Asse', 4, 0);
INSERT INTO `lokatie` VALUES(719, 'schepdaal', '4.2009828000', '50.8378402000', '1703', 'Schepdaal', 4, 0);
INSERT INTO `lokatie` VALUES(718, 'groot-bijgaarden', '4.2658227000', '50.8745835000', '1702', 'Groot-Bijgaarden', 4, 0);
INSERT INTO `lokatie` VALUES(717, 'itterbeek', '4.2346965000', '50.8340174000', '1701', 'Itterbeek', 4, 0);
INSERT INTO `lokatie` VALUES(716, 'sint-ulriks-kapelle', '4.2184309000', '50.8801350000', '1700', 'Sint-Ulriks-Kapelle', 4, 0);
INSERT INTO `lokatie` VALUES(715, 'sint-martens-bodegem', '4.2130151000', '50.8613825000', '1700', 'Sint-Martens-Bodegem', 4, 0);
INSERT INTO `lokatie` VALUES(714, 'dilbeek', '4.2640309000', '50.8451023000', '1700', 'Dilbeek', 4, 0);
INSERT INTO `lokatie` VALUES(713, 'bellingen', '4.1560061000', '50.7461998000', '1674', 'Bellingen', 4, 0);
INSERT INTO `lokatie` VALUES(712, 'beert', '4.1881823000', '50.7315700000', '1673', 'Beert', 4, 0);
INSERT INTO `lokatie` VALUES(711, 'elingen', '4.1765936000', '50.7788199000', '1671', 'Elingen', 4, 0);
INSERT INTO `lokatie` VALUES(710, 'pepingen', '4.1603060000', '50.7592853000', '1670', 'Pepingen', 4, 0);
INSERT INTO `lokatie` VALUES(709, 'heikruis', '4.1123959000', '50.7346720000', '1670', 'Heikruis', 4, 0);
INSERT INTO `lokatie` VALUES(708, 'bogaarden', '4.1352487000', '50.7397102000', '1670', 'Bogaarden', 4, 0);
INSERT INTO `lokatie` VALUES(707, 'huizingen', '4.2716795000', '50.7493554000', '1654', 'Huizingen', 4, 0);
INSERT INTO `lokatie` VALUES(706, 'dworp', '4.2967570000', '50.7302243000', '1653', 'Dworp', 4, 0);
INSERT INTO `lokatie` VALUES(705, 'alsemberg', '4.3274016000', '50.7473028000', '1652', 'Alsemberg', 4, 0);
INSERT INTO `lokatie` VALUES(704, 'lot', '4.2783289000', '50.7725332000', '1651', 'Lot', 4, 0);
INSERT INTO `lokatie` VALUES(703, 'beersel', '4.3120069000', '50.7686913000', '1650', 'Beersel', 4, 0);
INSERT INTO `lokatie` VALUES(702, 'sint-genesius-roderhode-saint-gense', '4.3812856000', '50.7530988000', '1640', 'Sint-Genesius-Rode/Rhode-Saint-Genèse', 4, 0);
INSERT INTO `lokatie` VALUES(701, 'linkebeek', '4.3429983000', '50.7675424000', '1630', 'Linkebeek', 4, 0);
INSERT INTO `lokatie` VALUES(700, 'drogenbos', '4.3080416000', '50.7935688000', '1620', 'Drogenbos', 4, 0);
INSERT INTO `lokatie` VALUES(699, 'vlezenbeek', '4.2334883000', '50.8054095000', '1602', 'Vlezenbeek', 4, 0);
INSERT INTO `lokatie` VALUES(698, 'ruisbroek-vlaams-brabant', '4.2958001000', '50.7849073000', '1601', 'Ruisbroek, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(697, 'sint-pieters-leeuw', '4.2428756000', '50.7792646000', '1600', 'Sint-Pieters-Leeuw', 4, 0);
INSERT INTO `lokatie` VALUES(696, 'sint-laureins-berchem', '4.1981622000', '50.7877669000', '1600', 'Sint-Laureins-Berchem', 4, 0);
INSERT INTO `lokatie` VALUES(695, 'oudenaken', '4.1979164000', '50.7805147000', '1600', 'Oudenaken', 4, 0);
INSERT INTO `lokatie` VALUES(694, 'vollezele', '4.0252292000', '50.7607833000', '1570', 'Vollezele', 4, 0);
INSERT INTO `lokatie` VALUES(693, 'tollembeek', '4.0071016000', '50.7409753000', '1570', 'Tollembeek', 4, 0);
INSERT INTO `lokatie` VALUES(692, 'galmaarden', '3.9704745000', '50.7526951000', '1570', 'Galmaarden', 4, 0);
INSERT INTO `lokatie` VALUES(691, 'hoeilaart', '4.4519958000', '50.7660388000', '1560', 'Hoeilaart', 4, 0);
INSERT INTO `lokatie` VALUES(690, 'beverbivne', '3.9276615000', '50.7068251000', '1547', 'Bever/Biévène', 4, 0);
INSERT INTO `lokatie` VALUES(689, 'sint-pieters-kapelle-vlaams-brabant', '3.9822484000', '50.6997768000', '1541', 'Sint-Pieters-Kapelle, Vlaams Brabant', 4, 0);
INSERT INTO `lokatie` VALUES(688, 'herne', '4.0285990000', '50.7246705000', '1540', 'Herne', 4, 0);
INSERT INTO `lokatie` VALUES(687, 'herfelingen', '4.0964426000', '50.7477667000', '1540', 'Herfelingen', 4, 0);
INSERT INTO `lokatie` VALUES(686, 'lembeek', '4.2425767000', '50.7010009000', '1502', 'Lembeek', 4, 0);
INSERT INTO `lokatie` VALUES(685, 'buizingen', '4.2639160000', '50.7392326000', '1501', 'Buizingen', 4, 0);
INSERT INTO `lokatie` VALUES(684, 'halle', '4.2349129000', '50.7324848000', '1500', 'Halle', 4, 0);
INSERT INTO `lokatie` VALUES(683, 'middelburg', '3.4101213000', '51.2502880000', '9992', 'Middelburg', 3, 0);
INSERT INTO `lokatie` VALUES(682, 'adegem', '3.4947081000', '51.1796950000', '9991', 'Adegem', 3, 0);
INSERT INTO `lokatie` VALUES(681, 'maldegem', '3.4340688000', '51.1919604000', '9990', 'Maldegem', 3, 0);
INSERT INTO `lokatie` VALUES(680, 'watervliet', '3.6272977000', '51.2759057000', '9988', 'Watervliet', 3, 0);
INSERT INTO `lokatie` VALUES(679, 'waterland-oudeman', '3.5886689000', '51.2876471000', '9988', 'Waterland-Oudeman', 3, 0);
INSERT INTO `lokatie` VALUES(678, 'sint-jan-in-eremo', '3.5853302000', '51.2555440000', '9982', 'Sint-Jan-in-Eremo', 3, 0);
INSERT INTO `lokatie` VALUES(677, 'sint-margriete', '3.5382307000', '51.2779475000', '9981', 'Sint-Margriete', 3, 0);
INSERT INTO `lokatie` VALUES(676, 'sint-laureins', '3.5329424000', '51.2361689000', '9980', 'Sint-Laureins', 3, 0);
INSERT INTO `lokatie` VALUES(675, 'lembeke', '3.6462946000', '51.1960228000', '9971', 'Lembeke', 3, 0);
INSERT INTO `lokatie` VALUES(674, 'kaprijke', '3.6186057000', '51.2230750000', '9970', 'Kaprijke', 3, 0);
INSERT INTO `lokatie` VALUES(673, 'oosteeklo', '3.6891624000', '51.1927282000', '9968', 'Oosteeklo', 3, 0);
INSERT INTO `lokatie` VALUES(672, 'bassevelde', '3.6775360000', '51.2304077000', '9968', 'Bassevelde', 3, 0);
INSERT INTO `lokatie` VALUES(671, 'boekhoute', '3.7098678000', '51.2516687000', '9961', 'Boekhoute', 3, 0);
INSERT INTO `lokatie` VALUES(670, 'assenede', '3.7514109000', '51.2346207000', '9960', 'Assenede', 3, 0);
INSERT INTO `lokatie` VALUES(669, 'waarschoot', '3.6160382000', '51.1550724000', '9950', 'Waarschoot', 3, 0);
INSERT INTO `lokatie` VALUES(668, 'sleidinge', '3.6791137000', '51.1327336000', '9940', 'Sleidinge', 3, 0);
INSERT INTO `lokatie` VALUES(667, 'kluizen', '3.7327716000', '51.1554007000', '9940', 'Kluizen', 3, 0);
INSERT INTO `lokatie` VALUES(666, 'evergem', '3.7077912000', '51.1090012000', '9940', 'Evergem', 3, 0);
INSERT INTO `lokatie` VALUES(665, 'ertvelde', '3.7468513000', '51.1788350000', '9940', 'Ertvelde', 3, 0);
INSERT INTO `lokatie` VALUES(664, 'ronsele', '3.5479614000', '51.1336044000', '9932', 'Ronsele', 3, 0);
INSERT INTO `lokatie` VALUES(663, 'oostwinkel', '3.5471801000', '51.1519438000', '9931', 'Oostwinkel', 3, 0);
INSERT INTO `lokatie` VALUES(662, 'zomergem', '3.5611179000', '51.1148946000', '9930', 'Zomergem', 3, 0);
INSERT INTO `lokatie` VALUES(661, 'vinderhoute', '3.6416711000', '51.0888821000', '9921', 'Vinderhoute', 3, 0);
INSERT INTO `lokatie` VALUES(660, 'lovendegem', '3.6285575000', '51.1075935000', '9920', 'Lovendegem', 3, 0);
INSERT INTO `lokatie` VALUES(659, 'ursel', '3.4849708000', '51.1304042000', '9910', 'Ursel', 3, 0);
INSERT INTO `lokatie` VALUES(658, 'knesselare', '3.4127770000', '51.1388097000', '9910', 'Knesselare', 3, 0);
INSERT INTO `lokatie` VALUES(657, 'eeklo', '3.5717618000', '51.1983185000', '9900', 'Eeklo', 3, 0);
INSERT INTO `lokatie` VALUES(656, 'vurste', '3.6839190000', '50.9450941000', '9890', 'Vurste', 3, 0);
INSERT INTO `lokatie` VALUES(655, 'semmerzake', '3.6629464000', '50.9427108000', '9890', 'Semmerzake', 3, 0);
INSERT INTO `lokatie` VALUES(654, 'gavere', '3.6616759000', '50.9285720000', '9890', 'Gavere', 3, 0);
INSERT INTO `lokatie` VALUES(653, 'dikkelvenne', '3.6904016000', '50.9180369000', '9890', 'Dikkelvenne', 3, 0);
INSERT INTO `lokatie` VALUES(652, 'baaigem', '3.7182708000', '50.9332379000', '9890', 'Baaigem', 3, 0);
INSERT INTO `lokatie` VALUES(651, 'asper', '3.6520854000', '50.9129157000', '9890', 'Asper', 3, 0);
INSERT INTO `lokatie` VALUES(650, 'bellem', '3.5021788000', '51.0905235000', '9881', 'Bellem', 3, 0);
INSERT INTO `lokatie` VALUES(649, 'poeke', '3.4436216000', '51.0410256000', '9880', 'Poeke', 3, 0);
INSERT INTO `lokatie` VALUES(648, 'lotenhulle', '3.4601211000', '51.0498769000', '9880', 'Lotenhulle', 3, 0);
INSERT INTO `lokatie` VALUES(647, 'aalter', '3.4484195000', '51.0838283000', '9880', 'Aalter', 3, 0);
INSERT INTO `lokatie` VALUES(646, 'zulte', '3.4437357000', '50.9224968000', '9870', 'Zulte', 3, 0);
INSERT INTO `lokatie` VALUES(645, 'olsene', '3.4657655000', '50.9363732000', '9870', 'Olsene', 3, 0);
INSERT INTO `lokatie` VALUES(644, 'machelen-oost-vlaanderen', '3.4854524000', '50.9608139000', '9870', 'Machelen, Oost-vlaanderen', 3, 0);
INSERT INTO `lokatie` VALUES(643, 'scheldewindeke', '3.7846025000', '50.9372636000', '9860', 'Scheldewindeke', 3, 0);
INSERT INTO `lokatie` VALUES(642, 'oosterzele', '3.8040530000', '50.9461577000', '9860', 'Oosterzele', 3, 0);
INSERT INTO `lokatie` VALUES(641, 'moortsele', '3.7797136000', '50.9590284000', '9860', 'Moortsele', 3, 0);
INSERT INTO `lokatie` VALUES(640, 'landskouter', '3.7928938000', '50.9683766000', '9860', 'Landskouter', 3, 0);
INSERT INTO `lokatie` VALUES(639, 'gijzenzele', '3.8153997000', '50.9705594000', '9860', 'Gijzenzele', 3, 0);
INSERT INTO `lokatie` VALUES(638, 'balegem', '3.7905005000', '50.9257977000', '9860', 'Balegem', 3, 0);
INSERT INTO `lokatie` VALUES(637, 'vosselare', '3.5549275000', '51.0265232000', '9850', 'Vosselare', 3, 0);
INSERT INTO `lokatie` VALUES(636, 'poesele', '3.5162472000', '51.0338276000', '9850', 'Poesele', 3, 0);
INSERT INTO `lokatie` VALUES(635, 'nevele', '3.5490817000', '51.0327759000', '9850', 'Nevele', 3, 0);
INSERT INTO `lokatie` VALUES(634, 'merendree', '3.5770320000', '51.0779834000', '9850', 'Merendree', 3, 0);
INSERT INTO `lokatie` VALUES(633, 'landegem', '3.5730450000', '51.0566021000', '9850', 'Landegem', 3, 0);
INSERT INTO `lokatie` VALUES(632, 'hansbeke', '3.5356724000', '51.0746606000', '9850', 'Hansbeke', 3, 0);
INSERT INTO `lokatie` VALUES(631, 'zevergem', '3.6949960000', '50.9784782000', '9840', 'Zevergem', 3, 0);
INSERT INTO `lokatie` VALUES(630, 'de-pinte', '3.6500052000', '50.9916976000', '9840', 'De Pinte', 3, 0);
INSERT INTO `lokatie` VALUES(629, 'deurle', '3.6137347000', '50.9930841000', '9831', 'Deurle', 3, 0);
INSERT INTO `lokatie` VALUES(628, 'sint-martens-latem', '3.6287716000', '51.0135066000', '9830', 'Sint-Martens-Latem', 3, 0);
INSERT INTO `lokatie` VALUES(627, 'schelderode', '3.7153372000', '50.9714693000', '9820', 'Schelderode', 3, 0);
INSERT INTO `lokatie` VALUES(626, 'munte', '3.7440973000', '50.9450039000', '9820', 'Munte', 3, 0);
INSERT INTO `lokatie` VALUES(625, 'merelbeke', '3.7456646000', '50.9947532000', '9820', 'Merelbeke', 3, 0);
INSERT INTO `lokatie` VALUES(624, 'melsen', '3.6944363000', '50.9567238000', '9820', 'Melsen', 3, 0);
INSERT INTO `lokatie` VALUES(623, 'lemberge', '3.7724529000', '50.9781560000', '9820', 'Lemberge', 3, 0);
INSERT INTO `lokatie` VALUES(622, 'bottelare', '3.7550284000', '50.9631355000', '9820', 'Bottelare', 3, 0);
INSERT INTO `lokatie` VALUES(621, 'nazareth', '3.5958790000', '50.9596094000', '9810', 'Nazareth', 3, 0);
INSERT INTO `lokatie` VALUES(620, 'eke', '3.6416624000', '50.9569440000', '9810', 'Eke', 3, 0);
INSERT INTO `lokatie` VALUES(619, 'zeveren', '3.5026094000', '50.9963697000', '9800', 'Zeveren', 3, 0);
INSERT INTO `lokatie` VALUES(618, 'wontergem', '3.4445403000', '50.9793231000', '9800', 'Wontergem', 3, 0);
INSERT INTO `lokatie` VALUES(617, 'vinkt', '3.4786464000', '51.0079883000', '9800', 'Vinkt', 3, 0);
INSERT INTO `lokatie` VALUES(616, 'sint-martens-leerne', '3.5839409000', '51.0136324000', '9800', 'Sint-Martens-Leerne', 3, 0);
INSERT INTO `lokatie` VALUES(615, 'petegem-aan-de-leie', '3.5290687000', '50.9733374000', '9800', 'Petegem-aan-de-Leie', 3, 0);
INSERT INTO `lokatie` VALUES(614, 'meigem', '3.5399660000', '51.0171279000', '9800', 'Meigem', 3, 0);
INSERT INTO `lokatie` VALUES(613, 'grammene', '3.4719723000', '50.9763184000', '9800', 'Grammene', 3, 0);
INSERT INTO `lokatie` VALUES(612, 'gottem', '3.4634533000', '50.9640663000', '9800', 'Gottem', 3, 0);
INSERT INTO `lokatie` VALUES(611, 'deinze', '3.5273256000', '50.9834245000', '9800', 'Deinze', 3, 0);
INSERT INTO `lokatie` VALUES(610, 'bachte-maria-leerne', '3.5797195000', '51.0098505000', '9800', 'Bachte-Maria-Leerne', 3, 0);
INSERT INTO `lokatie` VALUES(609, 'astene', '3.5606184000', '50.9836390000', '9800', 'Astene', 3, 0);
INSERT INTO `lokatie` VALUES(608, 'wortegem-petegem', '3.5268826000', '50.8445045000', '9790', 'Wortegem-Petegem', 3, 0);
INSERT INTO `lokatie` VALUES(607, 'wortegem', '3.5268826000', '50.8445045000', '9790', 'Wortegem', 3, 0);
INSERT INTO `lokatie` VALUES(606, 'petegem-aan-de-schelde', '3.5561271000', '50.8335013000', '9790', 'Petegem-aan-de-Schelde', 3, 0);
INSERT INTO `lokatie` VALUES(605, 'ooike-wortegem-petegem', '3.5517704000', '50.8705398000', '9790', 'Ooike (Wortegem-Petegem)', 3, 0);
INSERT INTO `lokatie` VALUES(604, 'moregem', '3.5613268000', '50.8503998000', '9790', 'Moregem', 3, 0);
INSERT INTO `lokatie` VALUES(603, 'elsegem', '3.5363403000', '50.8241264000', '9790', 'Elsegem', 3, 0);
INSERT INTO `lokatie` VALUES(602, 'wannegem-lede', '3.5511916000', '50.8906636000', '9772', 'Wannegem-Lede', 3, 0);
INSERT INTO `lokatie` VALUES(601, 'nokere', '3.5106345000', '50.8850002000', '9771', 'Nokere', 3, 0);
INSERT INTO `lokatie` VALUES(600, 'kruishoutem', '3.5280497000', '50.9045975000', '9770', 'Kruishoutem', 3, 0);
INSERT INTO `lokatie` VALUES(599, 'zingem', '3.6536746000', '50.9043275000', '9750', 'Zingem', 3, 0);
INSERT INTO `lokatie` VALUES(598, 'ouwegem', '3.5970625000', '50.9119041000', '9750', 'Ouwegem', 3, 0);
INSERT INTO `lokatie` VALUES(597, 'huise', '3.5895643000', '50.8993294000', '9750', 'Huise', 3, 0);
INSERT INTO `lokatie` VALUES(596, 'welden', '3.6556838000', '50.8783410000', '9700', 'Welden', 3, 0);
INSERT INTO `lokatie` VALUES(595, 'volkegem', '3.6433685000', '50.8389144000', '9700', 'Volkegem', 3, 0);
INSERT INTO `lokatie` VALUES(594, 'oudenaarde', '3.6040386000', '50.8426579000', '9700', 'Oudenaarde', 3, 0);
INSERT INTO `lokatie` VALUES(593, 'nederename', '3.6421497000', '50.8658152000', '9700', 'Nederename', 3, 0);
INSERT INTO `lokatie` VALUES(592, 'mullem', '3.6031472000', '50.8961300000', '9700', 'Mullem', 3, 0);
INSERT INTO `lokatie` VALUES(591, 'melden', '3.5660453000', '50.8145459000', '9700', 'Melden', 3, 0);
INSERT INTO `lokatie` VALUES(590, 'mater', '3.6628418000', '50.8424154000', '9700', 'Mater', 3, 0);
INSERT INTO `lokatie` VALUES(589, 'leupegem', '3.6046624000', '50.8335727000', '9700', 'Leupegem', 3, 0);
INSERT INTO `lokatie` VALUES(588, 'heurne', '3.6280121000', '50.8830180000', '9700', 'Heurne', 3, 0);
INSERT INTO `lokatie` VALUES(587, 'ename', '3.6329067000', '50.8551221000', '9700', 'Ename', 3, 0);
INSERT INTO `lokatie` VALUES(586, 'eine', '3.6212629000', '50.8683423000', '9700', 'Eine', 3, 0);
INSERT INTO `lokatie` VALUES(585, 'edelare', '3.6189075000', '50.8367915000', '9700', 'Edelare', 3, 0);
INSERT INTO `lokatie` VALUES(584, 'bevere', '3.5956607000', '50.8512601000', '9700', 'Bevere', 3, 0);
INSERT INTO `lokatie` VALUES(583, 'zulzeke', '3.5707987000', '50.7892445000', '9690', 'Zulzeke', 3, 0);
INSERT INTO `lokatie` VALUES(582, 'ruien', '3.4862393000', '50.7734676000', '9690', 'Ruien', 3, 0);
INSERT INTO `lokatie` VALUES(581, 'kluisbergen', '3.5190588000', '50.7822677000', '9690', 'Kluisbergen', 3, 0);
INSERT INTO `lokatie` VALUES(580, 'berchem-oost-vlaanderen', '3.5092074000', '50.7907585000', '9690', 'Berchem, Oost-vlaanderen', 3, 0);
INSERT INTO `lokatie` VALUES(579, 'schorisse', '3.6864648000', '50.7927173000', '9688', 'Schorisse', 3, 0);
INSERT INTO `lokatie` VALUES(578, 'nukerke', '3.5992870000', '50.7850270000', '9681', 'Nukerke', 3, 0);
INSERT INTO `lokatie` VALUES(577, 'maarke-kerkem', '3.6531226000', '50.8160688000', '9680', 'Maarke-Kerkem', 3, 0);
INSERT INTO `lokatie` VALUES(576, 'maarkedal', '3.6387412000', '50.8046243000', '9680', 'Maarkedal', 3, 0);
INSERT INTO `lokatie` VALUES(575, 'etikhove', '3.6266142000', '50.8126810000', '9680', 'Etikhove', 3, 0);
INSERT INTO `lokatie` VALUES(574, 'sint-maria-horebeke', '3.6882333000', '50.8379558000', '9667', 'Sint-Maria-Horebeke', 3, 0);
INSERT INTO `lokatie` VALUES(573, 'sint-kornelis-horebeke', '3.6969433000', '50.8350358000', '9667', 'Sint-Kornelis-Horebeke', 3, 0);
INSERT INTO `lokatie` VALUES(572, 'horebeke', '3.6919261000', '50.8341983000', '9667', 'Horebeke', 3, 0);
INSERT INTO `lokatie` VALUES(571, 'parike', '3.7997368000', '50.7864850000', '9661', 'Parike', 3, 0);
INSERT INTO `lokatie` VALUES(570, 'zegelsem', '3.7175589000', '50.8200850000', '9660', 'Zegelsem', 3, 0);
INSERT INTO `lokatie` VALUES(569, 'sint-maria-oudenhove-brakel', '3.7800461000', '50.8235684000', '9660', 'Sint-Maria-Oudenhove (Brakel)', 3, 0);
INSERT INTO `lokatie` VALUES(568, 'opbrakel', '3.7477094000', '50.7924251000', '9660', 'Opbrakel', 3, 0);
INSERT INTO `lokatie` VALUES(567, 'nederbrakel', '3.7647525000', '50.8034464000', '9660', 'Nederbrakel', 3, 0);
INSERT INTO `lokatie` VALUES(566, 'michelbeke', '3.7633803000', '50.8327877000', '9660', 'Michelbeke', 3, 0);
INSERT INTO `lokatie` VALUES(565, 'everbeek', '3.8088105000', '50.7636952000', '9660', 'Everbeek', 3, 0);
INSERT INTO `lokatie` VALUES(564, 'elst', '3.7391608000', '50.8298985000', '9660', 'Elst', 3, 0);
INSERT INTO `lokatie` VALUES(563, 'brakel', '3.7424070000', '50.7961437000', '9660', 'Brakel', 3, 0);
INSERT INTO `lokatie` VALUES(562, 'nederzwalm-hermelgem', '3.6898792000', '50.8889747000', '9636', 'Nederzwalm-Hermelgem', 3, 0);
INSERT INTO `lokatie` VALUES(561, 'zwalm', '3.7288705000', '50.8799184000', '9630', 'Zwalm', 3, 0);
INSERT INTO `lokatie` VALUES(560, 'sint-maria-latem', '3.7069321000', '50.8900899000', '9630', 'Sint-Maria-Latem', 3, 0);
INSERT INTO `lokatie` VALUES(559, 'sint-denijs-boekel', '3.7117508000', '50.8659117000', '9630', 'Sint-Denijs-Boekel', 3, 0);
INSERT INTO `lokatie` VALUES(558, 'sint-blasius-boekel', '3.7193540000', '50.8516381000', '9630', 'Sint-Blasius-Boekel', 3, 0);
INSERT INTO `lokatie` VALUES(557, 'rozebeke', '3.7528295000', '50.8498027000', '9630', 'Rozebeke', 3, 0);
INSERT INTO `lokatie` VALUES(556, 'roborst', '3.7527929000', '50.8658812000', '9630', 'Roborst', 3, 0);
INSERT INTO `lokatie` VALUES(555, 'paulatem', '3.7157668000', '50.8961968000', '9630', 'Paulatem', 3, 0);
INSERT INTO `lokatie` VALUES(554, 'munkzwalm', '3.7335839000', '50.8756709000', '9630', 'Munkzwalm', 3, 0);
INSERT INTO `lokatie` VALUES(553, 'meilegem', '3.6989155000', '50.9048968000', '9630', 'Meilegem', 3, 0);
INSERT INTO `lokatie` VALUES(552, 'hundelgem', '3.7521099000', '50.8886712000', '9630', 'Hundelgem', 3, 0);
INSERT INTO `lokatie` VALUES(551, 'dikkele', '3.7404909000', '50.9055402000', '9630', 'Dikkele', 3, 0);
INSERT INTO `lokatie` VALUES(550, 'beerlegem', '3.7166764000', '50.9059045000', '9630', 'Beerlegem', 3, 0);
INSERT INTO `lokatie` VALUES(549, 'zottegem', '3.8110792000', '50.8694029000', '9620', 'Zottegem', 3, 0);
INSERT INTO `lokatie` VALUES(548, 'velzeke-ruddershove', '3.7828118000', '50.8828278000', '9620', 'Velzeke-Ruddershove', 3, 0);
INSERT INTO `lokatie` VALUES(547, 'strijpen', '3.7875919000', '50.8683615000', '9620', 'Strijpen', 3, 0);
INSERT INTO `lokatie` VALUES(546, 'sint-maria-oudenhove-zottegem', '3.7961960000', '50.8333337000', '9620', 'Sint-Maria-Oudenhove (Zottegem)', 3, 0);
INSERT INTO `lokatie` VALUES(545, 'sint-goriks-oudenhove', '3.7869077000', '50.8528835000', '9620', 'Sint-Goriks-Oudenhove', 3, 0);
INSERT INTO `lokatie` VALUES(544, 'oombergen-zottegem', '3.8316151000', '50.8997008000', '9620', 'Oombergen (Zottegem)', 3, 0);
INSERT INTO `lokatie` VALUES(543, 'leeuwergem', '3.8302794000', '50.8881831000', '9620', 'Leeuwergem', 3, 0);
INSERT INTO `lokatie` VALUES(542, 'grotenberge', '3.8319480000', '50.8725420000', '9620', 'Grotenberge', 3, 0);
INSERT INTO `lokatie` VALUES(541, 'godveerdegem', '3.8213395000', '50.8595533000', '9620', 'Godveerdegem', 3, 0);
INSERT INTO `lokatie` VALUES(540, 'erwetegem', '3.8148231000', '50.8552937000', '9620', 'Erwetegem', 3, 0);
INSERT INTO `lokatie` VALUES(539, 'elene', '3.8100201000', '50.8889694000', '9620', 'Elene', 3, 0);
INSERT INTO `lokatie` VALUES(538, 'kwaremont', '3.5239886000', '50.7760131000', '9690', 'Kwaremont', 3, 0);
INSERT INTO `lokatie` VALUES(537, 'ronserenaix', '3.6075352000', '50.7535563000', '9600', 'Ronse/Renaix', 3, 0);
INSERT INTO `lokatie` VALUES(536, 'sint-martens-lierde', '3.8141474000', '50.8016319000', '9572', 'Sint-Martens-Lierde', 3, 0);
INSERT INTO `lokatie` VALUES(535, 'hemelveerdegem', '3.8648083000', '50.8103800000', '9571', 'Hemelveerdegem', 3, 0);
INSERT INTO `lokatie` VALUES(534, 'sint-maria-lierde', '3.8477682000', '50.8209744000', '9570', 'Sint-Maria-Lierde', 3, 0);
INSERT INTO `lokatie` VALUES(533, 'lierde', '3.8381658000', '50.8190695000', '9570', 'Lierde', 3, 0);
INSERT INTO `lokatie` VALUES(532, 'deftinge', '3.8415470000', '50.7857415000', '9570', 'Deftinge', 3, 0);
INSERT INTO `lokatie` VALUES(531, 'borsbeke', '3.8907942000', '50.9085303000', '9552', 'Borsbeke', 3, 0);
INSERT INTO `lokatie` VALUES(530, 'ressegem', '3.9133478000', '50.8921334000', '9551', 'Ressegem', 3, 0);
INSERT INTO `lokatie` VALUES(529, 'woubrechtegem', '3.9161022000', '50.8727269000', '9550', 'Woubrechtegem', 3, 0);
INSERT INTO `lokatie` VALUES(528, 'steenhuize-wijnhuize', '3.8887461000', '50.8396028000', '9550', 'Steenhuize-Wijnhuize', 3, 0);
INSERT INTO `lokatie` VALUES(527, 'sint-lievens-esse', '3.8857050000', '50.8570748000', '9550', 'Sint-Lievens-Esse', 3, 0);
INSERT INTO `lokatie` VALUES(526, 'sint-antelinks', '3.9256575000', '50.8490467000', '9550', 'Sint-Antelinks', 3, 0);
INSERT INTO `lokatie` VALUES(525, 'hillegem', '3.8534597000', '50.8953626000', '9550', 'Hillegem', 3, 0);
INSERT INTO `lokatie` VALUES(524, 'herzele', '3.8913622000', '50.8876170000', '9550', 'Herzele', 3, 0);
INSERT INTO `lokatie` VALUES(523, 'letterhoutem', '3.8815967000', '50.9270146000', '9521', 'Letterhoutem', 3, 0);
INSERT INTO `lokatie` VALUES(522, 'zonnegem', '3.9085342000', '50.9266557000', '9520', 'Zonnegem', 3, 0);
INSERT INTO `lokatie` VALUES(521, 'vlierzele', '3.8955451000', '50.9315385000', '9520', 'Vlierzele', 3, 0);
INSERT INTO `lokatie` VALUES(520, 'sint-lievens-houtem', '3.8590514000', '50.9205873000', '9520', 'Sint-Lievens-Houtem', 3, 0);
INSERT INTO `lokatie` VALUES(519, 'bavegem', '3.8656597000', '50.9443131000', '9520', 'Bavegem', 3, 0);
INSERT INTO `lokatie` VALUES(518, 'zandbergen', '3.9663706000', '50.8026722000', '9506', 'Zandbergen', 3, 0);
INSERT INTO `lokatie` VALUES(517, 'waarbeke', '3.9687726000', '50.7782844000', '9506', 'Waarbeke', 3, 0);
INSERT INTO `lokatie` VALUES(516, 'smeerebbe-vloerzegem', '3.9283472000', '50.8165834000', '9506', 'Smeerebbe-Vloerzegem', 3, 0);
INSERT INTO `lokatie` VALUES(515, 'schendelbeke', '3.8993276000', '50.7967517000', '9506', 'Schendelbeke', 3, 0);
INSERT INTO `lokatie` VALUES(514, 'nieuwenhove', '3.9893924000', '50.7878967000', '9506', 'Nieuwenhove', 3, 0);
INSERT INTO `lokatie` VALUES(513, 'idegem', '3.9265906000', '50.8005132000', '9506', 'Idegem', 3, 0);
INSERT INTO `lokatie` VALUES(512, 'grimminge', '3.9513918000', '50.7950325000', '9506', 'Grimminge', 3, 0);
INSERT INTO `lokatie` VALUES(511, 'zarlardinge', '3.8283689000', '50.7620698000', '9500', 'Zarlardinge', 3, 0);
INSERT INTO `lokatie` VALUES(510, 'viane', '3.9296036000', '50.7428487000', '9500', 'Viane', 3, 0);
INSERT INTO `lokatie` VALUES(509, 'overboelare', '3.8633465000', '50.7624157000', '9500', 'Overboelare', 3, 0);
INSERT INTO `lokatie` VALUES(508, 'ophasselt', '3.8946782000', '50.8215335000', '9500', 'Ophasselt', 3, 0);
INSERT INTO `lokatie` VALUES(507, 'onkerzele', '3.9114740000', '50.7825783000', '9500', 'Onkerzele', 3, 0);
INSERT INTO `lokatie` VALUES(506, 'nederboelare', '3.8743229000', '50.7813128000', '9500', 'Nederboelare', 3, 0);
INSERT INTO `lokatie` VALUES(505, 'moerbeke', '3.9191972000', '50.7535590000', '9500', 'Moerbeke', 3, 0);
INSERT INTO `lokatie` VALUES(504, 'goeferdinge', '3.8386367000', '50.7652132000', '9500', 'Goeferdinge', 3, 0);
INSERT INTO `lokatie` VALUES(503, 'geraardsbergen', '3.8822942000', '50.7715305000', '9500', 'Geraardsbergen', 3, 0);
INSERT INTO `lokatie` VALUES(502, 'welle', '4.0509649000', '50.8978735000', '9473', 'Welle', 3, 0);
INSERT INTO `lokatie` VALUES(501, 'iddergem', '4.0410235000', '50.8721478000', '9472', 'Iddergem', 3, 0);
INSERT INTO `lokatie` VALUES(500, 'denderleeuw', '4.0707683000', '50.8841490000', '9470', 'Denderleeuw', 3, 0);
INSERT INTO `lokatie` VALUES(499, 'kerksken', '3.9806314000', '50.8846472000', '9451', 'Kerksken', 3, 0);
INSERT INTO `lokatie` VALUES(498, 'heldergem', '3.9542280000', '50.8816761000', '9450', 'Heldergem', 3, 0);
INSERT INTO `lokatie` VALUES(497, 'haaltert', '4.0051119000', '50.9021286000', '9450', 'Haaltert', 3, 0);
INSERT INTO `lokatie` VALUES(496, 'denderhoutem', '4.0182873000', '50.8714348000', '9450', 'Denderhoutem', 3, 0);
INSERT INTO `lokatie` VALUES(495, 'vlekkem', '3.9309339000', '50.9360467000', '9420', 'Vlekkem', 3, 0);
INSERT INTO `lokatie` VALUES(494, 'ottergem', '3.9468348000', '50.9341459000', '9420', 'Ottergem', 3, 0);
INSERT INTO `lokatie` VALUES(493, 'mere', '3.9712962000', '50.9228106000', '9420', 'Mere', 3, 0);
INSERT INTO `lokatie` VALUES(492, 'erpe-mere', '3.9597695000', '50.9349049000', '9420', 'Erpe-Mere', 3, 0);
INSERT INTO `lokatie` VALUES(491, 'erpe', '3.9597695000', '50.9349049000', '9420', 'Erpe', 3, 0);
INSERT INTO `lokatie` VALUES(490, 'erondegem', '3.9555138000', '50.9408113000', '9420', 'Erondegem', 3, 0);
INSERT INTO `lokatie` VALUES(489, 'burst', '3.9203848000', '50.9134641000', '9420', 'Burst', 3, 0);
INSERT INTO `lokatie` VALUES(488, 'bambrugge', '3.9287768000', '50.9198308000', '9420', 'Bambrugge', 3, 0);
INSERT INTO `lokatie` VALUES(487, 'aaigem', '3.9372439000', '50.8890998000', '9420', 'Aaigem', 3, 0);
INSERT INTO `lokatie` VALUES(486, 'outer', '3.9905509000', '50.8452183000', '9406', 'Outer', 3, 0);
INSERT INTO `lokatie` VALUES(485, 'aspelare', '3.9438609000', '50.8441986000', '9404', 'Aspelare', 3, 0);
INSERT INTO `lokatie` VALUES(484, 'neigem', '4.0604615000', '50.8024403000', '9403', 'Neigem', 3, 0);
INSERT INTO `lokatie` VALUES(483, 'meerbeke', '4.0493717000', '50.8223555000', '9402', 'Meerbeke', 3, 0);
INSERT INTO `lokatie` VALUES(482, 'pollare', '4.0080991000', '50.8159663000', '9401', 'Pollare', 3, 0);
INSERT INTO `lokatie` VALUES(481, 'voorde', '3.9486939000', '50.8231194000', '9400', 'Voorde', 3, 0);
INSERT INTO `lokatie` VALUES(480, 'okegem', '4.0553964000', '50.8556112000', '9400', 'Okegem', 3, 0);
INSERT INTO `lokatie` VALUES(479, 'ninove', '4.0208395000', '50.8376326000', '9400', 'Ninove', 3, 0);
INSERT INTO `lokatie` VALUES(478, 'nederhasselt', '3.9746563000', '50.8467663000', '9400', 'Nederhasselt', 3, 0);
INSERT INTO `lokatie` VALUES(477, 'lieferinge', '4.0527646000', '50.7919675000', '9400', 'Lieferinge', 3, 0);
INSERT INTO `lokatie` VALUES(476, 'denderwindeke', '4.0248327000', '50.7981729000', '9400', 'Denderwindeke', 3, 0);
INSERT INTO `lokatie` VALUES(475, 'appelterre-eichem', '3.9669945000', '50.8189401000', '9400', 'Appelterre-Eichem', 3, 0);
INSERT INTO `lokatie` VALUES(474, 'wanzele', '3.9556819000', '50.9740325000', '9340', 'Wanzele', 3, 0);
INSERT INTO `lokatie` VALUES(473, 'smetlede', '3.9271623000', '50.9662674000', '9340', 'Smetlede', 3, 0);
INSERT INTO `lokatie` VALUES(472, 'oordegem', '3.9023149000', '50.9572222000', '9340', 'Oordegem', 3, 0);
INSERT INTO `lokatie` VALUES(471, 'lede', '3.9774265000', '50.9658856000', '9340', 'Lede', 3, 0);
INSERT INTO `lokatie` VALUES(470, 'impe', '3.9523856000', '50.9601891000', '9340', 'Impe', 3, 0);
INSERT INTO `lokatie` VALUES(469, 'nieuwerkerken', '4.0048799000', '50.9234186000', '9320', 'Nieuwerkerken', 3, 0);
INSERT INTO `lokatie` VALUES(468, 'erembodegem', '4.0561475000', '50.9196823000', '9320', 'Erembodegem', 3, 0);
INSERT INTO `lokatie` VALUES(467, 'moorsel', '4.0990898000', '50.9474764000', '9310', 'Moorsel', 3, 0);
INSERT INTO `lokatie` VALUES(466, 'meldert-oost-vlaanderen', '4.1333274000', '50.9321261000', '9310', 'Meldert, Oost-vlaanderen', 3, 0);
INSERT INTO `lokatie` VALUES(465, 'herdersem', '4.0670588000', '50.9716007000', '9310', 'Herdersem', 3, 0);
INSERT INTO `lokatie` VALUES(464, 'baardegem', '4.1415198000', '50.9545869000', '9310', 'Baardegem', 3, 0);
INSERT INTO `lokatie` VALUES(463, 'hofstade-oost-vlaanderen', '4.0348579000', '50.9608822000', '9308', 'Hofstade, Oost-vlaanderen', 3, 0);
INSERT INTO `lokatie` VALUES(462, 'gijzegem', '4.0538551000', '50.9849628000', '9308', 'Gijzegem', 3, 0);
INSERT INTO `lokatie` VALUES(461, 'aalst', '4.0410930000', '50.9373401000', '9300', 'Aalst', 3, 0);
INSERT INTO `lokatie` VALUES(460, 'uitbergen', '3.9572656000', '51.0180477000', '9290', 'Uitbergen', 3, 0);
INSERT INTO `lokatie` VALUES(459, 'overmere', '3.9466234000', '51.0464203000', '9290', 'Overmere', 3, 0);
INSERT INTO `lokatie` VALUES(458, 'berlare', '4.0024337000', '51.0252722000', '9290', 'Berlare', 3, 0);
INSERT INTO `lokatie` VALUES(457, 'wieze', '4.0803764000', '50.9799662000', '9280', 'Wieze', 3, 0);
INSERT INTO `lokatie` VALUES(456, 'lebbeke', '4.1288124000', '51.0008290000', '9280', 'Lebbeke', 3, 0);
INSERT INTO `lokatie` VALUES(455, 'denderbelle', '4.0845652000', '51.0011341000', '9280', 'Denderbelle', 3, 0);
INSERT INTO `lokatie` VALUES(454, 'laarne', '3.8501198000', '51.0295664000', '9270', 'Laarne', 3, 0);
INSERT INTO `lokatie` VALUES(453, 'kalken', '3.9191161000', '51.0365213000', '9270', 'Kalken', 3, 0);
INSERT INTO `lokatie` VALUES(452, 'wichelen', '3.9756856000', '51.0061263000', '9260', 'Wichelen', 3, 0);
INSERT INTO `lokatie` VALUES(451, 'serskamp', '3.9291462000', '50.9889409000', '9260', 'Serskamp', 3, 0);
INSERT INTO `lokatie` VALUES(450, 'schellebelle', '3.9278658000', '51.0136273000', '9260', 'Schellebelle', 3, 0);
INSERT INTO `lokatie` VALUES(449, 'opdorp', '4.2197069000', '51.0276178000', '9255', 'Opdorp', 3, 0);
INSERT INTO `lokatie` VALUES(448, 'buggenhout', '4.2020762000', '51.0152362000', '9255', 'Buggenhout', 3, 0);
INSERT INTO `lokatie` VALUES(447, 'waasmunster', '4.0862055000', '51.1186740000', '9250', 'Waasmunster', 3, 0);
INSERT INTO `lokatie` VALUES(446, 'zele', '4.0272569000', '51.0579497000', '9240', 'Zele', 3, 0);
INSERT INTO `lokatie` VALUES(445, 'wetteren', '3.8851699000', '51.0070737000', '9230', 'Wetteren', 3, 0);
INSERT INTO `lokatie` VALUES(444, 'westrem', '3.8614451000', '50.9696818000', '9230', 'Westrem', 3, 0);
INSERT INTO `lokatie` VALUES(443, 'massemen', '3.8736955000', '50.9808321000', '9230', 'Massemen', 3, 0);
INSERT INTO `lokatie` VALUES(442, 'moerzeke', '4.1529679000', '51.0628671000', '9220', 'Moerzeke', 3, 0);
INSERT INTO `lokatie` VALUES(441, 'hamme-oost-vlaanderen', '4.1374819000', '51.0981911000', '9220', 'Hamme, Oost-vlaanderen', 3, 0);
INSERT INTO `lokatie` VALUES(440, 'sint-gillis-bij-dendermonde', '4.1109917000', '51.0193550000', '9200', 'Sint-Gillis-bij-Dendermonde', 3, 0);
INSERT INTO `lokatie` VALUES(439, 'schoonaarde', '4.0149413000', '51.0049582000', '9200', 'Schoonaarde', 3, 0);
INSERT INTO `lokatie` VALUES(438, 'oudegem', '4.0612592000', '51.0091096000', '9200', 'Oudegem', 3, 0);
INSERT INTO `lokatie` VALUES(437, 'mespelare', '4.0692884000', '50.9961760000', '9200', 'Mespelare', 3, 0);
INSERT INTO `lokatie` VALUES(436, 'grembergen', '4.1065686000', '51.0536348000', '9200', 'Grembergen', 3, 0);
INSERT INTO `lokatie` VALUES(435, 'dendermonde', '4.0989771000', '51.0300408000', '9200', 'Dendermonde', 3, 0);
INSERT INTO `lokatie` VALUES(434, 'baasrode', '4.1619075000', '51.0375867000', '9200', 'Baasrode', 3, 0);
INSERT INTO `lokatie` VALUES(433, 'appels', '4.0541566000', '51.0293277000', '9200', 'Appels', 3, 0);
INSERT INTO `lokatie` VALUES(432, 'stekene', '4.0408479000', '51.2062458000', '9190', 'Stekene', 3, 0);
INSERT INTO `lokatie` VALUES(431, 'kemzeke', '4.0783574000', '51.2071095000', '9190', 'Kemzeke', 3, 0);
INSERT INTO `lokatie` VALUES(430, 'wachtebeke', '3.8704277000', '51.1888324000', '9185', 'Wachtebeke', 3, 0);
INSERT INTO `lokatie` VALUES(429, 'moerbeke-waas', '3.9453161000', '51.1863340000', '9180', 'Moerbeke-Waas', 3, 0);
INSERT INTO `lokatie` VALUES(428, 'sint-pauwels', '4.0957277000', '51.1939958000', '9170', 'Sint-Pauwels', 3, 0);
INSERT INTO `lokatie` VALUES(427, 'sint-gillis-waas', '4.1279173000', '51.2176643000', '9170', 'Sint-Gillis-Waas', 3, 0);
INSERT INTO `lokatie` VALUES(426, 'meerdonk', '4.1466655000', '51.2600779000', '9170', 'Meerdonk', 3, 0);
INSERT INTO `lokatie` VALUES(425, 'de-klinge', '4.0900158000', '51.2562695000', '9170', 'De Klinge', 3, 0);
INSERT INTO `lokatie` VALUES(424, 'lokeren', '3.9910960000', '51.1040417000', '9160', 'Lokeren', 3, 0);
INSERT INTO `lokatie` VALUES(423, 'eksaarde', '3.9658081000', '51.1485041000', '9160', 'Eksaarde', 3, 0);
INSERT INTO `lokatie` VALUES(422, 'daknam', '3.9802396000', '51.1259089000', '9160', 'Daknam', 3, 0);
INSERT INTO `lokatie` VALUES(421, 'rupelmonde', '4.2901239000', '51.1273737000', '9150', 'Rupelmonde', 3, 0);
INSERT INTO `lokatie` VALUES(420, 'kruibeke', '4.3125620000', '51.1711145000', '9150', 'Kruibeke', 3, 0);
INSERT INTO `lokatie` VALUES(419, 'bazel', '4.2999199000', '51.1471913000', '9150', 'Bazel', 3, 0);
INSERT INTO `lokatie` VALUES(418, 'tielrode', '4.1751534000', '51.1127382000', '9140', 'Tielrode', 3, 0);
INSERT INTO `lokatie` VALUES(417, 'temse', '4.2132548000', '51.1244233000', '9140', 'Temse', 3, 0);
INSERT INTO `lokatie` VALUES(416, 'steendorp', '4.2693754000', '51.1300501000', '9140', 'Steendorp', 3, 0);
INSERT INTO `lokatie` VALUES(415, 'elversele', '4.1380170000', '51.1144412000', '9140', 'Elversele', 3, 0);
INSERT INTO `lokatie` VALUES(414, 'verrebroek', '4.1885962000', '51.2555645000', '9130', 'Verrebroek', 3, 0);
INSERT INTO `lokatie` VALUES(413, 'kieldrecht', '4.1770549000', '51.2882987000', '9130', 'Kieldrecht', 3, 0);
INSERT INTO `lokatie` VALUES(412, 'kallo-kieldrecht', '4.2787706000', '51.2525418000', '9130', 'Kallo (Kieldrecht)', 3, 0);
INSERT INTO `lokatie` VALUES(411, 'doel', '4.2636879000', '51.3098259000', '9130', 'Doel', 3, 0);
INSERT INTO `lokatie` VALUES(410, 'vrasene', '4.1947967000', '51.2192381000', '9120', 'Vrasene', 3, 0);
INSERT INTO `lokatie` VALUES(409, 'melsele', '4.2816778000', '51.2210821000', '9120', 'Melsele', 3, 0);
INSERT INTO `lokatie` VALUES(408, 'kallo-beveren-waas', '4.2787706000', '51.2525418000', '9120', 'Kallo (Beveren-Waas)', 3, 0);
INSERT INTO `lokatie` VALUES(407, 'haasdonk', '4.2403994000', '51.1816165000', '9120', 'Haasdonk', 3, 0);
INSERT INTO `lokatie` VALUES(406, 'beveren-waas', '4.2581424000', '51.2134502000', '9120', 'Beveren-Waas', 3, 0);
INSERT INTO `lokatie` VALUES(405, 'sinaai-waas', '4.0172940000', '51.1629378000', '9112', 'Sinaai-Waas', 3, 0);
INSERT INTO `lokatie` VALUES(404, 'belsele', '4.0923026000', '51.1603405000', '9111', 'Belsele', 3, 0);
INSERT INTO `lokatie` VALUES(403, 'sint-niklaas', '4.1392231000', '51.1645487000', '9100', 'Sint-Niklaas', 3, 0);
INSERT INTO `lokatie` VALUES(402, 'nieuwkerken-waas', '4.1787815000', '51.1936164000', '9100', 'Nieuwkerken-Waas', 3, 0);
INSERT INTO `lokatie` VALUES(401, 'melle', '3.8024769000', '51.0048345000', '9090', 'Melle', 3, 0);
INSERT INTO `lokatie` VALUES(400, 'gontrode', '3.7978265000', '50.9841940000', '9090', 'Gontrode', 3, 0);
INSERT INTO `lokatie` VALUES(399, 'zeveneken', '3.8995861000', '51.1075027000', '9080', 'Zeveneken', 3, 0);
INSERT INTO `lokatie` VALUES(398, 'zaffelare', '3.8616086000', '51.1325569000', '9080', 'Zaffelare', 3, 0);
INSERT INTO `lokatie` VALUES(397, 'lochristi', '3.8331035000', '51.0960498000', '9080', 'Lochristi', 3, 0);
INSERT INTO `lokatie` VALUES(396, 'beervelde', '3.8785641000', '51.0802233000', '9080', 'Beervelde', 3, 0);
INSERT INTO `lokatie` VALUES(395, 'heusden-ovl', '3.7991096000', '51.0283585000', '9070', 'Heusden (O.Vl.)', 3, 0);
INSERT INTO `lokatie` VALUES(394, 'destelbergen', '3.7988892000', '51.0560874000', '9070', 'Destelbergen', 3, 0);
INSERT INTO `lokatie` VALUES(393, 'zelzate', '3.8025675000', '51.1962930000', '9060', 'Zelzate', 3, 0);
INSERT INTO `lokatie` VALUES(392, 'zwijnaarde', '3.7139045000', '51.0003903000', '9052', 'Zwijnaarde', 3, 0);
INSERT INTO `lokatie` VALUES(391, 'sint-denijs-westrem', '3.6688741000', '51.0213784000', '9051', 'Sint-Denijs-Westrem', 3, 0);
INSERT INTO `lokatie` VALUES(390, 'afsnee', '3.6683429000', '51.0309030000', '9051', 'Afsnee', 3, 0);
INSERT INTO `lokatie` VALUES(389, 'ledeberg', '3.7425471000', '51.0374725000', '9050', 'Ledeberg', 3, 0);
INSERT INTO `lokatie` VALUES(388, 'gentbrugge', '3.7630264000', '51.0317355000', '9050', 'Gentbrugge', 3, 0);
INSERT INTO `lokatie` VALUES(387, 'sint-kruis-winkel', '3.8262717000', '51.1542780000', '9042', 'Sint-Kruis-Winkel', 3, 0);
INSERT INTO `lokatie` VALUES(386, 'mendonk', '3.8212923000', '51.1467995000', '9042', 'Mendonk', 3, 0);
INSERT INTO `lokatie` VALUES(385, 'desteldonk', '3.7811183000', '51.1220781000', '9042', 'Desteldonk', 3, 0);
INSERT INTO `lokatie` VALUES(384, 'oostakker', '3.7634504000', '51.1002862000', '9041', 'Oostakker', 3, 0);
INSERT INTO `lokatie` VALUES(383, 'sint-amandsberg', '3.7566349000', '51.0643361000', '9040', 'Sint-Amandsberg', 3, 0);
INSERT INTO `lokatie` VALUES(382, 'wondelgem', '3.7043131000', '51.0921461000', '9032', 'Wondelgem', 3, 0);
INSERT INTO `lokatie` VALUES(381, 'drongen', '3.6273160000', '51.0501221000', '9031', 'Drongen', 3, 0);
INSERT INTO `lokatie` VALUES(380, 'mariakerke', '3.6740266000', '51.0747998000', '9030', 'Mariakerke', 3, 0);
INSERT INTO `lokatie` VALUES(379, 'gent', '3.7290914000', '51.0678307000', '9000', 'Gent', 3, 0);
INSERT INTO `lokatie` VALUES(378, 'wijchmaal', '5.4141039000', '51.1357430000', '3990', 'Wijchmaal', 2, 0);
INSERT INTO `lokatie` VALUES(377, 'peer', '5.4517445000', '51.1330304000', '3990', 'Peer', 2, 0);
INSERT INTO `lokatie` VALUES(376, 'kleine-brogel', '5.4502746000', '51.1723728000', '3990', 'Kleine-Brogel', 2, 0);
INSERT INTO `lokatie` VALUES(375, 'grote-brogel', '5.5056905000', '51.1534501000', '3990', 'Grote-Brogel', 2, 0);
INSERT INTO `lokatie` VALUES(374, 'tessenderlo', '5.0639450000', '51.0595014000', '3980', 'Tessenderlo', 2, 0);
INSERT INTO `lokatie` VALUES(373, 'heppen', '5.2331385000', '51.1096411000', '3971', 'Heppen', 2, 0);
INSERT INTO `lokatie` VALUES(372, 'leopoldsburg', '5.2605406000', '51.1188884000', '3970', 'Leopoldsburg', 2, 0);
INSERT INTO `lokatie` VALUES(371, 'tongerlo-limburg', '5.6599828000', '51.1269820000', '3960', 'Tongerlo, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(370, 'opitter', '5.6460330000', '51.1173205000', '3960', 'Opitter', 2, 0);
INSERT INTO `lokatie` VALUES(369, 'gerdingen', '5.5887286000', '51.1473359000', '3960', 'Gerdingen', 2, 0);
INSERT INTO `lokatie` VALUES(368, 'bree', '5.5976215000', '51.1410923000', '3960', 'Bree', 2, 0);
INSERT INTO `lokatie` VALUES(367, 'beek', '5.6027359000', '51.1552253000', '3960', 'Beek', 2, 0);
INSERT INTO `lokatie` VALUES(366, 'reppel', '5.5614489000', '51.1545555000', '3950', 'Reppel', 2, 0);
INSERT INTO `lokatie` VALUES(365, 'kaulille', '5.5179683000', '51.1880748000', '3950', 'Kaulille', 2, 0);
INSERT INTO `lokatie` VALUES(364, 'bocholt', '5.5780893000', '51.1725313000', '3950', 'Bocholt', 2, 0);
INSERT INTO `lokatie` VALUES(363, 'oostham', '5.1782184000', '51.1035321000', '3945', 'Oostham', 2, 0);
INSERT INTO `lokatie` VALUES(362, 'kwaadmechelen', '5.1474174000', '51.1016097000', '3945', 'Kwaadmechelen', 2, 0);
INSERT INTO `lokatie` VALUES(361, 'ham', '5.1730329000', '51.0966039000', '3945', 'Ham', 2, 0);
INSERT INTO `lokatie` VALUES(360, 'eksel', '5.3630586000', '51.1509150000', '3941', 'Eksel', 2, 0);
INSERT INTO `lokatie` VALUES(359, 'hechtel-eksel', '5.3295958000', '51.1105222000', '3940', 'Hechtel-Eksel', 2, 0);
INSERT INTO `lokatie` VALUES(358, 'hechtel', '5.3295958000', '51.1105222000', '3940', 'Hechtel', 2, 0);
INSERT INTO `lokatie` VALUES(357, 'hamont-achel', '5.5154222000', '51.2697668000', '3930', 'Hamont-Achel', 2, 0);
INSERT INTO `lokatie` VALUES(356, 'hamont', '5.5154222000', '51.2697668000', '3930', 'Hamont', 2, 0);
INSERT INTO `lokatie` VALUES(355, 'achel', '5.4785929000', '51.2545350000', '3930', 'Achel', 2, 0);
INSERT INTO `lokatie` VALUES(354, 'lommel', '5.2983567000', '51.2167985000', '3920', 'Lommel', 2, 0);
INSERT INTO `lokatie` VALUES(353, 'sint-huibrechts-lille', '5.4847906000', '51.2260493000', '3910', 'Sint-Huibrechts-Lille', 2, 0);
INSERT INTO `lokatie` VALUES(352, 'neerpelt', '5.4315988000', '51.2289071000', '3910', 'Neerpelt', 2, 0);
INSERT INTO `lokatie` VALUES(351, 'overpelt', '5.3966251000', '51.1913215000', '3900', 'Overpelt', 2, 0);
INSERT INTO `lokatie` VALUES(350, 'muizen-limburg', '5.1771106000', '50.7598214000', '3891', 'Muizen, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(349, 'mielen-boven-aalst', '5.2148663000', '50.7557827000', '3891', 'Mielen-boven-Aalst', 2, 0);
INSERT INTO `lokatie` VALUES(348, 'buvingen', '5.1758542000', '50.7526442000', '3891', 'Buvingen', 2, 0);
INSERT INTO `lokatie` VALUES(347, 'borlo', '5.1812494000', '50.7421975000', '3891', 'Borlo', 2, 0);
INSERT INTO `lokatie` VALUES(346, 'vorsen', '5.1714356000', '50.7038390000', '3890', 'Vorsen', 2, 0);
INSERT INTO `lokatie` VALUES(345, 'niel-bij-sint-truiden', '5.1399039000', '50.7411774000', '3890', 'Niel-bij-Sint-Truiden', 2, 0);
INSERT INTO `lokatie` VALUES(344, 'montenaken', '5.1344054000', '50.7222149000', '3890', 'Montenaken', 2, 0);
INSERT INTO `lokatie` VALUES(343, 'kortijs', '5.1503848000', '50.7069797000', '3890', 'Kortijs', 2, 0);
INSERT INTO `lokatie` VALUES(342, 'jeuk', '5.2097270000', '50.7342411000', '3890', 'Jeuk', 2, 0);
INSERT INTO `lokatie` VALUES(341, 'gingelom', '5.1352185000', '50.7500444000', '3890', 'Gingelom', 2, 0);
INSERT INTO `lokatie` VALUES(340, 'boekhout', '5.2333527000', '50.7457053000', '3890', 'Boekhout', 2, 0);
INSERT INTO `lokatie` VALUES(339, 'veulen', '5.3048989000', '50.7629280000', '3870', 'Veulen', 2, 0);
INSERT INTO `lokatie` VALUES(338, 'vechmaal', '5.3730378000', '50.7612244000', '3870', 'Vechmaal', 2, 0);
INSERT INTO `lokatie` VALUES(337, 'rukkelingen-loon', '5.2543685000', '50.7285680000', '3870', 'Rukkelingen-Loon', 2, 0);
INSERT INTO `lokatie` VALUES(336, 'opheers', '5.2939691000', '50.7366931000', '3870', 'Opheers', 2, 0);
INSERT INTO `lokatie` VALUES(335, 'mettekoven', '5.2896510000', '50.7811178000', '3870', 'Mettekoven', 2, 0);
INSERT INTO `lokatie` VALUES(334, 'mechelen-bovelingen', '5.2580240000', '50.7384190000', '3870', 'Mechelen-Bovelingen', 2, 0);
INSERT INTO `lokatie` VALUES(333, 'klein-gelmen', '5.2757461000', '50.7712359000', '3870', 'Klein-Gelmen', 2, 0);
INSERT INTO `lokatie` VALUES(332, 'horpmaal', '5.3323897000', '50.7587401000', '3870', 'Horpmaal', 2, 0);
INSERT INTO `lokatie` VALUES(331, 'heks', '5.3576042000', '50.7702017000', '3870', 'Heks', 2, 0);
INSERT INTO `lokatie` VALUES(330, 'heers', '5.3011659000', '50.7551226000', '3870', 'Heers', 2, 0);
INSERT INTO `lokatie` VALUES(329, 'gutschoven', '5.3180122000', '50.7714711000', '3870', 'Gutschoven', 2, 0);
INSERT INTO `lokatie` VALUES(328, 'bovelingen', '5.2607332000', '50.7410068000', '3870', 'Bovelingen', 2, 0);
INSERT INTO `lokatie` VALUES(327, 'batsheers', '5.2811626000', '50.7374887000', '3870', 'Batsheers', 2, 0);
INSERT INTO `lokatie` VALUES(326, 'wijer', '5.2242224000', '50.8986726000', '3850', 'Wijer', 2, 0);
INSERT INTO `lokatie` VALUES(325, 'nieuwerkerken-limburg', '5.1933792000', '50.8646381000', '3850', 'Nieuwerkerken, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(324, 'kozen', '5.2397691000', '50.8749722000', '3850', 'Kozen', 2, 0);
INSERT INTO `lokatie` VALUES(323, 'binderveld', '5.1717331000', '50.8628286000', '3850', 'Binderveld', 2, 0);
INSERT INTO `lokatie` VALUES(322, 'voort', '5.3185357000', '50.7938699000', '3840', 'Voort', 2, 0);
INSERT INTO `lokatie` VALUES(321, 'rijkel', '5.2611818000', '50.8050432000', '3840', 'Rijkel', 2, 0);
INSERT INTO `lokatie` VALUES(320, 'kuttekoven', '5.3306603000', '50.8079458000', '3840', 'Kuttekoven', 2, 0);
INSERT INTO `lokatie` VALUES(319, 'kolmont-borgloon', '5.4207783000', '50.8026992000', '3840', 'Kolmont (Borgloon)', 2, 0);
INSERT INTO `lokatie` VALUES(318, 'kerniel', '5.3632743000', '50.8165474000', '3840', 'Kerniel', 2, 0);
INSERT INTO `lokatie` VALUES(317, 'jesseren-kolmont', '5.3905239000', '50.8058364000', '3840', 'Jesseren (Kolmont)', 2, 0);
INSERT INTO `lokatie` VALUES(316, 'hoepertingen', '5.2851950000', '50.8115826000', '3840', 'Hoepertingen', 2, 0);
INSERT INTO `lokatie` VALUES(315, 'hendrieken', '5.3292693000', '50.7988359000', '3840', 'Hendrieken', 2, 0);
INSERT INTO `lokatie` VALUES(314, 'haren-borgloon', '5.3981671000', '50.7937257000', '3840', 'Haren (Borgloon)', 2, 0);
INSERT INTO `lokatie` VALUES(313, 'groot-loon', '5.3646903000', '50.7923669000', '3840', 'Groot-Loon', 2, 0);
INSERT INTO `lokatie` VALUES(312, 'gotem', '5.3108605000', '50.8046338000', '3840', 'Gotem', 2, 0);
INSERT INTO `lokatie` VALUES(311, 'gors-opleeuw', '5.3965907000', '50.8236072000', '3840', 'Gors-Opleeuw', 2, 0);
INSERT INTO `lokatie` VALUES(310, 'broekom', '5.3318366000', '50.7823861000', '3840', 'Broekom', 2, 0);
INSERT INTO `lokatie` VALUES(309, 'borgloon', '5.3446519000', '50.8013525000', '3840', 'Borgloon', 2, 0);
INSERT INTO `lokatie` VALUES(308, 'bommershoven-haren', '5.3806915000', '50.7852389000', '3840', 'Bommershoven (Haren)', 2, 0);
INSERT INTO `lokatie` VALUES(307, 'ulbeek', '5.2857336000', '50.8459041000', '3832', 'Ulbeek', 2, 0);
INSERT INTO `lokatie` VALUES(306, 'herten', '5.3314582000', '50.8268715000', '3831', 'Herten', 2, 0);
INSERT INTO `lokatie` VALUES(305, 'wellen', '5.3430820000', '50.8402302000', '3830', 'Wellen', 2, 0);
INSERT INTO `lokatie` VALUES(304, 'berlingen', '5.3102385000', '50.8175498000', '3830', 'Berlingen', 2, 0);
INSERT INTO `lokatie` VALUES(303, 'velm', '5.1337266000', '50.7797018000', '3806', 'Velm', 2, 0);
INSERT INTO `lokatie` VALUES(302, 'wilderen', '5.1432575000', '50.8180662000', '3803', 'Wilderen', 2, 0);
INSERT INTO `lokatie` VALUES(301, 'runkelen', '5.1542576000', '50.8464540000', '3803', 'Runkelen', 2, 0);
INSERT INTO `lokatie` VALUES(300, 'gorsem', '5.1646575000', '50.8334526000', '3803', 'Gorsem', 2, 0);
INSERT INTO `lokatie` VALUES(299, 'duras', '5.1463535000', '50.8351964000', '3803', 'Duras', 2, 0);
INSERT INTO `lokatie` VALUES(298, 'zepperen', '5.2476315000', '50.8211744000', '3800', 'Zepperen', 2, 0);
INSERT INTO `lokatie` VALUES(297, 'sint-truiden', '5.1866650000', '50.8154590000', '3800', 'Sint-Truiden', 2, 0);
INSERT INTO `lokatie` VALUES(296, 'ordingen', '5.2329715000', '50.8107767000', '3800', 'Ordingen', 2, 0);
INSERT INTO `lokatie` VALUES(295, 'kerkom-bij-sint-truiden', '5.1777875000', '50.7743418000', '3800', 'Kerkom-bij-Sint-Truiden', 2, 0);
INSERT INTO `lokatie` VALUES(294, 'halmaal', '5.1544034000', '50.8042884000', '3800', 'Halmaal', 2, 0);
INSERT INTO `lokatie` VALUES(293, 'groot-gelmen', '5.2657073000', '50.7821123000', '3800', 'Groot-Gelmen', 2, 0);
INSERT INTO `lokatie` VALUES(292, 'gelinden', '5.2628934000', '50.7670559000', '3800', 'Gelinden', 2, 0);
INSERT INTO `lokatie` VALUES(291, 'engelmanshoven', '5.2531011000', '50.7741949000', '3800', 'Engelmanshoven', 2, 0);
INSERT INTO `lokatie` VALUES(290, 'brustem', '5.2192524000', '50.8017456000', '3800', 'Brustem', 2, 0);
INSERT INTO `lokatie` VALUES(289, 'aalst-limburg', '5.2121700000', '50.7814490000', '3800', 'Aalst, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(288, '039s-gravenvoerenfouron-le-comte', '5.7669272000', '50.7605269000', '3798', '&#039;s Gravenvoeren/Fouron-le-Comte', 2, 0);
INSERT INTO `lokatie` VALUES(287, 'teuven', '5.8684528000', '50.7554588000', '3793', 'Teuven', 2, 0);
INSERT INTO `lokatie` VALUES(286, 'sint-pieters-voerenfouron-saint-pierre', '5.8239190000', '50.7264257000', '3792', 'Sint-Pieters-Voeren/Fouron-Saint-Pierre', 2, 0);
INSERT INTO `lokatie` VALUES(285, 'remersdaal', '5.8895119000', '50.7335494000', '3791', 'Remersdaal', 2, 0);
INSERT INTO `lokatie` VALUES(284, 'voerenfourons', '5.8409039000', '50.7464187000', '3790', 'Voeren/Fourons', 2, 0);
INSERT INTO `lokatie` VALUES(283, 'sint-martens-voerenfouron-saint-martin', '5.8130293000', '50.7494714000', '3790', 'Sint-Martens-Voeren/Fouron-Saint-Martin', 2, 0);
INSERT INTO `lokatie` VALUES(282, 'moelingenmouland', '5.7106458000', '50.7570313000', '3790', 'Moelingen/Mouland', 2, 0);
INSERT INTO `lokatie` VALUES(281, 'zichen-zussen-bolder', '5.6233032000', '50.7934642000', '3770', 'Zichen-Zussen-Bolder', 2, 0);
INSERT INTO `lokatie` VALUES(280, 'vroenhoven', '5.6399672000', '50.8262896000', '3770', 'Vroenhoven', 2, 0);
INSERT INTO `lokatie` VALUES(279, 'vlijtingen', '5.5891740000', '50.8336883000', '3770', 'Vlijtingen', 2, 0);
INSERT INTO `lokatie` VALUES(278, 'val-meer', '5.5954658000', '50.7866506000', '3770', 'Val-Meer', 2, 0);
INSERT INTO `lokatie` VALUES(277, 'riemst', '5.6016047000', '50.8091977000', '3770', 'Riemst', 2, 0);
INSERT INTO `lokatie` VALUES(276, 'millen', '5.5607362000', '50.7843251000', '3770', 'Millen', 2, 0);
INSERT INTO `lokatie` VALUES(275, 'membruggen', '5.5340568000', '50.8177086000', '3770', 'Membruggen', 2, 0);
INSERT INTO `lokatie` VALUES(274, 'kanne', '5.6742082000', '50.8134909000', '3770', 'Kanne', 2, 0);
INSERT INTO `lokatie` VALUES(273, 'herderen', '5.5727572000', '50.8076856000', '3770', 'Herderen', 2, 0);
INSERT INTO `lokatie` VALUES(272, 'genoelselderen', '5.5346721000', '50.8014866000', '3770', 'Genoelselderen', 2, 0);
INSERT INTO `lokatie` VALUES(271, 'hoelbeek', '5.5621743000', '50.8721928000', '3746', 'Hoelbeek', 2, 0);
INSERT INTO `lokatie` VALUES(270, 'martenslinde', '5.5327097000', '50.8527157000', '3742', 'Martenslinde', 2, 0);
INSERT INTO `lokatie` VALUES(269, 'waltwilder', '5.5448128000', '50.8644441000', '3740', 'Waltwilder', 2, 0);
INSERT INTO `lokatie` VALUES(268, 'spouwen', '5.5333330000', '50.8333330000', '3740', 'Spouwen', 2, 0);
INSERT INTO `lokatie` VALUES(267, 'rosmeer', '5.5750235000', '50.8460854000', '3740', 'Rosmeer', 2, 0);
INSERT INTO `lokatie` VALUES(266, 'rijkhoven', '5.5134955000', '50.8362829000', '3740', 'Rijkhoven', 2, 0);
INSERT INTO `lokatie` VALUES(265, 'munsterbilzen', '5.5265255000', '50.8891799000', '3740', 'Munsterbilzen', 2, 0);
INSERT INTO `lokatie` VALUES(264, 'mopertingen', '5.5741976000', '50.8625451000', '3740', 'Mopertingen', 2, 0);
INSERT INTO `lokatie` VALUES(263, 'kleine-spouwen', '5.5473369000', '50.8382821000', '3740', 'Kleine-Spouwen', 2, 0);
INSERT INTO `lokatie` VALUES(262, 'hees', '5.6093575000', '50.8454948000', '3740', 'Hees', 2, 0);
INSERT INTO `lokatie` VALUES(261, 'grote-spouwen', '5.5529753000', '50.8336791000', '3740', 'Grote-Spouwen', 2, 0);
INSERT INTO `lokatie` VALUES(260, 'eigenbilzen', '5.5739574000', '50.8753392000', '3740', 'Eigenbilzen', 2, 0);
INSERT INTO `lokatie` VALUES(259, 'bilzen', '5.5180271000', '50.8707362000', '3740', 'Bilzen', 2, 0);
INSERT INTO `lokatie` VALUES(258, 'beverst', '5.4734872000', '50.8915814000', '3740', 'Beverst', 2, 0);
INSERT INTO `lokatie` VALUES(257, 'schalkhoven', '5.4473553000', '50.8410786000', '3732', 'Schalkhoven', 2, 0);
INSERT INTO `lokatie` VALUES(256, 'werm', '5.4800934000', '50.8327915000', '3730', 'Werm', 2, 0);
INSERT INTO `lokatie` VALUES(255, 'sint-huibrechts-hern', '5.4513759000', '50.8268962000', '3730', 'Sint-Huibrechts-Hern', 2, 0);
INSERT INTO `lokatie` VALUES(254, 'romershoven', '5.4597408000', '50.8582115000', '3730', 'Romershoven', 2, 0);
INSERT INTO `lokatie` VALUES(253, 'hoeselt', '5.4860991000', '50.8500400000', '3730', 'Hoeselt', 2, 0);
INSERT INTO `lokatie` VALUES(252, 'vliermaal', '5.4227110000', '50.8291852000', '3724', 'Vliermaal', 2, 0);
INSERT INTO `lokatie` VALUES(251, 'guigoven', '5.3967642000', '50.8434298000', '3723', 'Guigoven', 2, 0);
INSERT INTO `lokatie` VALUES(250, 'wintershoven', '5.4114092000', '50.8531866000', '3722', 'Wintershoven', 2, 0);
INSERT INTO `lokatie` VALUES(249, 'vliermaalroot', '5.4307377000', '50.8705543000', '3721', 'Vliermaalroot', 2, 0);
INSERT INTO `lokatie` VALUES(248, 'kortessem', '5.3781216000', '50.8625531000', '3720', 'Kortessem', 2, 0);
INSERT INTO `lokatie` VALUES(247, 'herstappe', '5.4252762000', '50.7274341000', '3717', 'Herstappe', 2, 0);
INSERT INTO `lokatie` VALUES(246, 'widooie-haren', '5.4072410000', '50.7721686000', '3700', 'Widooie (Haren)', 2, 0);
INSERT INTO `lokatie` VALUES(245, 'vreren', '5.4974685000', '50.7515562000', '3700', 'Vreren', 2, 0);
INSERT INTO `lokatie` VALUES(244, 'tongeren', '5.4648639000', '50.7809591000', '3700', 'Tongeren', 2, 0);
INSERT INTO `lokatie` VALUES(243, 'sluizen', '5.5306047000', '50.7666334000', '3700', 'Sluizen', 2, 0);
INSERT INTO `lokatie` VALUES(242, '039s-herenelderen', '5.4968925000', '50.8068059000', '3700', '&#039;s Herenelderen', 2, 0);
INSERT INTO `lokatie` VALUES(241, 'rutten', '5.4427213000', '50.7474533000', '3700', 'Rutten', 2, 0);
INSERT INTO `lokatie` VALUES(240, 'riksingen', '5.4624396000', '50.8058913000', '3700', 'Riksingen', 2, 0);
INSERT INTO `lokatie` VALUES(239, 'piringen-haren', '5.4201087000', '50.7859400000', '3700', 'Piringen (Haren)', 2, 0);
INSERT INTO `lokatie` VALUES(238, 'overrepen-kolmont', '5.4303637000', '50.8078672000', '3700', 'Overrepen (Kolmont)', 2, 0);
INSERT INTO `lokatie` VALUES(237, 'nerem', '5.5094201000', '50.7617761000', '3700', 'Nerem', 2, 0);
INSERT INTO `lokatie` VALUES(236, 'neerrepen', '5.4441736000', '50.8129840000', '3700', 'Neerrepen', 2, 0);
INSERT INTO `lokatie` VALUES(235, 'mal', '5.5218672000', '50.7684626000', '3700', 'Mal', 2, 0);
INSERT INTO `lokatie` VALUES(234, 'lauw', '5.4147148000', '50.7398345000', '3700', 'Lauw', 2, 0);
INSERT INTO `lokatie` VALUES(233, 'koninksem', '5.4420409000', '50.7660785000', '3700', 'Koninksem', 2, 0);
INSERT INTO `lokatie` VALUES(232, 'kolmont-tongeren', '5.4207783000', '50.8026992000', '3700', 'Kolmont (Tongeren)', 2, 0);
INSERT INTO `lokatie` VALUES(231, 'henis', '5.4711739000', '50.7992280000', '3700', 'Henis', 2, 0);
INSERT INTO `lokatie` VALUES(230, 'haren-tongeren', '5.3981671000', '50.7937257000', '3700', 'Haren (Tongeren)', 2, 0);
INSERT INTO `lokatie` VALUES(229, 'diets-heur', '5.4840801000', '50.7456958000', '3700', 'Diets-Heur', 2, 0);
INSERT INTO `lokatie` VALUES(228, 'berg-limburg', '5.4932174000', '50.7908496000', '3700', 'Berg, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(227, 'zutendaal', '5.5772043000', '50.9315388000', '3690', 'Zutendaal', 2, 0);
INSERT INTO `lokatie` VALUES(226, 'opoeteren', '5.6548985000', '51.0694507000', '3680', 'Opoeteren', 2, 0);
INSERT INTO `lokatie` VALUES(225, 'neeroeteren', '5.7048356000', '51.0886511000', '3680', 'Neeroeteren', 2, 0);
INSERT INTO `lokatie` VALUES(224, 'maaseik', '5.7939066000', '51.0948261000', '3680', 'Maaseik', 2, 0);
INSERT INTO `lokatie` VALUES(223, 'wijshagen', '5.5612363000', '51.1056773000', '3670', 'Wijshagen', 2, 0);
INSERT INTO `lokatie` VALUES(222, 'neerglabbeek', '5.6142616000', '51.0918441000', '3670', 'Neerglabbeek', 2, 0);
INSERT INTO `lokatie` VALUES(221, 'meeuwen-gruitrode', '5.5551470000', '51.0790680000', '3670', 'Meeuwen-Gruitrode', 2, 0);
INSERT INTO `lokatie` VALUES(220, 'meeuwen', '5.5209987000', '51.0961099000', '3670', 'Meeuwen', 2, 0);
INSERT INTO `lokatie` VALUES(219, 'gruitrode', '5.5551470000', '51.0790680000', '3670', 'Gruitrode', 2, 0);
INSERT INTO `lokatie` VALUES(218, 'ellikom', '5.5248953000', '51.1299619000', '3670', 'Ellikom', 2, 0);
INSERT INTO `lokatie` VALUES(217, 'niel-bij-as', '5.6139436000', '51.0186720000', '3668', 'Niel-bij-As', 2, 0);
INSERT INTO `lokatie` VALUES(216, 'as', '5.5715438000', '50.9997751000', '3665', 'As', 2, 0);
INSERT INTO `lokatie` VALUES(215, 'opglabbeek', '5.5724074000', '51.0363610000', '3660', 'Opglabbeek', 2, 0);
INSERT INTO `lokatie` VALUES(214, 'rotem', '5.7385093000', '51.0532458000', '3650', 'Rotem', 2, 0);
INSERT INTO `lokatie` VALUES(213, 'lanklaar', '5.7197357000', '51.0129002000', '3650', 'Lanklaar', 2, 0);
INSERT INTO `lokatie` VALUES(212, 'elen', '5.7592675000', '51.0664899000', '3650', 'Elen', 2, 0);
INSERT INTO `lokatie` VALUES(211, 'dilsen-stokkem', '5.7220645000', '51.0374849000', '3650', 'Dilsen-Stokkem', 2, 0);
INSERT INTO `lokatie` VALUES(210, 'ophoven', '5.8022361000', '51.1260567000', '3640', 'Ophoven', 2, 0);
INSERT INTO `lokatie` VALUES(209, 'molenbeersel', '5.7373361000', '51.1697822000', '3640', 'Molenbeersel', 2, 0);
INSERT INTO `lokatie` VALUES(208, 'kinrooi', '5.7409459000', '51.1447824000', '3640', 'Kinrooi', 2, 0);
INSERT INTO `lokatie` VALUES(207, 'kessenich', '5.8245292000', '51.1503062000', '3640', 'Kessenich', 2, 0);
INSERT INTO `lokatie` VALUES(206, 'uikhoven', '5.7257575000', '50.9239154000', '3631', 'Uikhoven', 2, 0);
INSERT INTO `lokatie` VALUES(205, 'boorsem', '5.7197253000', '50.9408520000', '3631', 'Boorsem', 2, 0);
INSERT INTO `lokatie` VALUES(204, 'vucht', '5.7136710000', '50.9764472000', '3630', 'Vucht', 2, 0);
INSERT INTO `lokatie` VALUES(203, 'opgrimbie', '5.6799630000', '50.9412000000', '3630', 'Opgrimbie', 2, 0);
INSERT INTO `lokatie` VALUES(202, 'meeswijk', '5.7476978000', '50.9994633000', '3630', 'Meeswijk', 2, 0);
INSERT INTO `lokatie` VALUES(201, 'mechelen-aan-de-maas', '5.6960092000', '50.9629240000', '3630', 'Mechelen-aan-de-Maas', 2, 0);
INSERT INTO `lokatie` VALUES(200, 'maasmechelen', '5.7006165000', '50.9616031000', '3630', 'Maasmechelen', 2, 0);
INSERT INTO `lokatie` VALUES(199, 'leut', '5.7355220000', '50.9915661000', '3630', 'Leut', 2, 0);
INSERT INTO `lokatie` VALUES(198, 'eisden', '5.7176376000', '50.9832545000', '3630', 'Eisden', 2, 0);
INSERT INTO `lokatie` VALUES(197, 'rekem', '5.6715779000', '50.9217656000', '3621', 'Rekem', 2, 0);
INSERT INTO `lokatie` VALUES(196, 'veldwezelt', '5.6316269000', '50.8651292000', '3620', 'Veldwezelt', 2, 0);
INSERT INTO `lokatie` VALUES(195, 'neerharen', '5.6871520000', '50.9083018000', '3620', 'Neerharen', 2, 0);
INSERT INTO `lokatie` VALUES(194, 'lanaken', '5.6507384000', '50.8901027000', '3620', 'Lanaken', 2, 0);
INSERT INTO `lokatie` VALUES(193, 'gellik', '5.6061107000', '50.8831029000', '3620', 'Gellik', 2, 0);
INSERT INTO `lokatie` VALUES(192, 'genk', '5.5001852000', '50.9635588000', '3600', 'Genk', 2, 0);
INSERT INTO `lokatie` VALUES(191, 'diepenbeek', '5.4060911000', '50.9082457000', '3590', 'Diepenbeek', 2, 0);
INSERT INTO `lokatie` VALUES(190, 'paal', '5.1707265000', '51.0495936000', '3583', 'Paal', 2, 0);
INSERT INTO `lokatie` VALUES(189, 'koersel', '5.2708082000', '51.0712929000', '3582', 'Koersel', 2, 0);
INSERT INTO `lokatie` VALUES(188, 'beverlo', '5.2419586000', '51.0882973000', '3581', 'Beverlo', 2, 0);
INSERT INTO `lokatie` VALUES(187, 'beringen', '5.2214769000', '51.0473373000', '3580', 'Beringen', 2, 0);
INSERT INTO `lokatie` VALUES(186, 'alken', '5.2862633000', '50.8824075000', '3570', 'Alken', 2, 0);
INSERT INTO `lokatie` VALUES(185, 'meldert-limburg', '5.1419299000', '50.9986703000', '3560', 'Meldert, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(184, 'lummen', '5.1911345000', '50.9861892000', '3560', 'Lummen', 2, 0);
INSERT INTO `lokatie` VALUES(183, 'linkhout', '5.1372937000', '50.9655394000', '3560', 'Linkhout', 2, 0);
INSERT INTO `lokatie` VALUES(182, 'zolder', '5.2883713000', '51.0286322000', '3550', 'Zolder', 2, 0);
INSERT INTO `lokatie` VALUES(181, 'heusden-zolder', '5.2883713000', '51.0286322000', '3550', 'Heusden-Zolder', 2, 0);
INSERT INTO `lokatie` VALUES(180, 'heusden-limburg', '5.2818103000', '51.0349982000', '3550', 'Heusden, Limburg', 2, 0);
INSERT INTO `lokatie` VALUES(179, 'zelem', '5.1048162000', '50.9793448000', '3545', 'Zelem', 2, 0);
INSERT INTO `lokatie` VALUES(178, 'loksbergen', '5.0694246000', '50.9342667000', '3545', 'Loksbergen', 2, 0);
INSERT INTO `lokatie` VALUES(177, 'halen', '5.1145643000', '50.9481892000', '3545', 'Halen', 2, 0);
INSERT INTO `lokatie` VALUES(176, 'schulen', '5.1767375000', '50.9570899000', '3540', 'Schulen', 2, 0);
INSERT INTO `lokatie` VALUES(175, 'herk-de-stad', '5.1670883000', '50.9409856000', '3540', 'Herk-de-Stad', 2, 0);
INSERT INTO `lokatie` VALUES(174, 'donk', '5.1339598000', '50.9391961000', '3540', 'Donk', 2, 0);
INSERT INTO `lokatie` VALUES(173, 'berbroek', '5.2083975000', '50.9503304000', '3540', 'Berbroek', 2, 0);
INSERT INTO `lokatie` VALUES(172, 'houthalen-helchteren', '5.4194864000', '51.0435550000', '3530', 'Houthalen-Helchteren', 2, 0);
INSERT INTO `lokatie` VALUES(171, 'houthalen', '5.4194864000', '51.0435550000', '3530', 'Houthalen', 2, 0);
INSERT INTO `lokatie` VALUES(170, 'helchteren', '5.3843951000', '51.0561470000', '3530', 'Helchteren', 2, 0);
INSERT INTO `lokatie` VALUES(169, 'zonhoven', '5.3671983000', '50.9871295000', '3520', 'Zonhoven', 2, 0);
INSERT INTO `lokatie` VALUES(168, 'stevoort', '5.2488451000', '50.9206443000', '3512', 'Stevoort', 2, 0);
INSERT INTO `lokatie` VALUES(167, 'stokrooie', '5.2831378000', '50.9665418000', '3511', 'Stokrooie', 2, 0);
INSERT INTO `lokatie` VALUES(166, 'kuringen', '5.3053389000', '50.9440751000', '3511', 'Kuringen', 2, 0);
INSERT INTO `lokatie` VALUES(165, 'spalbeek', '5.2302442000', '50.9497028000', '3510', 'Spalbeek', 2, 0);
INSERT INTO `lokatie` VALUES(164, 'kermt', '5.2536483000', '50.9474414000', '3510', 'Kermt', 2, 0);
INSERT INTO `lokatie` VALUES(163, 'wimmertingen', '5.3513070000', '50.8807484000', '3501', 'Wimmertingen', 2, 0);
INSERT INTO `lokatie` VALUES(162, 'sint-lambrechts-herk', '5.3073146000', '50.8982913000', '3500', 'Sint-Lambrechts-Herk', 2, 0);
INSERT INTO `lokatie` VALUES(161, 'hasselt', '5.3382272000', '50.9297333000', '3500', 'Hasselt', 2, 0);
INSERT INTO `lokatie` VALUES(160, 'wuustwezel', '4.5911512000', '51.3910554000', '2990', 'Wuustwezel', 1, 0);
INSERT INTO `lokatie` VALUES(159, 'loenhout', '4.6440805000', '51.3990544000', '2990', 'Loenhout', 1, 0);
INSERT INTO `lokatie` VALUES(158, 'zoersel', '4.7123859000', '51.2673788000', '2980', 'Zoersel', 1, 0);
INSERT INTO `lokatie` VALUES(157, 'halle-kempen', '4.6465144000', '51.2398077000', '2980', 'Halle, Kempen', 1, 0);
INSERT INTO `lokatie` VALUES(156, 'schilde', '4.5834127000', '51.2319753000', '2970', 'Schilde', 1, 0);
INSERT INTO `lokatie` VALUES(155, '039s-gravenwezel', '4.5547451000', '51.2632081000', '2970', '&#039;s Gravenwezel', 1, 0);
INSERT INTO `lokatie` VALUES(154, 'sint-lenaarts', '4.6791688000', '51.3470839000', '2960', 'Sint-Lenaarts', 1, 0);
INSERT INTO `lokatie` VALUES(153, 'sint-job-in-039t-goor', '4.5832721000', '51.2927798000', '2960', 'Sint-Job-in-&#039;t-Goor', 1, 0);
INSERT INTO `lokatie` VALUES(152, 'brecht', '4.6428094000', '51.3511383000', '2960', 'Brecht', 1, 0);
INSERT INTO `lokatie` VALUES(151, 'kapellen-antwerpen', '4.4278683000', '51.3167950000', '2950', 'Kapellen, Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(150, 'stabroek', '4.3648292000', '51.3319503000', '2940', 'Stabroek', 1, 0);
INSERT INTO `lokatie` VALUES(149, 'hoevenen', '4.4032203000', '51.3057832000', '2940', 'Hoevenen', 1, 0);
INSERT INTO `lokatie` VALUES(148, 'brasschaat', '4.4954295000', '51.3133626000', '2930', 'Brasschaat', 1, 0);
INSERT INTO `lokatie` VALUES(147, 'kalmthout', '4.4581628000', '51.3988520000', '2920', 'Kalmthout', 1, 0);
INSERT INTO `lokatie` VALUES(146, 'essen', '4.4648560000', '51.4406708000', '2910', 'Essen', 1, 0);
INSERT INTO `lokatie` VALUES(145, 'schoten', '4.5139892000', '51.2706562000', '2900', 'Schoten', 1, 0);
INSERT INTO `lokatie` VALUES(144, 'sint-amands', '4.2039790000', '51.0545095000', '2890', 'Sint-Amands', 1, 0);
INSERT INTO `lokatie` VALUES(143, 'oppuurs', '4.2441692000', '51.0663517000', '2890', 'Oppuurs', 1, 0);
INSERT INTO `lokatie` VALUES(142, 'lippelo', '4.2618911000', '51.0432702000', '2890', 'Lippelo', 1, 0);
INSERT INTO `lokatie` VALUES(141, 'weert', '4.1931173000', '51.1018210000', '2880', 'Weert', 1, 0);
INSERT INTO `lokatie` VALUES(140, 'mariekerke-bornem', '4.1899371000', '51.0605433000', '2880', 'Mariekerke (Bornem)', 1, 0);
INSERT INTO `lokatie` VALUES(139, 'hingene', '4.2688116000', '51.1032761000', '2880', 'Hingene', 1, 0);
INSERT INTO `lokatie` VALUES(138, 'bornem', '4.2348693000', '51.0996776000', '2880', 'Bornem', 1, 0);
INSERT INTO `lokatie` VALUES(137, 'ruisbroek-antwerpen', '4.3315528000', '51.0896757000', '2870', 'Ruisbroek, Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(136, 'puurs', '4.2755871000', '51.0765143000', '2870', 'Puurs', 1, 0);
INSERT INTO `lokatie` VALUES(135, 'liezele', '4.2800590000', '51.0601992000', '2870', 'Liezele', 1, 0);
INSERT INTO `lokatie` VALUES(134, 'breendonk', '4.3257261000', '51.0441963000', '2870', 'Breendonk', 1, 0);
INSERT INTO `lokatie` VALUES(133, 'onze-lieve-vrouw-waver', '4.5754857000', '51.0639394000', '2861', 'Onze-Lieve-Vrouw-Waver', 1, 0);
INSERT INTO `lokatie` VALUES(132, 'sint-katelijne-waver', '4.5055555000', '51.0614235000', '2860', 'Sint-Katelijne-Waver', 1, 0);
INSERT INTO `lokatie` VALUES(131, 'boom', '4.3779474000', '51.0924256000', '2850', 'Boom', 1, 0);
INSERT INTO `lokatie` VALUES(130, 'niel', '4.3329557000', '51.1071825000', '2845', 'Niel', 1, 0);
INSERT INTO `lokatie` VALUES(129, 'terhagen', '4.3971203000', '51.0800898000', '2840', 'Terhagen', 1, 0);
INSERT INTO `lokatie` VALUES(128, 'rumst', '4.4233031000', '51.0781312000', '2840', 'Rumst', 1, 0);
INSERT INTO `lokatie` VALUES(127, 'reet', '4.4126524000', '51.1012596000', '2840', 'Reet', 1, 0);
INSERT INTO `lokatie` VALUES(126, 'willebroek', '4.3604065000', '51.0607260000', '2830', 'Willebroek', 1, 0);
INSERT INTO `lokatie` VALUES(125, 'tisselt', '4.3587589000', '51.0340425000', '2830', 'Tisselt', 1, 0);
INSERT INTO `lokatie` VALUES(124, 'heindonk', '4.4067273000', '51.0666590000', '2830', 'Heindonk', 1, 0);
INSERT INTO `lokatie` VALUES(123, 'blaasveld', '4.3715143000', '51.0565925000', '2830', 'Blaasveld', 1, 0);
INSERT INTO `lokatie` VALUES(122, 'rijmenam', '4.5844421000', '51.0011339000', '2820', 'Rijmenam', 1, 0);
INSERT INTO `lokatie` VALUES(121, 'bonheiden', '4.5475032000', '51.0224150000', '2820', 'Bonheiden', 1, 0);
INSERT INTO `lokatie` VALUES(120, 'muizen-mechelen', '4.5168262000', '51.0139320000', '2812', 'Muizen (Mechelen)', 1, 0);
INSERT INTO `lokatie` VALUES(119, 'leest', '4.4195710000', '51.0336796000', '2811', 'Leest', 1, 0);
INSERT INTO `lokatie` VALUES(118, 'hombeek', '4.4421390000', '51.0152806000', '2811', 'Hombeek', 1, 0);
INSERT INTO `lokatie` VALUES(117, 'heffen', '4.4090115000', '51.0494135000', '2801', 'Heffen', 1, 0);
INSERT INTO `lokatie` VALUES(116, 'walem', '4.4568606000', '51.0659932000', '2800', 'Walem', 1, 0);
INSERT INTO `lokatie` VALUES(115, 'mechelen', '4.4780726000', '51.0289190000', '2800', 'Mechelen', 1, 0);
INSERT INTO `lokatie` VALUES(114, 'edegem', '4.4380338000', '51.1529820000', '2650', 'Edegem', 1, 0);
INSERT INTO `lokatie` VALUES(113, 'mortsel', '4.4665225000', '51.1728522000', '2640', 'Mortsel', 1, 0);
INSERT INTO `lokatie` VALUES(112, 'aartselaar', '4.3844742000', '51.1340539000', '2630', 'Aartselaar', 1, 0);
INSERT INTO `lokatie` VALUES(111, 'schelle', '4.3451903000', '51.1250483000', '2627', 'Schelle', 1, 0);
INSERT INTO `lokatie` VALUES(110, 'hemiksem', '4.3358751000', '51.1463366000', '2620', 'Hemiksem', 1, 0);
INSERT INTO `lokatie` VALUES(109, 'gestel', '4.6747238000', '51.1276277000', '2590', 'Gestel', 1, 0);
INSERT INTO `lokatie` VALUES(108, 'berlaar', '4.6600052000', '51.1184123000', '2590', 'Berlaar', 1, 0);
INSERT INTO `lokatie` VALUES(107, 'putte', '4.6289382000', '51.0562339000', '2580', 'Putte', 1, 0);
INSERT INTO `lokatie` VALUES(106, 'beerzel', '4.6706653000', '51.0576396000', '2580', 'Beerzel', 1, 0);
INSERT INTO `lokatie` VALUES(105, 'duffel', '4.5302842000', '51.0970920000', '2570', 'Duffel', 1, 0);
INSERT INTO `lokatie` VALUES(104, 'nijlen', '4.6700171000', '51.1610419000', '2560', 'Nijlen', 1, 0);
INSERT INTO `lokatie` VALUES(103, 'kessel', '4.6287396000', '51.1389975000', '2560', 'Kessel', 1, 0);
INSERT INTO `lokatie` VALUES(102, 'bevel', '4.6814214000', '51.1373787000', '2560', 'Bevel', 1, 0);
INSERT INTO `lokatie` VALUES(101, 'waarloos', '4.4560833000', '51.1027092000', '2550', 'Waarloos', 1, 0);
INSERT INTO `lokatie` VALUES(100, 'kontich', '4.4448390000', '51.1346882000', '2550', 'Kontich', 1, 0);
INSERT INTO `lokatie` VALUES(99, 'lint', '4.5003232000', '51.1270385000', '2547', 'Lint', 1, 0);
INSERT INTO `lokatie` VALUES(98, 'hove', '4.4785055000', '51.1488217000', '2540', 'Hove', 1, 0);
INSERT INTO `lokatie` VALUES(97, 'vremde', '4.5339282000', '51.1781205000', '2531', 'Vremde', 1, 0);
INSERT INTO `lokatie` VALUES(96, 'boechout', '4.4971700000', '51.1664397000', '2530', 'Boechout', 1, 0);
INSERT INTO `lokatie` VALUES(95, 'ranst', '4.5608873000', '51.1903856000', '2520', 'Ranst', 1, 0);
INSERT INTO `lokatie` VALUES(94, 'oelegem', '4.5971868000', '51.2108526000', '2520', 'Oelegem', 1, 0);
INSERT INTO `lokatie` VALUES(93, 'emblem', '4.6063271000', '51.1623638000', '2520', 'Emblem', 1, 0);
INSERT INTO `lokatie` VALUES(92, 'broechem', '4.6019845000', '51.1813377000', '2520', 'Broechem', 1, 0);
INSERT INTO `lokatie` VALUES(91, 'lier', '4.5736171000', '51.1301550000', '2500', 'Lier', 1, 0);
INSERT INTO `lokatie` VALUES(90, 'koningshooikt', '4.6104554000', '51.0949067000', '2500', 'Koningshooikt', 1, 0);
INSERT INTO `lokatie` VALUES(89, 'olmen', '5.1606990000', '51.1338157000', '2491', 'Olmen', 1, 0);
INSERT INTO `lokatie` VALUES(88, 'balen', '5.2100666000', '51.1578305000', '2490', 'Balen', 1, 0);
INSERT INTO `lokatie` VALUES(87, 'dessel', '5.1235191000', '51.2455742000', '2480', 'Dessel', 1, 0);
INSERT INTO `lokatie` VALUES(86, 'retie', '5.0763087000', '51.2686279000', '2470', 'Retie', 1, 0);
INSERT INTO `lokatie` VALUES(85, 'tielen', '4.8969270000', '51.2419530000', '2460', 'Tielen', 1, 0);
INSERT INTO `lokatie` VALUES(84, 'lichtaart', '4.9200829000', '51.2245899000', '2460', 'Lichtaart', 1, 0);
INSERT INTO `lokatie` VALUES(83, 'kasterlee', '4.9663639000', '51.2408319000', '2460', 'Kasterlee', 1, 0);
INSERT INTO `lokatie` VALUES(82, 'meerhout', '5.0752598000', '51.1218380000', '2450', 'Meerhout', 1, 0);
INSERT INTO `lokatie` VALUES(81, 'geel', '4.9908542000', '51.1623296000', '2440', 'Geel', 1, 0);
INSERT INTO `lokatie` VALUES(80, 'veerle', '4.9869024000', '51.0700492000', '2431', 'Veerle', 1, 0);
INSERT INTO `lokatie` VALUES(79, 'varendonk', '4.9522424000', '51.0825463000', '2431', 'Varendonk', 1, 0);
INSERT INTO `lokatie` VALUES(78, 'vorst-kempen', '5.0323247000', '51.0820644000', '2430', 'Vorst, Kempen', 1, 0);
INSERT INTO `lokatie` VALUES(77, 'laakdal', '5.0242977000', '51.0873823000', '2430', 'Laakdal', 1, 0);
INSERT INTO `lokatie` VALUES(76, 'eindhout', '5.0034671000', '51.1052971000', '2430', 'Eindhout', 1, 0);
INSERT INTO `lokatie` VALUES(75, 'mol', '5.1962097000', '51.2213789000', '2400', 'Mol', 1, 0);
INSERT INTO `lokatie` VALUES(74, 'westmalle', '4.6908592000', '51.3011516000', '2390', 'Westmalle', 1, 0);
INSERT INTO `lokatie` VALUES(73, 'oostmalle', '4.7319202000', '51.3011852000', '2390', 'Oostmalle', 1, 0);
INSERT INTO `lokatie` VALUES(72, 'malle', '4.7236195000', '51.3043858000', '2390', 'Malle', 1, 0);
INSERT INTO `lokatie` VALUES(71, 'baarle-hertog', '4.9044992000', '51.4046963000', '2387', 'Baarle-Hertog', 1, 0);
INSERT INTO `lokatie` VALUES(70, 'poppel', '5.0592852000', '51.4586402000', '2382', 'Poppel', 1, 0);
INSERT INTO `lokatie` VALUES(69, 'weelde', '5.0004736000', '51.4190551000', '2381', 'Weelde', 1, 0);
INSERT INTO `lokatie` VALUES(68, 'ravels', '5.0185568000', '51.3762015000', '2380', 'Ravels', 1, 0);
INSERT INTO `lokatie` VALUES(67, 'arendonk', '5.0768229000', '51.3421481000', '2370', 'Arendonk', 1, 0);
INSERT INTO `lokatie` VALUES(66, 'oud-turnhout', '5.0073017000', '51.3136124000', '2360', 'Oud-Turnhout', 1, 0);
INSERT INTO `lokatie` VALUES(65, 'vosselaar', '4.8834494000', '51.3030836000', '2350', 'Vosselaar', 1, 0);
INSERT INTO `lokatie` VALUES(64, 'vlimmeren', '4.7810871000', '51.2953286000', '2340', 'Vlimmeren', 1, 0);
INSERT INTO `lokatie` VALUES(63, 'beerse', '4.8564507000', '51.3198108000', '2340', 'Beerse', 1, 0);
INSERT INTO `lokatie` VALUES(62, 'merksplas', '4.8616250000', '51.3617870000', '2330', 'Merksplas', 1, 0);
INSERT INTO `lokatie` VALUES(61, 'meerle', '4.8031381000', '51.4694102000', '2328', 'Meerle', 1, 0);
INSERT INTO `lokatie` VALUES(60, 'wortel', '4.8105746000', '51.4006985000', '2323', 'Wortel', 1, 0);
INSERT INTO `lokatie` VALUES(59, 'minderhout', '4.7794791000', '51.4440580000', '2322', 'Minderhout', 1, 0);
INSERT INTO `lokatie` VALUES(58, 'meer', '4.7357497000', '51.4427664000', '2321', 'Meer', 1, 0);
INSERT INTO `lokatie` VALUES(57, 'hoogstraten', '4.7468218000', '51.4032970000', '2320', 'Hoogstraten', 1, 0);
INSERT INTO `lokatie` VALUES(56, 'rijkevorsel', '4.7706425000', '51.3550139000', '2310', 'Rijkevorsel', 1, 0);
INSERT INTO `lokatie` VALUES(55, 'turnhout', '4.9344756000', '51.3377191000', '2300', 'Turnhout', 1, 0);
INSERT INTO `lokatie` VALUES(54, 'vorselaar', '4.7601857000', '51.2189405000', '2290', 'Vorselaar', 1, 0);
INSERT INTO `lokatie` VALUES(53, 'bouwel', '4.7433872000', '51.1699342000', '2288', 'Bouwel', 1, 0);
INSERT INTO `lokatie` VALUES(52, 'grobbendonk', '4.7349959000', '51.1832616000', '2280', 'Grobbendonk', 1, 0);
INSERT INTO `lokatie` VALUES(51, 'wechelderzande', '4.7865968000', '51.2631887000', '2275', 'Wechelderzande', 1, 0);
INSERT INTO `lokatie` VALUES(50, 'poederlee', '4.8353179000', '51.2262686000', '2275', 'Poederlee', 1, 0);
INSERT INTO `lokatie` VALUES(49, 'lille', '4.8243044000', '51.2385083000', '2275', 'Lille', 1, 0);
INSERT INTO `lokatie` VALUES(48, 'gierle', '4.8675606000', '51.2668658000', '2275', 'Gierle', 1, 0);
INSERT INTO `lokatie` VALUES(47, 'herenthout', '4.7460081000', '51.1356598000', '2270', 'Herenthout', 1, 0);
INSERT INTO `lokatie` VALUES(46, 'zoerle-parwijs', '4.8721914000', '51.0878837000', '2260', 'Zoerle-Parwijs', 1, 0);
INSERT INTO `lokatie` VALUES(45, 'westerlo', '4.9177663000', '51.0872770000', '2260', 'Westerlo', 1, 0);
INSERT INTO `lokatie` VALUES(44, 'tongerlo-antwerpen', '4.9155301000', '51.1062335000', '2260', 'Tongerlo, Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(43, 'oevel', '4.9036444000', '51.1386158000', '2260', 'Oevel', 1, 0);
INSERT INTO `lokatie` VALUES(42, 'olen', '4.8851510000', '51.1666078000', '2250', 'Olen', 1, 0);
INSERT INTO `lokatie` VALUES(41, 'pulle', '4.6861600000', '51.1957105000', '2243', 'Pulle', 1, 0);
INSERT INTO `lokatie` VALUES(40, 'pulderbos', '4.6919235000', '51.2176838000', '2242', 'Pulderbos', 1, 0);
INSERT INTO `lokatie` VALUES(39, 'zandhoven', '4.6604283000', '51.2151646000', '2240', 'Zandhoven', 1, 0);
INSERT INTO `lokatie` VALUES(38, 'viersel', '4.6488708000', '51.1874984000', '2240', 'Viersel', 1, 0);
INSERT INTO `lokatie` VALUES(37, 'massenhoven', '4.6359857000', '51.1993569000', '2240', 'Massenhoven', 1, 0);
INSERT INTO `lokatie` VALUES(36, 'westmeerbeek', '4.8346555000', '51.0612780000', '2235', 'Westmeerbeek', 1, 0);
INSERT INTO `lokatie` VALUES(35, 'hulshout', '4.7910250000', '51.0747602000', '2235', 'Hulshout', 1, 0);
INSERT INTO `lokatie` VALUES(34, 'houtvenne', '4.8085568000', '51.0415859000', '2235', 'Houtvenne', 1, 0);
INSERT INTO `lokatie` VALUES(33, 'ramsel', '4.8326788000', '51.0323721000', '2230', 'Ramsel', 1, 0);
INSERT INTO `lokatie` VALUES(32, 'herselt', '4.8807978000', '51.0528794000', '2230', 'Herselt', 1, 0);
INSERT INTO `lokatie` VALUES(31, 'schriek', '4.6960515000', '51.0277811000', '2223', 'Schriek', 1, 0);
INSERT INTO `lokatie` VALUES(30, 'wiekevorst', '4.7948325000', '51.1089887000', '2222', 'Wiekevorst', 1, 0);
INSERT INTO `lokatie` VALUES(29, 'itegem', '4.7299527000', '51.1028966000', '2222', 'Itegem', 1, 0);
INSERT INTO `lokatie` VALUES(28, 'booischot', '4.7625115000', '51.0460108000', '2221', 'Booischot', 1, 0);
INSERT INTO `lokatie` VALUES(27, 'heist-op-den-berg', '4.7290145000', '51.0758168000', '2220', 'Heist-op-den-Berg', 1, 0);
INSERT INTO `lokatie` VALUES(26, 'hallaar', '4.7291449000', '51.0841811000', '2220', 'Hallaar', 1, 0);
INSERT INTO `lokatie` VALUES(25, 'noorderwijk', '4.8397821000', '51.1406539000', '2200', 'Noorderwijk', 1, 0);
INSERT INTO `lokatie` VALUES(24, 'morkhoven', '4.8214871000', '51.1190764000', '2200', 'Morkhoven', 1, 0);
INSERT INTO `lokatie` VALUES(23, 'herentals', '4.8358298000', '51.1779067000', '2200', 'Herentals', 1, 0);
INSERT INTO `lokatie` VALUES(22, 'wommelgem', '4.5219648000', '51.2021676000', '2160', 'Wommelgem', 1, 0);
INSERT INTO `lokatie` VALUES(21, 'borsbeek-antwerpen', '4.4851903000', '51.1904787000', '2150', 'Borsbeek, Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(20, 'wijnegem', '4.5270315000', '51.2334311000', '2110', 'Wijnegem', 1, 0);
INSERT INTO `lokatie` VALUES(19, 'zwijndrecht', '4.3263758000', '51.2191912000', '2070', 'Zwijndrecht', 1, 0);
INSERT INTO `lokatie` VALUES(18, 'burcht', '4.3455232000', '51.2017688000', '2070', 'Burcht', 1, 0);
INSERT INTO `lokatie` VALUES(17, 'hoboken', '4.3532966000', '51.1771171000', '2660', 'Hoboken', 1, 0);
INSERT INTO `lokatie` VALUES(16, 'wilrijk', '4.3893798000', '51.1652924000', '2610', 'Wilrijk', 1, 0);
INSERT INTO `lokatie` VALUES(15, 'berchem', '4.4347991000', '51.1923982000', '2600', 'Berchem', 1, 0);
INSERT INTO `lokatie` VALUES(14, 'ekeren', '4.4299536000', '51.2817354000', '2180', 'Ekeren', 1, 0);
INSERT INTO `lokatie` VALUES(13, 'merksem', '4.4403455000', '51.2472392000', '2170', 'Merksem', 1, 0);
INSERT INTO `lokatie` VALUES(12, 'borgerhout', '4.4444118000', '51.2130001000', '2140', 'Borgerhout', 1, 0);
INSERT INTO `lokatie` VALUES(11, 'deurne', '4.4731932000', '51.2145255000', '2100', 'Deurne', 1, 0);
INSERT INTO `lokatie` VALUES(10, 'antwerpen', '4.4279883000', '51.2293515000', '2060', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(9, 'antwerpen', '4.3740221000', '51.2287575000', '2050', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(8, 'zandvliet', '4.3079413000', '51.3602955000', '2040', 'Zandvliet', 1, 0);
INSERT INTO `lokatie` VALUES(7, 'lillo', '4.2897701000', '51.3045843000', '2040', 'Lillo', 1, 0);
INSERT INTO `lokatie` VALUES(6, 'berendrecht', '4.3144482000', '51.3401136000', '2040', 'Berendrecht', 1, 0);
INSERT INTO `lokatie` VALUES(5, 'antwerpen', '4.2964605000', '51.3418306000', '2040', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(4, 'antwerpen', '4.3624604000', '51.2763963000', '2030', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(3, 'antwerpen', '4.3836284000', '51.1890846000', '2020', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(2, 'antwerpen', '4.4112637000', '51.2037695000', '2018', 'Antwerpen', 1, 0);
INSERT INTO `lokatie` VALUES(1, 'antwerpen', '4.4011356000', '51.2198771000', '2000', 'Antwerpen', 0, 0);
INSERT INTO `lokatie` VALUES(14275, 'brussel', '4.3515499000', '50.8427501000', '1000', 'Brussel', 23, 0);
INSERT INTO `lokatie` VALUES(14276, 'brussel', '4.3515499000', '50.8427501000', '1000', 'Brussel', 23, 0);
INSERT INTO `lokatie` VALUES(14277, 'brussel', '4.3515499000', '50.8427501000', '1000', 'Brussel', 23, 0);
INSERT INTO `lokatie` VALUES(14278, 'brussel', '4.3515499000', '50.8427501000', '1000', 'Brussel', 23, 0);
INSERT INTO `lokatie` VALUES(14279, 'schaarbeek', '4.3796600000', '50.8625502000', '1030', 'Schaarbeek', 23, 0);
INSERT INTO `lokatie` VALUES(14280, 'etterbeek', '4.3969658000', '50.8332318000', '1040', 'Etterbeek', 23, 0);
INSERT INTO `lokatie` VALUES(14281, 'elsene', '4.3766927000', '50.8235717000', '1050', 'Elsene', 23, 0);
INSERT INTO `lokatie` VALUES(14282, 'sint-gillis', '4.3464309000', '50.8299126000', '1060', 'Sint-Gillis', 23, 0);
INSERT INTO `lokatie` VALUES(14283, 'anderlecht', '4.2986584000', '50.8238652000', '1070', 'Anderlecht', 23, 0);
INSERT INTO `lokatie` VALUES(14284, 'sint-jans-molenbeek', '4.3193694000', '50.8569755000', '1080', 'Sint-Jans-Molenbeek', 23, 0);
INSERT INTO `lokatie` VALUES(14285, 'koekelberg', '4.3250320000', '50.8632823000', '1081', 'Koekelberg', 23, 0);
INSERT INTO `lokatie` VALUES(14286, 'sint-agatha-berchem', '4.2925975000', '50.8657821000', '1082', 'Sint-Agatha-Berchem', 23, 0);
INSERT INTO `lokatie` VALUES(14287, 'ganshoren', '4.3093326000', '50.8729866000', '1083', 'Ganshoren', 23, 0);
INSERT INTO `lokatie` VALUES(14288, 'jette', '4.3314996000', '50.8747739000', '1090', 'Jette', 23, 0);
INSERT INTO `lokatie` VALUES(14289, 'evere', '4.4061878000', '50.8719806000', '1140', 'Evere', 23, 0);
INSERT INTO `lokatie` VALUES(14290, 'sint-pieters-woluwe', '4.4494347000', '50.8286387000', '1150', 'Sint-Pieters-Woluwe', 23, 0);
INSERT INTO `lokatie` VALUES(14291, 'oudergem', '4.4372273000', '50.8108671000', '1160', 'Oudergem', 23, 0);
INSERT INTO `lokatie` VALUES(14292, 'watermaal-bosvoorde', '4.4180065000', '50.7881573000', '1170', 'Watermaal-Bosvoorde', 23, 0);
INSERT INTO `lokatie` VALUES(14293, 'ukkel', '4.3559193000', '50.7904904000', '1180', 'Ukkel', 23, 0);
INSERT INTO `lokatie` VALUES(14294, 'vorst', '4.3218906000', '50.8125885000', '1190', 'Vorst', 23, 0);
INSERT INTO `lokatie` VALUES(14295, 'sint-lambrechts-woluwe', '4.4278228000', '50.8503080000', '1200', 'Sint-Lambrechts-Woluwe', 23, 0);
INSERT INTO `lokatie` VALUES(14296, 'sint-joost-ten-node', '4.3704657000', '50.8537715000', '1210', 'Sint-Joost-ten-Node', 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lokatie_zonenummer`
--

CREATE TABLE `lokatie_zonenummer` (
  `id` int(11) NOT NULL auto_increment,
  `lokatie_id` int(4) NOT NULL,
  `zonenummer_id` int(4) NOT NULL,
  PRIMARY KEY  (`id`,`lokatie_id`,`zonenummer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Link tussen lokatie en de telefoon zonenummers\n' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `lokatie_zonenummer`
--


-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  `menu_code` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` VALUES(4, 'Pizza''s', '1000');

-- --------------------------------------------------------

--
-- Table structure for table `menukaart`
--

CREATE TABLE `menukaart` (
  `id` int(11) NOT NULL auto_increment,
  `resto_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`,`menu_id`,`resto_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `menukaart`
--


-- --------------------------------------------------------

--
-- Table structure for table `optie_variant`
--

CREATE TABLE `optie_variant` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  `optie_id` int(3) NOT NULL,
  `matrix` decimal(4,2) default NULL,
  PRIMARY KEY  (`id`,`optie_id`),
  KEY `fk_variant_gerecht_opties1` (`optie_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `optie_variant`
--

INSERT INTO `optie_variant` VALUES(7, 'Medium', 1, '1.20');
INSERT INTO `optie_variant` VALUES(5, 'Normaal', 1, '1.00');
INSERT INTO `optie_variant` VALUES(8, 'Panpizza', 2, '1.20');
INSERT INTO `optie_variant` VALUES(9, 'Napolitaans (Normaal)', 2, '1.00');
INSERT INTO `optie_variant` VALUES(10, 'Large', 1, '1.50');
INSERT INTO `optie_variant` VALUES(11, 'Stuffed crust', 2, '1.50');
INSERT INTO `optie_variant` VALUES(12, 'Normaal', 3, '1.00');
INSERT INTO `optie_variant` VALUES(13, 'Karton', 3, '0.80');

-- --------------------------------------------------------

--
-- Table structure for table `promoties`
--

CREATE TABLE `promoties` (
  `id` int(4) NOT NULL auto_increment,
  `onderwerp` mediumtext,
  `bericht` text COMMENT 'mag beperkte html bevatten',
  `startdatum` bigint(20) default NULL,
  `einddatum` bigint(20) default NULL,
  `verstuurd` tinyint(1) default NULL,
  `promocode` varchar(6) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `promoties`
--


-- --------------------------------------------------------

--
-- Table structure for table `provincie`
--

CREATE TABLE `provincie` (
  `id` smallint(6) NOT NULL auto_increment,
  `name` varchar(255) character set latin1 collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

--
-- Dumping data for table `provincie`
--


-- --------------------------------------------------------

--
-- Table structure for table `resto`
--

CREATE TABLE `resto` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) default NULL,
  `taal` varchar(45) default NULL,
  `lokatie_adres` varchar(45) default NULL,
  `lokatie_id` varchar(45) NOT NULL,
  `leveringkosten_minimaal` decimal(4,2) NOT NULL,
  PRIMARY KEY  (`id`,`lokatie_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Alle gegevens die te maken hebben met het restaurant' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `resto`
--

INSERT INTO `resto` VALUES(1, 'Pizza Milo', 'nl', 'Hertjen 32', '403', '20.00');

-- --------------------------------------------------------

--
-- Table structure for table `voedsel_categorie`
--

CREATE TABLE `voedsel_categorie` (
  `id` int(11) NOT NULL auto_increment,
  `naam` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=14 ;

--
-- Dumping data for table `voedsel_categorie`
--

INSERT INTO `voedsel_categorie` VALUES(1, 'Groente');
INSERT INTO `voedsel_categorie` VALUES(2, 'Kruiden en Specerijen');
INSERT INTO `voedsel_categorie` VALUES(3, 'Vlees');
INSERT INTO `voedsel_categorie` VALUES(4, 'Noten');
INSERT INTO `voedsel_categorie` VALUES(5, 'Kazen');
INSERT INTO `voedsel_categorie` VALUES(6, 'Zeevruchten');
INSERT INTO `voedsel_categorie` VALUES(12, 'Fruit');

-- --------------------------------------------------------

--
-- Table structure for table `zonenummers`
--

CREATE TABLE `zonenummers` (
  `id` int(11) NOT NULL auto_increment,
  `zonenummer` int(4) NOT NULL,
  `naam` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `zonenummers`
--

